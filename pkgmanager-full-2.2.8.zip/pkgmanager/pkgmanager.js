/**
 * MeshCentral Package Manager plugin ("pkgmanager") — v2.0.3.
 *
 *     v2.2.8 SIDE-BY-SIDE TOP PANES: Macchine scansionate and Pacchetti
 *     rilevati go back to a flex row (1 : 1.5), as two fixed sections;
 *     the rest of the v2.2.7 stack is unchanged.
 *
 *     v2.2.7 FIXED SECTIONS + DOWNLOAD PROGRESS: the OS view is a stack of
 *     fixed-height sections (dropdown on top, then Macchine, Pacchetti,
 *     NEW Avanzamento download, Piano, Riassunto at the bottom), each with
 *     its own internal scroll; page scroll stays free. osfetch now reports
 *     per-file progress (pkgOsFetchProgress: start/ok/fail/end + total).
 *
 *     v2.2.6 SUMMARY BAR + SCROLLABLE LISTS: fixed "Riassunto mancanti"
 *     strip at the bottom of the OS view (per release: machines, missing,
 *     bytes to download, in-store, selected) updated on every plan/select
 *     change; machines box and plan table now scroll (max-height 420px).
 *
 *     v2.2.5 WINDOWS IN THE UNIFIED PLAN: Microsoft Update Catalog per
 *     windows group (query "<family> Version <displayVer>") -> missing =
 *     catalog KB not installed on any machine of the group -> same fields
 *     as Linux (package/version/file/url/size/targets), resolved download
 *     URL via DownloadDialog, store dir os-updates-windows-<ver>, osfetch
 *     and checkboxes identical. Catalog cap: 30 most recent per group.
 *     Install for Windows (.msu push+wusa) NOT yet wired.
 *
 *     v2.2.4 HONEST EMPTY PLAN: with only windows/macos machines the
 *     right pane said "tutte le macchine sono aggiornate" and still
 *     showed the download button — wrong, the plan only covers Linux.
 *     Empty plan now points to "Esporta downloader"; button hidden at
 *     zero rows; machine rows say "voci inventario" not "mancanti".
 *
 *     v2.2.3 SCAN-TABLE REMOVED: the per-machine "Scansione aggiornamenti
 *     OS" table is gone; version OS, inventory count and status live in
 *     the "Macchine scansionate" rows now (pkgOsScanRender forwards).
 *
 *     v2.2.2 EXPORTS FIX: every client function a view calls MUST be in
 *     obj.exports or MeshCentral never serializes it to the browser
 *     (pkgOsMachinesRender, PkgsRender, PkgsToggle, PkgsSelAll were missing - empty
 *     panes on any browser).
 *
 *     v2.2.1 OS TWO-PANE VIEW: machines pane (left) vs detected packages
 *     pane (right, unique per release + dedup across machines) with
 *     checkboxes and "Scarica selezionati" (osfetch packages filter);
 *     top "Scarica i mancanti sul server" removed.
 *
 *     v2.2.0 DOWNLOAD TAB + PLUGIN LOG: dedicated "Download plugin" tab
 *     (version/update, plugin downloader binaries with retry + last error,
 *     core agentbuilds clearly separated, log tail). plog() replaces the
 *     plugin's server console.log lines: same console output plus an
 *     in-memory ring (500 lines) and pkgmanager.log in datapath (1 MB
 *     rotation). Server actions: binstatus, binretry, plogtail (admin).
 *
 *     v2.1.12 UPDATE-CHECK CACHE-BUSTER: raw POPs served divergent copies
 *     (check could read a stale js and answer "already updated" for
 *     minutes). pluginupdate-check now fetches a unique query-string URL.
 *
 *     v2.1.11 ENSURE-BINARIES FIX: the downloader-binary bootstrap used the
 *     external `unzip` command (missing on minimal containers -> silent
 *     permanent failure) and never retried extraction errors. Now:
 *     yauzl-based extraction (core dependency resolved via server
 *     parentpath), unified retries, last error surfaced to the UI banner.
 *
 *     v2.1.10 HANDLER SIGNATURE FIX: server-sent plugin methods are invoked
 *     by the UI as handler[method](server, message) (default.handlebars).
 *     pkgAgentBuild took (message) and got the server object -> panel stuck
 *     on the placeholder. Same convention as pkgUpdateInfo/pkgOsPlan/etc.
 *
 *     v2.1.9 AGENT BINARY PANEL: serveraction "agentbuildinfo" (admin-only)
 *     surfaces parent.parent.agentDefaults.status() — the core tracks every
 *     default agent file with status/received/size — plus a disk scan of
 *     agentbuilds/ (verified cache) and agents/ (overrides). The plugin tab
 *     renders it with progress bars and auto-refreshes while anything is
 *     downloading. Graceful on cores without agentDefaults (core=null).
 *
 *     v2.1.8 RESTART BUTTON: admin-only "Riavvia server" button in the
 *     plugin view (serverrestart serveraction) — schedules a clean
 *     launcher-channel restart in 2s.
 *
 *     v2.1.7 AUTO-RESTART EVERYWHERE: the v2.1.6 check shipped inside the
 *     NEW code, but after a screen-install the OLD cached module keeps
 *     running and never saw it. Now: 60s poll (guarded, unref'd) notices a
 *     different config.json version on disk; self-update (online/file
 *     buttons) aligns config.json and auto-restarts by default
 *     (pkgmanagerAutoRestart:false to opt out); all restarts use the
 *     launcher channel ("Server restart..." on stdout, clean relaunch in
 *     500ms) instead of a bare exit(0) that the launcher reads as a crash.
 *     Stand-down: after reloadplugin the superseded module stops
 *     scheduling (globalThis.__pkgmanagerActiveVersion sentinel).
 *
 *     v2.1.6 AUTO-RESTART: server_startup detects an on-disk config.json
 *     version different from the running one (happens right after an
 *     install/update, where require() returns the cached old module) and
 *     schedules a graceful server restart via the launcher channel
 *     ("Server restart..." on stdout). Opt-out: autoRestartOnUpdate:false.
 *
 *     v2.1.5 STORE LIST RENDER FIX: pkgOsStoreList stored the array where
 *     the render expected { store: [...] } — the downloaded-packages
 *     section stayed empty on every render.
 *
 *     v2.1.4 VERSION COMPARATOR: verDebCmp — full dpkg version algorithm
 *     (epoch, ~ ordering, digit runs) in pure JS; the OS plan no longer
 *     depends on the server having dpkg (string fallback compared
 *     "4.10" < "4.9" -> phantom updates + reinstall loop).
 *
 *     v2.1.3 GHOST-PACKAGE FIX: Linux inventory = only actually-installed
 *     packages (dpkg-query Status-Abbrev filtered to installed states) —
 *     removed-but-not-purged ghosts no longer trigger phantom updates;
 *     plan shows the scan timestamp (staleness hint after installs).
 *
 *     v2.1.2 PLAN REASONS + BROKEN-STATE DETECTION: the OS-update plan shows
 *     WHY each package is there (update vs new dependency of an updated
 *     package — explains count differences vs apt upgrade); the Linux scan
 *     also runs dpkg --audit and warns about machines with unsatisfied
 *     dependencies.
 *
 *     v2.1.1 LEGACY STORE DIR: osstorelist also lists 'os-updates'
 *     (pre-2.0.7 downloads, no codename suffix) — previously invisible.
 *
 *     v2.1.0 STORE MANAGEMENT VIEW: "Gestione aggiornamenti OS" lists the
 *     downloaded store packages per release (osstorelist) with per-file
 *     delete, OS filter in the OS view, refresh button; airgap bundle
 *     import section unchanged.
 *
 *     v2.0.9 GROUP MACHINE SELECTION + EXPORT BUTTON: checkbox machine
 *     picker per OS group (staged updates: install only the picked machines),
 *     «Esporta downloader…» back in the OS view (airgap flow).
 *
 *     v2.0.8 OS-VIEW REDESIGN: plan-driven OS-updates view — per-OS
 *     dropdown, package list with installed/candidate versions and server
 *     store status, download-missing-only (osfetch), direct install from
 *     the plan (no catalog bundles). Server: osPlanCompute shared by
 *     osplan/osfetch; catalog bundles only via airgap manifest import.
 *
 *     v2.0.7 OS-BUNDLE REWORK: one bundle PER DISTRO RELEASE with
 *     per-package max-version union (machines at different update levels
 *     converge to the newest); single dpkg -i install; bundle contents
 *     visible per OS (admin + OS view); catalog save mutex (concurrent
 *     bundle saves no longer lose each other).
 *
 *     v2.0.6 SCAN INFO FIXES: Windows version column shows the real
 *     release (registry DisplayVersion) instead of the Windows API version
 *     (10.0.x even on Windows 11); Linux os-release values are
 *     quote-stripped (VERSION_ID arrives quoted, codename goes into the
 *     vendor repo URLs).
 *
 *     v2.0.5 SCAN FIX: pkgOsScan silently died since v2.0.2 (pkgD2Pending
 *     called before allids existed + dead d2runPending reference) — the
 *     scan button did nothing at all. Regression test: tools/test-client.js.
 *
 *     v2.0.4 CONFIG-URL INVARIANT GUARD: at startup the plugin force-aligns
 *     its local config.json (and the DB record) to the canonical
 *     self-referencing raw URLs and verifies the remote config.json too,
 *     logging a loud error on any future bad release (a configUrl field
 *     mismatch kills Node 24 on the official plugins screen).
 *
 *     v2.0.3 UPDATE SOURCE REPOINT: updateSrcUrl (self-update check) and
 *     binariesUrl (downloader binaries auto-install) still pointed at the
 *     archived fork branch (v2.0.0) — the update check always reported the
 *     plugin as current. Both now point at this repo's main/release.
 *
 *     v2.0.2 SELF-CONTAINED REPLY PLUMBING: the OS-update scanner and the
 *     batch/single installs depended on the d2run* machinery (d2runBegin/
 *     d2runPending/d2runResponseId + reply handlers) that only exists in the
 *     patched fork UI — on an OFFICIAL MeshCentral the scan stayed "waiting"
 *     forever because nothing collected the runcommands replies. The plugin
 *     now wraps meshserver.onMessage once (idempotent) and routes its own
 *     replies into window.pkgmanagerD2; on the forked UI it coexists with the
 *     dialog (install still opens it when present, otherwise a summary is
 *     reported via the message line).
 *
 *     v2.0.1 OS CLASSIFICATION FIX: machines are now classified by AGENT TYPE
 *     (node.agent.id — always present) before falling back to the os_title/os
 *     text. Previously a Windows machine with a missing/empty os_title was
 *     silently treated as Linux (the default), breaking inventory and installs.
 *
 * Design: the catalog lives server-side (catalog.json next to this file).
 * The plugin pages are TABS IN THE TOP GRAY BAR (their own
 * #pkgmanagerMenuSpan row next to #MainSubMenuSpan — the span that renders
 * the per-device General/Desktop/Terminal/Files tabs — with the same
 * topbar_td style3x classes; the active tab carries the same fullselect
 * class go() toggles on the core tabs). The row is ALWAYS visible as the
 * plugin top menu (v0.7.1): it is hidden ONLY while a device sub-view owns
 * the gray bar (x 9..19, the General/Desktop/... row), so the three
 * entries are discoverable right after login):
 *   - "Installa/Elimina pacchetti" (everyone, renamed in v1.2.0): packages
 *     are CHECKBOX-SELECTABLE (no per-row buttons) and ONE "Installa
 *     selezionati" + ONE "Elimina selezionati" button runs the whole batch:
 *     every selected package x every selected machine, one runcommands per
 *     OS|type group with the per-package commands concatenated (the results
 *     dialog shows one combined output per machine). "Elimina" runs the new
 *     MANDATORY per-OS "uninstall" command (v1.2.1: required exactly like
 *     the install command — both the client save and the server save
 *     reject a def without it), auto-generated by the preset where the
 *     artifact extension allows (.deb/.rpm/.apk -> dpkg -r/rpm -e/apk del,
 *     .msi -> msiexec /x, .pkg -> pkgutil --forget, .app -> rm -rf
 *     /Applications), with an explicit note when it cannot be automated.
 *     The per-device tab keeps its per-row Install.
 *     package table + target machine checkboxes on the right; the list
 *     auto-filters by the OSes of the selected machines; installs run on
 *     EVERY selected machine and the output comes back into ONE results
 *     dialog (runcommands reply).
 *   - "Gestione pacchetti" (full site admins only): catalog management —
 *     add / edit / delete packages and upload / delete airgap artifacts
 *     straight from the UI.
 *   - "Creazione pacchetti" (full site admins only): the GUIDED PACKAGE
 *     BUILDER (v0.9.0) — ONE single form with an OS dropdown (like the
 *     other options): switching OS swaps artifact/type/timeout/command
 *     fields and a per-OS draft in memory never loses anything. Airgap
 *     v1.9.1 STICKY VIEW: when the control websocket drops (network blip,
 *     laptop sleep, server restart) the CORE bounces to the disconnection
 *     panel (go(0)) and silently re-lands on the main page (go(1)) after
 *     the reconnect — killing any open plugin view. goPageStart now SAVES
 *     the active plugin view into sessionStorage on every go(0) (the one
 *     go() a user can never fire by hand) and pkgList REOPENS it by itself
 *     once the catalog arrives after the bounce (only when the core landed
 *     on page 1 and no plugin view is active; the marker is consumed on
 *     read). A user-initiated navigation away (any other go(x)) never arms
 *     the marker — the sticky restore only ever follows a real disconnect.
 *     v1.9.2 STAY-IN-VIEW + PLATFORM DROPDOWN: diagnosed LIVE (probe stack)
 *     the scan bounce root cause: the core's mainUpdate() naggle timer ends
 *     with gotoStartViewPage(), which fires go(1) whenever xxcurrentView ==
 *     -1 — and the plugin views USE -1 as their convention, so every event
 *     flood during a scan (or a WS re-landing) tears the plugin view down.
 *     goPageStart now distinguishes user navigation (every real click passes
 *     `event`) from SPONTANEOUS core navigation (event == null): the latter
 *     is re-asserted right after the core's go() completes (setTimeout 0,
 *     same view->open mapping as the sticky restore). go(0) still tears down
 *     and arms the sticky marker (a reload may follow). «Esporta downloader…»
 *     now shows an inline DROPDOWN (7 compiled platforms + py) instead of the
 *     typed prompt; confirmation via pkgOsExportGo().
 *     v1.9.3 ZERO-FLICKER NEUTRALIZATION: v1.9.2's deferred re-assert still
 *     let the core's go(1) body SHOW panel p1 for one frame before hiding it
 *     again — every event flood (serverstats, agent state, ...) flickered
 *     the page while a plugin view was open. Root insight: go() checks
 *     `if (xxcurrentView == x) return;` AFTER the goPageStart hook, so the
 *     hook now sets xxcurrentView = x for SPONTANEOUS go()s (event == null,
 *     x !== 0, plugin view active) and the core's body becomes a no-op —
 *     no panel is ever shown or hidden. gotoStartViewPage then short-
 *     circuits on its own (xxcurrentView != -1). User navigation (event)
 *     tears down as before, restoring xxcurrentView = -1 first so the same
 *     core body really shows the requested panel (no blank main area).
 *     v1.9.4 OS FILTER ON «GESTIONE PACCHETTI»: dropdown above the target-
 *     machines list (Tutti/Linux/Windows/macOS, remembered in
 *     window.pkgmanagerOsFilterVal — NOT pkgmanagerOsFilter: elements with an
 *     id become window properties, the id-global would shadow the state). pkgDevListRender() renders the device rows
 *     with data-os and hides non-matching ones (count shown); pkgDevOsFilter()
 *     re-renders ONLY that list. pkgDevSelectAll() respects the filter — but
 *     only on the install view (the select exists there; the OS view keeps
 *     unfiltered select-all). Checked machines survive filter changes: the
 *     filter is visual, the selection is the install target.
 *     v1.9.5 OS FILTER ON «GESTIONE PACCHETTI» (the CATALOG view with the
 *     Modifica/Elimina buttons): second dropdown (Tutti/Linux/Windows/macOS)
 *     showing only packages that HAVE a definition for the chosen OS, with a
 *     "mostrati X di Y" count. State in window.pkgmanagerAdminOsVal (select
 *     id pkgmanagerAdminOsSel — again avoiding the id-global trap). The OS
 *     bundles bar («Gestione aggiornamenti») stays unfiltered, as requested.
 *     v1.9.6 PLUGIN SELF-UPDATE (the last manual step, now automated): two
 *     admin buttons in «Gestione pacchetti». ONLINE: the SERVER fetches
 *     pkgmanager.js from obj.updateSrcUrl (raw GitHub of this fork,
 *     overridable via settings.plugins.pkgmanagerUpdateUrl), compares
 *     versions, hashes sha384, and installs. AIRGAP: «Aggiorna plugin
 *     (file)» POSTs the picked .js to /pkgstore.ashx?op=plugupd ->
 *     .update-pending.js, then the server verifies (vm syntax check, version
 *     >= running, sha384) and installs. Both paths: backup to
 *     pkgmanager.js.bak-<version> before overwrite; the new version
 *     activates on MeshCentral restart — automatic (process.exit after 3s)
 *     ONLY with settings.plugins.pkgmanagerAutoRestart === true (needs a
 *     service manager like systemd).
 *     v1.9.8 AUTO-INSTALL OF THE DOWNLOADER BINARIES: the official plugin
 *     package ships CODE ONLY (50KB) — the compiled per-OS downloader
 *     binaries are an instance asset. 15s after startup the plugin checks
 *     bin/ for all 7 platforms and, if any is missing, downloads the full
 *     package from obj.binariesUrl (GitHub release asset of this fork,
 *     overridable via settings.plugins.pkgmanagerBinariesUrl) and extracts
 *     pkgmanager/bin/* with unzip (childProcess) + exec permissions, then
 *     re-verifies. Up to 5 attempts, 15min between failures; airgap servers
 *     just keep using py or copy bin/ manually.
 *     v1.9.9 USER NOTICE WHILE BINARIES ARE PENDING: every pkgList reply
 *     carries binMissing/binBusy/binAttempts; the client shows an amber
 *     banner on top of the install, OS-updates and catalog views until all
 *     7 binaries are present ("downloading in background — export limited
 *     to py" / after 5 failed attempts: "not available — copy bin/
 *     manually or configure pkgmanagerBinariesUrl"). The banner disappears
 *     automatically once all binaries are in place.
 *     v1.9.0 COMPILED PER-PLATFORM DOWNLOADER: like the meshagents, the
 *     downloader ships COMPILED, one binary per OS — plugins/pkgmanager/
 *     bin/meshos-downloader-<platform> (win-x64, win-x86, linux-x64,
 *     linux-arm64, linux-arm, macos-x64, macos-arm64; Go source in
 *     tools/meshos-downloader/, stdlib only). «Esporta downloader…» asks the
 *     platform (auto-detected from the admin browser), the SERVER patches the
 *     scan inventory into the binary's embedded slot (byte-for-byte, like the
 *     meshagent .msh patch: __MESHOS_INVENTORY_START__ + 2MB + __END__) and
 *     serves it over /pkgstore.ashx (LAN download, admin-only). Run it on ANY
 *     machine with internet (zero args; --max N to cap), copy os-updates/ into
 *     the store (My Files), «Importa manifest…». 'py' in the platform prompt
 *     keeps the v1.8.0 stand-alone Python script as the fallback.
 *     v1.8.0 EXPORTABLE PYTHON DOWNLOADER: «Esporta downloader…» (admin,
 *     OS view) — the plugin GENERATES meshos-downloader.py with the scan
 *     inventory ALREADY EMBEDDED and hands it out through MeshCentral
 *     itself (LAN download): zero arguments, zero config, Python stdlib
 *     only (urllib/gzip/hashlib; dpkg version compare when available).
 *     THE flow for an AIRGAP server: run it on any machine with internet
 *     -> copy os-updates/ into the store (My Files) -> «Importa manifest…».
 *     «Scarica aggiornamenti» stays as the fast path for a server WITH
 *     internet; its errors/skips are now VISIBLE client-side (pkgList
 *     renders message.error — previously silent) and every message points
 *     to «Esporta downloader…» for airgap servers.
 *     v1.7.0 OS-TAB REMOVAL + INTEGRATED DOWNLOADER: OS updates can NOT be
 *     hand-created — the «Creazione aggiornamenti» tab is GONE (the OS bar
 *     keeps Aggiornamenti OS · Gestione aggiornamenti), the package wizard
 *     no longer offers the OS category and «Gestione aggiornamenti» keeps
 *     only Modifica/Elimina/Importa manifest (no manual Add): OS bundles
 *     come ONLY from the scan pipeline. NEW «Scarica aggiornamenti»
 *     (admin-only, OS view): sends the completed scan inventory to the
 *     SERVER, which fetches the Ubuntu vendor indexes (security+updates,
 *     main+universe), computes the missing updates per Linux machine
 *     (delta + dependency closure, dpkg version compare when available),
 *     downloads the .deb files DIRECTLY into store/<bundle-id>/ and re-
 *     enters the v1.6.1 import path (files re-verified, kind:'os' bundle
 *     built+saved, admin-guarded). Managed machines stay AIRGAP — only the
 *     server talks to the vendor mirrors; installs keep flowing from the
 *     LAN store. Windows/macOS machines are reported as skipped (best
 *     effort — meshos-fetch.js --kb/--macos stays as the documented
 *     fallback for a server without internet). Store-filename charset
 *     extended to [a-zA-Z0-9._+~:-] (Debian epochs / +dfsg versions).
 *     v1.6.1 IMPORT MANIFEST: «Importa manifest…» in Gestione aggiornamenti —
 *     the client reads a meshos-fetch manifest.json (file picker), the
 *     server verifies EVERY file already sits in store/<bundle-id>/, builds
 *     the kind:'os' bundle (artifacts[] + per-extension install commands
 *     with {{url:N}}/{{sha384:N}} placeholders) and saves it through the
 *     existing save path (admin-only, kind-aware guards).
 *     v1.6.0 OS-UPDATE SCANNER: «Scansiona macchine» in the OS view sends
 *     a per-OS inventory command to EVERY online machine (Linux dpkg-query,
 *     Windows Get-HotFix + build, macOS sw_vers + softwareupdate history)
 *     through the same reply channel used by Run Commands — no modal — and
 *     renders a per-machine table (OS, level, item count). «Esporta report
 *     (.json)» downloads the full inventory (machines, OS info, package/KB
 *     lists) that the external downloader consumes to fetch only the
 *     missing updates. For kind:'os' bundles the uninstall command becomes
 *     OPTIONAL (security patches are often non-removable); apps keep the
 *     v1.2.1 mandatory-uninstall rule everywhere.
 *     v1.5.0 SEPARATE GRAY BARS: each sidebar menu gets its OWN top bar —
 *     the packages icon opens the packages bar (Installa/Elimina pacchetti
 *     · Gestione pacchetti · Creazione pacchetti), the OS icon opens the OS
 *     bar (Aggiornamenti OS · Gestione aggiornamenti · Creazione
 *     aggiornamenti). The OS-side management/creation views filter on
 *     kind:'os' (pkgIsOsView) and the OS wizard forces Categoria=os.
 *     v1.4.0 SEPARATE OS-UPDATES VIEW: OS updates are managed SEPARATELY
 *     from software packages — a second sidebar icon (shield emoji
 *     «Aggiornamenti OS») opens its OWN tab + view that lists ONLY
 *     kind:'os' update bundles; the package views («Installa/Elimina»,
 *     «Gestione», per-device tab) show ONLY apps. A «Categoria» field in
 *     both forms (Applicazione / Aggiornamento OS) sets pkg.kind, carried
 *     per-OS in def.kind and persisted by sanitizeDef + the server save;
 *     every view filters on it. Install/delete mechanics UNCHANGED, shared.
 *     v1.3.0 OS-UPDATE BUNDLES (airgap): a package can carry MULTIPLE
 *     store files per OS (space/comma separated list in the artifact field):
 *     every file gets its own LAN download + SHA-384 verification line with
 *     an INDEXED placeholder ({{url:N}}/{{sha384:N}}); the preset chains all
 *     downloads + installers (.deb/.rpm/.apk, .msi/.msu/.cab, .pkg/.app) in
 *     one command and generates the multi-file uninstall where automatable.
 *     presets per artifact extension, {{url}}/{{sha384}} insertion at the
 *     cursor, artifact upload, live ID check. Save MERGES: drafted defs +
 *     defs already saved for that ID (the wizard never silently drops a
 *     saved OS). Catalog replies only update hints/acks, never re-render
 *     the form. v0.9.1: the management Add/Edit form uses the SAME
 *     single-form pattern (OS dropdown + its own per-OS drafts + merge
 *     save) — "Modifica" no longer shows one section per OS.
 *   - "My Files" shows the store as a NAVIGABLE FOLDER (v1.1.0, user
 *     request: "come la voce MyFiles/Public che ha di default"): a
 *     symlink "Pacchetti (pkgmanager)" -> store is created inside the My
 *     Files area of every FULL SITE ADMIN at server startup (junction
 *     type: works on Windows too without admin rights). The core file
 *     tree follows symlinks (readFilesRec uses statSync), so admins
 *     browse/download artifacts with ZERO core changes; non-admins never
 *     get the link and stale links are cleaned up. Deleting the link
 *     non-recursively removes just the link; the plugin recreates both
 *     the store dir and the link at every startup.
 * The sidebar box opens the main page directly (no dropdown), and the
 * per-device "Plugins" tab (p19) keeps a single-device entry point.
 *
 * AIRGAP (v0.4.0+): packages install WITHOUT internet. Artifacts are dropped
 * on the server in <datapath>/plugins/pkgmanager/store/<pkg-id>/<file> — or
 * uploaded from the management page — and served to the AGENT over the LAN by
 * this plugin via /pkgstore.ashx (GET download: per-process token; POST
 * upload/delete: session-authenticated full site admin). The device downloads
 * the artifact from THIS server and installs locally (dpkg -i / msiexec /
 * installer -pkg / plain script). Catalog "cmd" supports the {{url}} and
 * {{sha384}} placeholders (server-computed hash -> device-side verification).
 *
 * Server surface: serveraction "list" (catalog + token + artifact enrichment)
 * and "save"/"delete" (full site admins only); hook_setupHttpHandlers
 * registers /pkgstore.ashx GET+POST. Installs go through the core runcommands
 * path (device rights enforced).
 *
 * Client functions listed in obj.exports are stringified into the browser by
 * pluginHandler.prepExports() and run in page context: they must not reference
 * this closure — only page globals (meshserver, currentNode, nodes, userinfo,
 * Q, EscapeHtml, d2runBegin...) and pluginHandler.pkgmanager.*.
 */
        // v2.1.4: confronto versioni Debian in JS PURO (fallback quando il
// server MeshCentral NON ha dpkg — es. container Alpine). Il vecchio
// fallback (String >= String) confrontava '4.10' < '4.9' -> phantom
// update + loop di reinstallazione (caso xxd di Mauro).
var verOrder = function (c) { var cc = c.charCodeAt(0); if (cc === 126) { return -1; } if (/^[A-Za-z]$/.test(c)) { return cc; } return cc + 256; };
var verrevcmp = function (a, b) {
    var i = 0, j = 0;
    while ((i < a.length) || (j < b.length)) {
        while (((i < a.length) && !/[0-9]/.test(a[i])) || ((j < b.length) && !/[0-9]/.test(b[j]))) {
            var ac = (i < a.length) ? a.charCodeAt(i) : 0;
            var bc = (j < b.length) ? b.charCodeAt(j) : 0;
            if (ac !== bc) { return ((ac == 0) ? 0 : verOrder(String.fromCharCode(ac))) - ((bc == 0) ? 0 : verOrder(String.fromCharCode(bc))); }
            i++; j++;
        }
        while ((i < a.length) && (a[i] == '0')) { i++; }
        while ((j < b.length) && (b[j] == '0')) { j++; }
        var s1 = i, s2 = j;
        while ((i < a.length) && /[0-9]/.test(a[i])) { i++; }
        while ((j < b.length) && /[0-9]/.test(b[j])) { j++; }
        if ((i - s1) !== (j - s2)) { return (i - s1) - (j - s2); }
        var n1 = a.slice(s1, i), n2 = b.slice(s2, j);
        if (n1 !== n2) { return (parseInt(n1, 10) - parseInt(n2, 10)); }
    }
    return 0;
};
const verDebCmp = function (A, B) {
    A = String(A); B = String(B);
    var ea = A.indexOf(':'), eb = B.indexOf(':');
    var e1 = (ea >= 0) ? (parseInt(A.slice(0, ea), 10) || 0) : 0;
    var e2 = (eb >= 0) ? (parseInt(B.slice(0, eb), 10) || 0) : 0;
    if (e1 !== e2) { return (e1 - e2); }
    var a = (ea >= 0) ? A.slice(ea + 1) : A, b = (eb >= 0) ? B.slice(eb + 1) : B;
    var ra = a.lastIndexOf('-'), rb = b.lastIndexOf('-');
    var uc = verrevcmp((ra >= 0) ? a.slice(0, ra) : a, (rb >= 0) ? b.slice(0, rb) : b);
    if (uc !== 0) { return uc; }
    return verrevcmp((ra >= 0) ? a.slice(ra + 1) : '', (rb >= 0) ? b.slice(rb + 1) : '');
};

module.exports.verDebCmp = verDebCmp;

module.exports.pkgmanager = function (parent) {
    var crypto = require('crypto');
    var zlib = require('zlib');
    var childProcess = null; try { childProcess = require('child_process'); } catch (e) { }
    var vmMod = null; try { vmMod = require('vm'); } catch (e) { }
    var obj = {};
    obj.version = '2.2.8';
        globalThis.__pkgmanagerActiveVersion = obj.version; // v2.1.7: versione ATTIVA (il vecchio modulo in cache dopo un install resta a ZONA, il reloadplugin la aggiorna)
    obj.fs = parent.fs;
    obj.path = parent.path;
    obj.catalogPath = parent.path.join(parent.parent.datapath, 'plugins', 'pkgmanager', 'catalog.json');
    // v1.9.6: sorgente di aggiornamento del plugin (online); sovrascrivibile
    // da settings.plugins.pkgmanagerUpdateUrl. Il file caricato via airgap
    // atterra su .update-pending.js nella stessa cartella.
    obj.updateSrcUrl = 'https://raw.githubusercontent.com/hitclawagent/MeshCentral-pkgmanager/main/pkgmanager.js';
    try { var _pu = parent.parent.config.settings.plugins; if ((_pu != null) && (_pu.pkgmanagerUpdateUrl != null)) { obj.updateSrcUrl = String(_pu.pkgmanagerUpdateUrl); } } catch (e) { }
    obj.updatePendingPath = parent.path.join(parent.path.dirname(obj.catalogPath), '.update-pending.js');

    // v1.9.8: AUTO-INSTALL DEI BINARI del downloader in background. Il
    // pacchetto ufficiale del plugin contiene SOLO il codice: i binari
    // compilati per-OS sono un asset dell'istanza. Se mancano, 15s dopo
    // l'avvio il plugin scarica lo zip completo dalla release e estrae
    // pkgmanager/bin/* con unzip (niente toolchain Go sul target).
    // v2.2.0: LOGGER DEL PLUGIN — righe in memoria (coda 500) + file
    // pkgmanager.log in datapath/plugins/pkgmanager (rotazione a 1 MB).
    // plog sostituisce i console.log server del plugin: stesso output su
    // console/journal E traccia locale visibile dalla UI (sezione Log).
    obj.plogBuf = [];
    obj.plogCount = 0;
    obj.plog = function (msg) {
        var line = new Date().toISOString() + ' ' + String(msg);
        try { console.log('pkgmanager[server]: ' + String(msg)); } catch (e0) { }
        obj.plogBuf.push(line);
        if (obj.plogBuf.length > 500) { obj.plogBuf.splice(0, obj.plogBuf.length - 500); }
        try {
            if (obj.logPath == null) { obj.logPath = parent.path.join(parent.parent.datapath, 'plugins', 'pkgmanager', 'pkgmanager.log'); }
            parent.fs.appendFileSync(obj.logPath, line + '\n');
            obj.plogCount++;
            if ((obj.plogCount % 100) == 0) {
                var stl = parent.fs.statSync(obj.logPath);
                if (stl.size > 1048576) {
                    try { parent.fs.unlinkSync(obj.logPath + '.old'); } catch (e4) { }
                    parent.fs.renameSync(obj.logPath, obj.logPath + '.old');
                }
            }
        } catch (e3) { }
        return line;
    };

    obj.downloaderPlatforms = ['linux-x64', 'linux-arm64', 'linux-arm', 'win-x64', 'win-x86', 'macos-x64', 'macos-arm64'];
    obj.binariesUrl = 'https://github.com/hitclawagent/MeshCentral-pkgmanager/releases/download/v2.0.2/pkgmanager-full-2.0.2.zip';
    try { var _pbin = parent.parent.config.settings.plugins; if ((_pbin != null) && (_pbin.pkgmanagerBinariesUrl != null)) { obj.binariesUrl = String(_pbin.pkgmanagerBinariesUrl); } } catch (e) { }
    obj.binDir = parent.path.join(parent.parent.datapath, 'plugins', 'pkgmanager', 'bin');
    obj.binariesMissing = function () {
        var miss = [];
        for (var i in obj.downloaderPlatforms) {
            var plat = obj.downloaderPlatforms[i];
            var f = parent.path.join(obj.binDir, 'meshos-downloader-' + plat + ((plat.indexOf('win') === 0) ? '.exe' : ''));
            try { if (parent.fs.statSync(f).size < 1000000) { miss.push(plat); } } catch (e) { miss.push(plat); }
        }
        return miss;
    };
    obj.binariesLastError = null;
    // v2.1.11: estrazione zip in puro Node con yauzl (gia' dipendenza core).
    obj.extractZip = function (zipPath, outDir, func) {
        var done = false;
        var fin = function (e) { if (!done) { done = true; try { func(e); } catch (e2) { } } };
        var loadYauzl = function () {
            try { return require('yauzl'); } catch (e1) { }
            // Il plugin vive in datapath (fuori da node_modules): risolvi yauzl
            // dal parentpath del server (cwd del figlio di MeshCentral).
            var roots = [];
            try { roots.push(parent.parent.parentpath); } catch (e2) { }
            try { roots.push(process.cwd()); } catch (e3) { }
            for (var r in roots) {
                try { return require(parent.path.join(roots[r], 'node_modules', 'yauzl')); } catch (e4) { }
            }
            return null;
        };
        try {
            var yauzl = (parent.yauzl != null) ? parent.yauzl : loadYauzl();
            if (yauzl == null) { throw new Error('yauzl non disponibile su questo server'); }
            yauzl.open(zipPath, { lazyEntries: true, autoClose: true }, function (eZ, zipfile) {
                if (eZ != null) { fin(eZ); return; }
                try { parent.fs.rmSync(outDir, { recursive: true, force: true }); } catch (eR) { }
                zipfile.readEntry();
                zipfile.on('entry', function (entry) {
                    if (/\/$/.test(entry.fileName)) { try { parent.fs.mkdirSync(parent.path.join(outDir, entry.fileName), { recursive: true }); } catch (eD) { fin(eD); return; } zipfile.readEntry(); return; }
                    zipfile.openReadStream(entry, function (eR2, rs) {
                        if (eR2 != null) { fin(eR2); return; }
                        var out = parent.path.join(outDir, entry.fileName);
                        try { parent.fs.mkdirSync(parent.path.dirname(out), { recursive: true }); } catch (eD2) { fin(eD2); return; }
                        var w = parent.fs.createWriteStream(out);
                        w.on('error', function (eW) { fin(eW); });
                        rs.on('end', function () { zipfile.readEntry(); });
                        rs.pipe(w);
                    });
                });
                zipfile.on('error', function (eY) { fin(eY); });
                zipfile.on('end', function () { fin(null); });
            });
        } catch (e) { fin(e); }
    };
    obj.ensureBinariesBusy = false;
    obj.ensureBinariesAttempts = 0;
    obj.ensureBinaries = function () {
        try {
            if (obj.ensureBinariesBusy) return;
            var miss = obj.binariesMissing();
            if (miss.length == 0) { if (obj.ensureBinariesAttempts == 0) { obj.plog('binari del downloader presenti (' + obj.downloaderPlatforms.length + '/' + obj.downloaderPlatforms.length + ' piattaforme).'); } return; }
            if (obj.ensureBinariesAttempts >= 5) { obj.plog('ensureBinaries rinuncia dopo 5 tentativi (url: ' + obj.binariesUrl + ') — airgap: copia bin/ a mano o usa py.'); return; }
            obj.ensureBinariesBusy = true;
            obj.ensureBinariesAttempts++;
            obj.plog('ensureBinaries -> mancano ' + miss.length + '/7 binari (' + miss.join(', ') + '), scarico da ' + obj.binariesUrl + ' (tentativo ' + obj.ensureBinariesAttempts + ')...');
            var tmpZip = parent.path.join(parent.path.dirname(obj.catalogPath), '.binaries-pending.zip');
            Promise.resolve().then(function () { return fetch(obj.binariesUrl); }).then(function (r) {
                if (!r.ok) { throw new Error('HTTP ' + r.status); }
                return r.arrayBuffer();
            }).then(function (ab) {
                var buf = Buffer.from(ab);
                parent.fs.writeFileSync(tmpZip, buf);
                obj.plog('ensureBinaries -> scaricato ' + Math.round(buf.length / 1048576) + 'MB, estrazione...');
                var tmpDir = parent.path.join(parent.path.dirname(obj.catalogPath), '.binaries-extract');
                // v2.1.11: estrazione con yauzl (dipendenza di MeshCentral) —
                // niente comando esterno 'unzip', assente nei container minimi
                // (LXC): era la causa del fallimento silenzioso.
                obj.extractZip(tmpZip, tmpDir, function (eU) {
                    try {
                        if (eU != null) { throw new Error('estrazione: ' + eU); }
                        var srcBin = parent.path.join(tmpDir, 'pkgmanager', 'bin');
                        parent.fs.mkdirSync(obj.binDir, { recursive: true });
                        var names = parent.fs.readdirSync(srcBin);
                        for (var i in names) {
                            var from = parent.path.join(srcBin, names[i]);
                            var to = parent.path.join(obj.binDir, names[i]);
                            try { parent.fs.unlinkSync(to); } catch (e6) { }
                            parent.fs.renameSync(from, to);
                            try { parent.fs.chmodSync(to, 0o755); } catch (e7) { }
                        }
                        try { parent.fs.unlinkSync(tmpZip); } catch (e8) { }
                        try { parent.fs.rmSync(tmpDir, { recursive: true, force: true }); } catch (e9) { }
                        obj.binariesLastError = null;
    // v2.1.11: estrazione zip in puro Node con yauzl (gia' dipendenza core).
    obj.extractZip = function (zipPath, outDir, func) {
        var done = false;
        var fin = function (e) { if (!done) { done = true; try { func(e); } catch (e2) { } } };
        var loadYauzl = function () {
            try { return require('yauzl'); } catch (e1) { }
            // Il plugin vive in datapath (fuori da node_modules): risolvi yauzl
            // dal parentpath del server (cwd del figlio di MeshCentral).
            var roots = [];
            try { roots.push(parent.parent.parentpath); } catch (e2) { }
            try { roots.push(process.cwd()); } catch (e3) { }
            for (var r in roots) {
                try { return require(parent.path.join(roots[r], 'node_modules', 'yauzl')); } catch (e4) { }
            }
            return null;
        };
        try {
            var yauzl = (parent.yauzl != null) ? parent.yauzl : loadYauzl();
            if (yauzl == null) { throw new Error('yauzl non disponibile su questo server'); }
            yauzl.open(zipPath, { lazyEntries: true, autoClose: true }, function (eZ, zipfile) {
                if (eZ != null) { fin(eZ); return; }
                try { parent.fs.rmSync(outDir, { recursive: true, force: true }); } catch (eR) { }
                zipfile.readEntry();
                zipfile.on('entry', function (entry) {
                    if (/\/$/.test(entry.fileName)) { try { parent.fs.mkdirSync(parent.path.join(outDir, entry.fileName), { recursive: true }); } catch (eD) { fin(eD); return; } zipfile.readEntry(); return; }
                    zipfile.openReadStream(entry, function (eR2, rs) {
                        if (eR2 != null) { fin(eR2); return; }
                        var out = parent.path.join(outDir, entry.fileName);
                        try { parent.fs.mkdirSync(parent.path.dirname(out), { recursive: true }); } catch (eD2) { fin(eD2); return; }
                        var w = parent.fs.createWriteStream(out);
                        w.on('error', function (eW) { fin(eW); });
                        rs.on('end', function () { zipfile.readEntry(); });
                        rs.pipe(w);
                    });
                });
                zipfile.on('error', function (eY) { fin(eY); });
                zipfile.on('end', function () { fin(null); });
            });
        } catch (e) { fin(e); }
    };
    obj.ensureBinariesBusy = false; obj.binariesLastError = null;
                        var left = obj.binariesMissing();
                        obj.plog('ensureBinaries -> estratti ' + names.length + ' binari; mancanti ora: ' + left.length + ((left.length > 0) ? (' (' + left.join(', ') + ')') : ''));
                        if (left.length > 0) { setTimeout(function () { try { obj.ensureBinaries(); } catch (e10) { } }, 60000); }
                    } catch (e11) {
                        obj.binariesLastError = null;
    // v2.1.11: estrazione zip in puro Node con yauzl (gia' dipendenza core).
    obj.extractZip = function (zipPath, outDir, func) {
        var done = false;
        var fin = function (e) { if (!done) { done = true; try { func(e); } catch (e2) { } } };
        var loadYauzl = function () {
            try { return require('yauzl'); } catch (e1) { }
            // Il plugin vive in datapath (fuori da node_modules): risolvi yauzl
            // dal parentpath del server (cwd del figlio di MeshCentral).
            var roots = [];
            try { roots.push(parent.parent.parentpath); } catch (e2) { }
            try { roots.push(process.cwd()); } catch (e3) { }
            for (var r in roots) {
                try { return require(parent.path.join(roots[r], 'node_modules', 'yauzl')); } catch (e4) { }
            }
            return null;
        };
        try {
            var yauzl = (parent.yauzl != null) ? parent.yauzl : loadYauzl();
            if (yauzl == null) { throw new Error('yauzl non disponibile su questo server'); }
            yauzl.open(zipPath, { lazyEntries: true, autoClose: true }, function (eZ, zipfile) {
                if (eZ != null) { fin(eZ); return; }
                try { parent.fs.rmSync(outDir, { recursive: true, force: true }); } catch (eR) { }
                zipfile.readEntry();
                zipfile.on('entry', function (entry) {
                    if (/\/$/.test(entry.fileName)) { try { parent.fs.mkdirSync(parent.path.join(outDir, entry.fileName), { recursive: true }); } catch (eD) { fin(eD); return; } zipfile.readEntry(); return; }
                    zipfile.openReadStream(entry, function (eR2, rs) {
                        if (eR2 != null) { fin(eR2); return; }
                        var out = parent.path.join(outDir, entry.fileName);
                        try { parent.fs.mkdirSync(parent.path.dirname(out), { recursive: true }); } catch (eD2) { fin(eD2); return; }
                        var w = parent.fs.createWriteStream(out);
                        w.on('error', function (eW) { fin(eW); });
                        rs.on('end', function () { zipfile.readEntry(); });
                        rs.pipe(w);
                    });
                });
                zipfile.on('error', function (eY) { fin(eY); });
                zipfile.on('end', function () { fin(null); });
            });
        } catch (e) { fin(e); }
    };
    obj.ensureBinariesBusy = false; obj.binariesLastError = String(e11);
                        obj.plog('ensureBinaries errore installazione: ' + e11);
                        // v2.1.11: riprova anche per errori di estrazione (prima: nessun retry)
                        setTimeout(function () { try { obj.ensureBinaries(); } catch (e12) { } }, 60000);
                    }
                });
            }).catch(function (err) {
                obj.binariesLastError = null;
    // v2.1.11: estrazione zip in puro Node con yauzl (gia' dipendenza core).
    obj.extractZip = function (zipPath, outDir, func) {
        var done = false;
        var fin = function (e) { if (!done) { done = true; try { func(e); } catch (e2) { } } };
        var loadYauzl = function () {
            try { return require('yauzl'); } catch (e1) { }
            // Il plugin vive in datapath (fuori da node_modules): risolvi yauzl
            // dal parentpath del server (cwd del figlio di MeshCentral).
            var roots = [];
            try { roots.push(parent.parent.parentpath); } catch (e2) { }
            try { roots.push(process.cwd()); } catch (e3) { }
            for (var r in roots) {
                try { return require(parent.path.join(roots[r], 'node_modules', 'yauzl')); } catch (e4) { }
            }
            return null;
        };
        try {
            var yauzl = (parent.yauzl != null) ? parent.yauzl : loadYauzl();
            if (yauzl == null) { throw new Error('yauzl non disponibile su questo server'); }
            yauzl.open(zipPath, { lazyEntries: true, autoClose: true }, function (eZ, zipfile) {
                if (eZ != null) { fin(eZ); return; }
                try { parent.fs.rmSync(outDir, { recursive: true, force: true }); } catch (eR) { }
                zipfile.readEntry();
                zipfile.on('entry', function (entry) {
                    if (/\/$/.test(entry.fileName)) { try { parent.fs.mkdirSync(parent.path.join(outDir, entry.fileName), { recursive: true }); } catch (eD) { fin(eD); return; } zipfile.readEntry(); return; }
                    zipfile.openReadStream(entry, function (eR2, rs) {
                        if (eR2 != null) { fin(eR2); return; }
                        var out = parent.path.join(outDir, entry.fileName);
                        try { parent.fs.mkdirSync(parent.path.dirname(out), { recursive: true }); } catch (eD2) { fin(eD2); return; }
                        var w = parent.fs.createWriteStream(out);
                        w.on('error', function (eW) { fin(eW); });
                        rs.on('end', function () { zipfile.readEntry(); });
                        rs.pipe(w);
                    });
                });
                zipfile.on('error', function (eY) { fin(eY); });
                zipfile.on('end', function () { fin(null); });
            });
        } catch (e) { fin(e); }
    };
    obj.ensureBinariesBusy = false; obj.binariesLastError = String(err);
                obj.plog('ensureBinaries fallito (' + err + ') — riprovo tra 15 minuti.');
                setTimeout(function () { try { obj.ensureBinaries(); } catch (e12) { } }, 15 * 60 * 1000);
            });
        } catch (e) { obj.ensureBinariesBusy = false; obj.plog('ensureBinaries errore: ' + e); }
    };
    setTimeout(function () { try { obj.ensureBinaries(); } catch (e) { obj.plog('ensureBinaries errore: ' + e); } }, 15000);

    // ---- Client-side (stringified into the browser) ----
    obj.exports = ['onWebUIStartupEnd', 'pkgSidebarInject', 'pkgRequestList', 'pkgList', 'pkgCompose', 'pkgTableHtml', 'pkgTargetOs', 'pkgDevToggle', 'pkgDevSelectAll', 'pkgDevOsFilter', 'pkgDevListRender', 'pkgSelectedNodes', 'pkgSidebarOpen', 'pkgSidebarRenderDevices', 'pkgSidebarRender', 'pkgPkgToggle', 'pkgPkgSelectAll', 'pkgPkgSummary', 'pkgBatchRun', 'pkgOsScan', 'pkgOsImportManifest', 'pkgOsExportDownloader', 'pkgOsExportGo', 'pkgDownloaderReady', 'pkgOsScanPoll', 'pkgOsScanParse', 'pkgOsScanRender', 'pkgOsScanExport', 'pkgOsSidebarOpen', 'pkgOsRender', 'pkgOsMachinesRender', 'pkgOsPkgsRender', 'pkgOsPkgsToggle', 'pkgOsPkgsSelAll', 'pkgOsTable', 'pkgOsKind', 'pkgOsAdminOpen', 'pkgIsOsView', 'pkgInstall', 'pkgRunOn', 'goPageStart', 'pkgMsg', 'pkgTabSetActive', 'pkgAdminOpen', 'pkgAdminRender', 'pkgCreateOpen', 'pkgCreateRender', 'pkgCreateCurOs', 'pkgCreateDefaultType', 'pkgCreateFieldSync', 'pkgCreateDraftSync', 'pkgCreateOsChange', 'pkgCreateOsHint', 'pkgCreateUpload', 'pkgCreateArtifactDel', 'pkgCreatePreset', 'pkgCreateInsert', 'pkgCreateSave', 'pkgCreateCheckId', 'pkgCreateCatalogArrived', 'pkgAdminAdd', 'pkgAdminEdit', 'pkgAdminForm', 'pkgAdminCurOs', 'pkgAdminFieldSync', 'pkgAdminDraftSync', 'pkgAdminOsChange', 'pkgAdminOsHint', 'pkgAdminSave', 'pkgAdminDelete', 'pkgAdminUpload', 'pkgAdminUploadDo', 'pkgAdminArtifactDel', 'pkgAdminStatus', 'pkgAdminRefresh', 'pkgAdminOsFilter', 'pkgBinBanner', 'pkgOsPluginOpen', 'pkgOsPluginRender', 'pkgUpdateOnline', 'pkgUpdateFile', 'pkgRestartNow', 'pkgAgentBuild', 'pkgAgentBuildRequest', 'pkgBinStatus', 'pkgBinStatusRequest', 'pkgBinRetry', 'pkgLogTail', 'pkgLogTailRequest', 'pkgUpdateUpload', 'pkgUpdateInfo', 'pkgUpdateApplied', 'pkgDenied', 'pkgD2WrapOnMessage', 'pkgD2Pending', 'pkgD2Receive', 'pkgD2PollSummary', 'pkgOsPlan', 'pkgOsPlanRender', 'pkgOsPlanSelChange', 'pkgOsSummaryRender', 'pkgOsFetchProgress', 'pkgOsFetchProgRender', 'pkgOsPlanRequest', 'pkgOsPlanDownload', 'pkgOsPlanInstall', 'pkgOsPlanMachToggle', 'pkgOsPlanMachSelAll', 'pkgOsStoreRequest', 'pkgOsStoreList', 'pkgOsStoreSelChange', 'pkgOsStoreDel'];

    obj.onWebUIStartupEnd = function () {
        try {
            // v2.0.2: reply plumbing SELF-CONTAINED. Sul MeshCentral ufficiale
            // manca il machinery d2run* del fork (d2runBegin/d2runPending +
            // handler delle risposte): qui wrappiamo meshserver.onMessage una
            // volta sola e instradiamo le risposte runcommands del plugin in
            // window.pkgmanagerD2. Sul fork coesiste senza conflitti (rid diversi).
            pluginHandler.pkgmanager.pkgD2WrapOnMessage();
            pluginHandler.registerPluginTab({ tabId: 'pkgmanagerTab', tabTitle: 'Packages' });
            var d = document.getElementById('pkgmanagerTab');
            if (d != null) { d.innerHTML = '<div style="padding:12px;font-family:Arial,Helvetica,sans-serif">Loading package catalog…</div>'; }
            console.log('pkgmanager: startup hook');
            pluginHandler.pkgmanager.pkgSidebarInject();
            pluginHandler.pkgmanager.pkgRequestList();
        } catch (e) { console.log('pkgmanager startup failed: ' + e); }
    };

    // v2.0.2: wrap idempotente di meshserver.onMessage (page context).
    obj.pkgD2WrapOnMessage = function () {
        try {
            if ((typeof meshserver != 'object') || (meshserver == null) || (meshserver.onMessage == null)) { return; }
            if (meshserver.onMessage.pkgmanagerWrapped === true) { return; }
            var prev = meshserver.onMessage;
            var wrapped = function (server, message) {
                try { pluginHandler.pkgmanager.pkgD2Receive(message); } catch (e2) { }
                prev(server, message);
            };
            wrapped.pkgmanagerWrapped = true;
            meshserver.onMessage = wrapped;
        } catch (e) { }
    };

    // v2.0.2: pending del plugin (responseid -> risultati per nodo), indipendente
    // dal fork (d2runPending) e dall'ufficiale (nulla).
    obj.pkgD2Pending = function (nodeids) {
        if (window.pkgmanagerD2 == null) { window.pkgmanagerD2 = {}; }
        var rid = 'pkgm-' + Date.now() + '-' + Math.floor(Math.random() * 1000000);
        window.pkgmanagerD2[rid] = { nodes: nodeids.slice(0), results: {} };
        return rid;
    };

    // v2.0.2: ricezione risposte runcommands. Due canali:
    // - action 'runcommands' con responseid e SENZA nodeid = errore immediato
    //   del server ("Agent not connected", "Access denied", ...): attribuito al
    //   primo nodo senza risultato (stessa semantica del fork);
    // - msg type 'runcommands' con nodeid = chunk di output del comando.
    // I chunk consecutivi dello stesso nodo vengono CONCATENATI.
    obj.pkgD2Receive = function (message) {
        try {
            if ((message == null) || (message.responseid == null) || (window.pkgmanagerD2 == null)) { return; }
            var p = window.pkgmanagerD2[message.responseid];
            if (p == null) { return; }
            var nid = message.nodeid;
            if (nid == null) { for (var i in p.nodes) { if (p.results[p.nodes[i]] == null) { nid = p.nodes[i]; break; } } }
            if (nid == null) { return; }
            var txt = String((message.result == null) ? '' : message.result);
            p.results[nid] = ((p.results[nid] == null) ? '' : (String(p.results[nid]) + '\n')) + txt;
        } catch (e) { }
    };

    // v2.0.2: attesa sintetica per gli install su UI ufficiale (senza dialogo
    // d2run del fork): riporta via pkgMsg quando tutte le macchine hanno
    // risposto o allo scadere del cap.
    obj.pkgD2PollSummary = function (rid, started, label, cap) {
        try {
            var p = ((window.pkgmanagerD2 != null) && (window.pkgmanagerD2[rid] != null)) ? window.pkgmanagerD2[rid] : null;
            var got = 0, total = 0;
            if (p != null) { for (var i in p.nodes) { total++; if (p.results[p.nodes[i]] != null) { got++; } } }
            if ((got < total) && ((Date.now() - started) < (cap || 420000))) { setTimeout(function () { pluginHandler.pkgmanager.pkgD2PollSummary(rid, started, label, cap); }, 2000); return; }
            try { delete window.pkgmanagerD2[rid]; } catch (e2) { }
            pluginHandler.pkgmanager.pkgMsg(label + ': ' + got + '/' + total + ' macchine hanno restituito output' + ((got < total) ? ' (timeout o nessuna risposta dalle restanti).' : '.'));
        } catch (e) { }
    };

    // "Packages" entry in the LEFT SIDEBAR (classic + default3 render #page_leftbar;
    // mobile has none, the injection skips there). Clicking it opens the main
    // page directly (no dropdown). The plugin pages are TABS IN THE TOP GRAY
    // BAR (see the injection below). The per-device "Plugins" tab from
    // registerPluginTab keeps working as a second entry point.
    obj.pkgSidebarInject = function () {
        try {
            if (document.getElementById('LeftMenuPackages') != null) return;
            var lb = document.getElementById('page_leftbar');
            if (lb == null) { console.log('pkgmanager: no sidebar in this template, entry skipped'); return; }
            var b = document.createElement('div');
            b.id = 'LeftMenuPackages';
            b.className = 'lbbutton';
            b.title = 'Installa/Elimina pacchetti';
            b.setAttribute('tabindex', '0');
            b.setAttribute('onmouseup', 'pluginHandler.pkgmanager.pkgSidebarOpen()');
            // Icon sized to match the other sidebar entries (.lbtg is 62x62).
            b.innerHTML = '<div style="position:absolute;top:8px;left:0;width:100%;text-align:center;font-size:46px;line-height:58px">📦</div>';
            lb.appendChild(b);
            // v1.4.0: SECOND sidebar entry — OS updates managed SEPARATELY.
            var b2 = document.createElement('div');
            b2.id = 'LeftMenuOsUpdates';
            b2.className = 'lbbutton';
            b2.title = 'Aggiornamenti e gestione del sistema operativo (airgap)';
            b2.setAttribute('tabindex', '0');
            b2.setAttribute('onmouseup', 'pluginHandler.pkgmanager.pkgOsSidebarOpen()');
            // v1.9.14: icona SVG «due frecce che si rincorrono» (archi spessi
            // e verdi, stile sync) al posto dell'emoji — resa identica su
            // tutte le piattaforme e colore controllato.
            b2.innerHTML = '<div style="position:absolute;top:10px;left:0;width:100%;text-align:center">'
                + '<svg width="54" height="54" viewBox="0 0 24 24" fill="none" stroke="#34a853" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">'
                + '<polyline points="23 4 23 10 17 10"></polyline>'
                + '<polyline points="1 20 1 14 7 14"></polyline>'
                + '<path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"></path>'
                + '</svg></div>';
            lb.appendChild(b2);
            var col = document.getElementById('column_l');
            if (col == null) return;
            var page = document.createElement('div');
            page.id = 'pkgmanagerMainWrap';
            page.style.display = 'none';
            page.innerHTML = '<div id="pkgmanagerMain" style="padding:12px;font-family:Arial,Helvetica,sans-serif"></div>';
            col.appendChild(page);
            // TOP GRAY BAR: the classic template HIDES #MainMenuSpan and shows
            // the per-device tabs (General/Desktop/Files) in #MainSubMenuSpan.
            // Render the plugin tabs in the SAME place and style: our own
            // #pkgmanagerMenuSpan div + table (topbar_td style3x) as a sibling
            // of #MainSubMenuSpan, shown while a plugin page is open and hidden
            // by goPageStart on every go(). "Gestione pacchetti" starts hidden
            // and is shown by pkgTabSetActive() once userinfo is known (admins).
            var sub = document.getElementById('MainSubMenuSpan') || document.getElementById('MainMenuSpan');
            var span = document.createElement('div');
            span.id = 'pkgmanagerMenuSpan';
            span.style.display = 'none';
            if ((sub != null) && (sub.parentNode != null)) {
                // v0.7.2: full-width row like the core device tab row (the core CSS width:100% on
                // #MainSubMenuSpan/#MainSubMenu does not cover this plugin span -> inline on both)
                // + padded entries (16px, like the core nonenglish tabs) so they are not glued.
                span.style.width = '100%';
                // v1.5.0: TWO separate gray bars — one per sidebar menu.
                span.innerHTML = '<table id="pkgmanagerMenuTable" cellpadding=0 cellspacing=0 class="style1" style="width:100%"><tr>'
                    + '<td tabindex=0 id="MainTabPackages" class="topbar_td style3x" style="padding-left:16px;padding-right:16px" onmouseup="pluginHandler.pkgmanager.pkgSidebarOpen()" onkeypress="if (event.key == \'Enter\') pluginHandler.pkgmanager.pkgSidebarOpen()">Installa/Elimina pacchetti</td>'
                    + '<td tabindex=0 id="MainTabPkgMgmt" class="topbar_td style3x" style="display:none;padding-left:16px;padding-right:16px" onmouseup="pluginHandler.pkgmanager.pkgAdminOpen()" onkeypress="if (event.key == \'Enter\') pluginHandler.pkgmanager.pkgAdminOpen()">Gestione pacchetti</td>'
                    + '<td tabindex=0 id="MainTabPkgCreate" class="topbar_td style3x" style="display:none;padding-left:16px;padding-right:16px" onmouseup="pluginHandler.pkgmanager.pkgCreateOpen()" onkeypress="if (event.key == \'Enter\') pluginHandler.pkgmanager.pkgCreateOpen()">Creazione pacchetti</td>'
                    + '<td class="topbar_td_end style3">&nbsp;</td>'
                    + '</tr></table>';
                var span2 = document.createElement('div');
                span2.id = 'osmanagerMenuSpan';
                span2.style.display = 'none';
                span2.style.width = '100%';
                span2.innerHTML = '<table id="osmanagerMenuTable" cellpadding=0 cellspacing=0 class="style1" style="width:100%"><tr>'
                    + '<td tabindex=0 id="MainTabOsUpdates" class="topbar_td style3x" style="padding-left:16px;padding-right:16px" onmouseup="pluginHandler.pkgmanager.pkgOsSidebarOpen()" onkeypress="if (event.key == \'Enter\') pluginHandler.pkgmanager.pkgOsSidebarOpen()">Aggiornamenti OS</td>'
                    + '<td tabindex=0 id="MainTabOsMgmt" class="topbar_td style3x" style="display:none;padding-left:16px;padding-right:16px" onmouseup="pluginHandler.pkgmanager.pkgOsAdminOpen()" onkeypress="if (event.key == \'Enter\') pluginHandler.pkgmanager.pkgOsAdminOpen()">Gestione aggiornamenti OS</td>'
                    + '<td tabindex=0 id="MainTabOsPlugin" class="topbar_td style3x" style="display:none;padding-left:16px;padding-right:16px" onmouseup="pluginHandler.pkgmanager.pkgOsPluginOpen()" onkeypress="if (event.key == \'Enter\') pluginHandler.pkgmanager.pkgOsPluginOpen()">Download plugin</td>'
                    + '<td class="topbar_td_end style3">&nbsp;</td>'
                    + '</tr></table>';
                sub.parentNode.insertBefore(span, sub.nextSibling);
                sub.parentNode.insertBefore(span2, sub.nextSibling);
            } else {
                var tb2 = document.getElementById('topbar');
                if (tb2 != null) { tb2.appendChild(span); }
            }
            // The tab row is the plugin TOP MENU: visible right away (v0.7.1),
            // not only after a plugin page is opened.
            pluginHandler.pkgmanager.pkgTabSetActive(null, false);
            console.log('pkgmanager: sidebar entry + top bar tabs injected (gray bar only on plugin pages)');
        } catch (e) { console.log('pkgmanager sidebar inject failed: ' + e); }
    };

    // Top gray bar tab state: our #pkgmanagerMenuSpan row shows while a plugin
    // page is open (like #MainSubMenuSpan does while a device is selected);
    // goPageStart (-> null) hides it. Highlight the ACTIVE plugin tab with the
    // same class go() toggles on the core tabs (fullselect), keep "Gestione
    // pacchetti" visible to full site admins only (userinfo.siteadmin), and
    // reserve the submenu row height on column_l exactly like go() does
    // (room4submenu) so the page does not slide under the bar.
    obj.pkgTabSetActive = function (which, hideRow) {
        try {
            var spanA = document.getElementById('pkgmanagerMenuSpan'); // packages bar
            var spanB = document.getElementById('osmanagerMenuSpan'); // OS bar
            if ((spanA == null) && (spanB == null)) return;
            var t1 = document.getElementById('MainTabPackages');
            var t2 = document.getElementById('MainTabPkgMgmt');
            var t3 = document.getElementById('MainTabPkgCreate');
            var o1 = document.getElementById('MainTabOsUpdates');
            var o2 = document.getElementById('MainTabOsMgmt');
            var o3 = document.getElementById('MainTabOsPlugin');
            var adm = ((typeof userinfo != 'undefined') && (userinfo != null) && (userinfo.siteadmin === 0xFFFFFFFF));
            if (t2 != null) { t2.style.display = adm ? '' : 'none'; }
            if (t3 != null) { t3.style.display = adm ? '' : 'none'; }
            if (o2 != null) { o2.style.display = adm ? '' : 'none'; }
            if (o3 != null) { o3.style.display = adm ? '' : 'none'; }
            // v1.5.0: each sidebar menu shows ONLY its own gray bar (v1.4.1
            // rule kept: both hide on every core page; goPageStart -> which null).
            var osBar = ((which == 'os') || (which == 'osadmin') || (which == 'osplugin'));
            if (spanA != null) { spanA.style.display = ((which != null) && (!osBar) && (hideRow !== true)) ? '' : 'none'; }
            if (spanB != null) { spanB.style.display = ((osBar) && (hideRow !== true)) ? '' : 'none'; }
            var ts = [t1, t2, t3, o1, o2, o3];
            for (var i = 0; i < ts.length; i++) { if (ts[i] != null) { ts[i].classList.remove('fullselect'); } }
            // v1.9.11: indicatore di voce attiva nel menu laterale (le voci
            // core usano lbbuttonsel2 — il bottone si allarga e tocca la
            // pagina). pkgTabSetActive e' chiamato sia all'apertura delle
            // viste plugin sia da goPageStart(null) al ritorno su una pagina
            // core, quindi qui la classe viene aggiunta E rimossa.
            var sb1 = document.getElementById('LeftMenuPackages');
            var sb2 = document.getElementById('LeftMenuOsUpdates');
            var sbs = [sb1, sb2];
            for (var s = 0; s < sbs.length; s++) {
                if (sbs[s] != null) { sbs[s].classList.remove('lbbuttonsel'); sbs[s].classList.remove('lbbuttonsel2'); }
            }
            // v1.9.12: apertura di una vista plugin -> pulisce ANCHE la
            // selezione delle voci core (menu sinistro + barra top), altrimenti
            // l'ultima pagina default visitata resta evidenziata accanto al
            // trattino del plugin (il core pulisce le sue classi solo dentro
            // go(), che il click sulla voce plugin non attraversa).
            if (which != null) {
                var coreLeft = ['LeftMenuMyDevices', 'LeftMenuMyAccount', 'LeftMenuMyEvents', 'LeftMenuMyFiles', 'LeftMenuMyUsers', 'LeftMenuMyServer'];
                var coreTop = ['MainMenuMyDevices', 'MainMenuMyAccount', 'MainMenuMyEvents', 'MainMenuMyFiles', 'MainMenuMyUsers', 'MainMenuMyServer'];
                for (var c4 = 0; c4 < coreLeft.length; c4++) {
                    var el = document.getElementById(coreLeft[c4]);
                    if (el != null) { el.classList.remove('lbbuttonsel'); el.classList.remove('lbbuttonsel2'); }
                    var el2 = document.getElementById(coreTop[c4]);
                    if (el2 != null) { el2.classList.remove('fullselect'); el2.classList.remove('semiselect'); }
                }
            }
            if (which != null) {
                var a = { install: t1, admin: t2, create: t3, os: o1, osadmin: o2, osplugin: o3 }[which];
                if (a != null) { a.classList.add('fullselect'); }
                var sbSel = (osBar) ? sb2 : sb1;
                if (sbSel != null) { sbSel.classList.add('lbbuttonsel2'); }
                try { QC('column_l').add('room4submenu'); } catch (e) { }
            } else {
                try { QC('column_l').remove('room4submenu'); } catch (e) { }
            }
        } catch (e) { }
    };

    // go() calls this hook on EVERY navigation — but BEFORE its own modal guard
    // (`if (xxdialogMode) return;`): a go() fired while a modal is open (e.g. the
    // async startup-view re-entry the template runs on a server event) is a NO-OP
    // for the core, yet would tear this page down. Mirror the core guard: with a
    // modal open keep the plugin page; a real navigation (modal closed) still
    // tears it down.
    obj.goPageStart = function (x, event) {
        try {
            if ((typeof xxdialogMode !== 'undefined') && xxdialogMode) return; // core would no-op this go()
            // v1.9.1 sticky view: x == 0 e' il PANNELLO DI DISCONNESSIONE —
            // il core rimbalza li' a ogni caduta della websocket di controllo
            // e riatterra in silenzio su go(1) dopo la riconnessione,
            // uccidendo la vista plugin aperta. Salvala ORA (un utente non
            // puo' mai sparare go(0) a mano) cosi' pkgList la riapre quando
            // il catalogo torna dopo il bounce.
            var curV = window.pkgmanagerView;
            if ((x === 0) && (curV != null)) {
                try { sessionStorage.setItem('pkgmanagerStickyView', String(curV)); } catch (e2) { }
                console.log('pkgmanager: sticky view armata per il bounce: ' + String(curV));
            }
            // v1.9.3: un go() SENZA evento e' navigazione SPONTANEA del core
            // (gotoStartViewPage dopo ogni flood di eventi — scansione,
            // serverstats, stato agenti — o la riatterrata della websocket):
            // gotoStartViewPage scatta proprio perche' le viste plugin usano
            // xxcurrentView == -1, che per il core significa "nessuna vista".
            // NON e' una scelta dell'utente (ogni click reale passa `event`).
            // v1.9.2 la riasseriva DOPO il go() — ma il corpo di go() mostra
            // p1 per un frame prima: flicker a ogni flood. Il corpo di go()
            // pero' esce subito con "if (xxcurrentView == x) return" — quindi
            // qui impostiamo xxcurrentView = x: il corpo diventa un NO-OP,
            // nessun pannello viene mostrato o nascosto. ZERO flicker; e dal
            // flood dopo, gotoStartViewPage esce da solo (xx != -1).
            if ((event == null) && (x !== 0) && (curV != null)) {
                if ((typeof x === 'number') && (typeof xxcurrentView === 'number') && (xxcurrentView !== x)) { xxcurrentView = x; }
                console.log('pkgmanager: go(' + String(x) + ') spontaneo neutralizzato: vista ' + curV + ' resta');
                return;
            }
            // navigazione UTENTE (event != null) o go(0): teardown come prima.
            // Riprimo xxcurrentView a -1 SOLO se era stato neutralizzato (>= 0):
            // cosi' il corpo di go(x) non fa l'early-return e mostra davvero il
            // pannello richiesto (niente area principale vuota).
            if ((curV != null) && (typeof xxcurrentView === 'number') && (xxcurrentView >= 0)) { xxcurrentView = -1; }
            window.pkgmanagerView = null;
            pluginHandler.pkgmanager.pkgTabSetActive(null, ((typeof x == 'number') && (x >= 9) && (x < 20)));
            var w = document.getElementById('pkgmanagerMainWrap');
            if (w != null) w.style.display = 'none';
            var b = document.getElementById('LeftMenuPackages');
            if (b != null) b.style.opacity = '';
            var bo = document.getElementById('LeftMenuOsUpdates');
            if (bo != null) bo.style.opacity = '';
        } catch (e) { }
    };

    obj.pkgSidebarOpen = function () {
        try {
            var w = document.getElementById('pkgmanagerMainWrap');
            if (w == null) return;
            // Hide the current core panel and reset the view tracker so any later
            // go(x) fully restores the normal panel (no same-view early return).
            try {
                if ((typeof xxcurrentView == 'number') && (xxcurrentView >= 0) && (xxcurrentView <= 60)) { QV('p' + xxcurrentView, false); }
                xxcurrentView = -1;
            } catch (e) { }
            w.style.display = '';
            window.pkgmanagerView = 'install';
            pluginHandler.pkgmanager.pkgTabSetActive('install');
            var b = document.getElementById('LeftMenuPackages');
            if (b != null) b.style.opacity = '1';
            pluginHandler.pkgmanager.pkgSidebarRenderDevices();
        } catch (e) { console.log('pkgmanager open failed: ' + e); }
    };

    // ---- "Gestione pacchetti" (full site admins) ----
    // ---- v1.5.0: OS-side admin/create views (opened from the OS gray bar) ----
    obj.pkgIsOsView = function () {
        return ((window.pkgmanagerView == 'os') || (window.pkgmanagerView == 'osadmin'));
    };

    // v1.9.13: scheda «Aggiorna plugin» — i due tasti di aggiornamento
    // (online e file airgap) con la sintesi della versione corrente.
    obj.pkgOsPluginOpen = function () {
        try {
            var w = document.getElementById('pkgmanagerMainWrap');
            if (w == null) return;
            try {
                if ((typeof xxcurrentView == 'number') && (xxcurrentView >= 0) && (xxcurrentView <= 60)) { QV('p' + xxcurrentView, false); }
                xxcurrentView = -1;
            } catch (e) { }
            w.style.display = '';
            window.pkgmanagerView = 'osplugin';
            window.pkgmanagerAdminMsg = '';
            pluginHandler.pkgmanager.pkgTabSetActive('osplugin');
            var b = document.getElementById('LeftMenuPackages');
            if (b != null) b.style.opacity = '';
            var bo = document.getElementById('LeftMenuOsUpdates');
            if (bo != null) bo.style.opacity = '1';
            pluginHandler.pkgmanager.pkgOsPluginRender();
            try { if (typeof userinfo != 'undefined' && userinfo != null && userinfo.siteadmin === 0xFFFFFFFF) { pluginHandler.pkgmanager.pkgBinStatusRequest(); pluginHandler.pkgmanager.pkgAgentBuildRequest(); pluginHandler.pkgmanager.pkgLogTailRequest(); } } catch (e2) { }
        } catch (e) { console.log('pkgmanager osplugin open failed: ' + e); }
    };

    obj.pkgOsPluginRender = function () {
        try {
            var m = document.getElementById('pkgmanagerMain');
            if (m == null) return;
            var adm = ((typeof userinfo != 'undefined') && (userinfo != null) && (userinfo.siteadmin === 0xFFFFFFFF));
            var ver = ((window.pkgmanagerPluginVersion != null) ? String(window.pkgmanagerPluginVersion) : null);
            var x = '<div style="margin-bottom:8px;font-size:16px"><b>Download plugin</b></div>' + pluginHandler.pkgmanager.pkgBinBanner();
            x += '<div style="margin-bottom:10px">Versione corrente del plugin: <b style="font-size:15px">v' + EscapeHtml((ver != null) ? ver : '?') + '</b>' + ((ver == null) ? ' <span style="color:#888">(si aggiorna al primo caricamento del catalogo)</span>' : '') + '</div>';
            if (adm) {
                x += '<div style="margin-bottom:10px"><input type=button value="Aggiorna plugin (online)" title="Il SERVER scarica la nuova versione del plugin dal sorgente configurato, la verifica (sha384) e la installa con backup: serve il riavvio di MeshCentral per attivarla" onclick="pluginHandler.pkgmanager.pkgUpdateOnline()"> <input type=button value="Aggiorna plugin (file)" title="VIA AIRGAP: carica il pkgmanager.js nuovo da un file locale; il server lo verifica (JavaScript valido, versione, sha384), fa il backup e lo installa — serve il riavvio di MeshCentral per attivarla" onclick="pluginHandler.pkgmanager.pkgUpdateFile()"> <input type=button value="Riavvia server" title="Riavvia MeshCentral tramite il canale del launcher (riavvio pulito)" onclick="pluginHandler.pkgmanager.pkgRestartNow()"></div>';
            } else {
                x += '<div style="color:#888">La gestione degli aggiornamenti del plugin è riservata agli amministratori completi del server.</div>';
            }
            x += '<div id="pkgmanagerMsg" style="margin-top:10px;color:#888"></div>';
            if (adm) {
                // v2.2.0: SEZIONE 1 — BINARI DOWNLOADER (del PLUGIN)
                var bs = window.pkgmanagerBinStatus;
                var bx = '<div style="margin-top:12px"><b>Binari del downloader</b> <span style="color:#888;font-size:12px">(compilati, per «Esporta downloader» — airgap senza Python)</span> <input type=button value="Verifica/ritenta" onclick="pluginHandler.pkgmanager.pkgBinStatusRequest()"> <input type=button value="Ritenta installazione" onclick="pluginHandler.pkgmanager.pkgBinRetry()" title="Azzera il contatore tentativi e rilancia il download/estrazione"></div>';
                if (bs == null) {
                    bx += '<div style="color:#888;font-size:12px;margin-top:4px">Stato non ancora caricato — premi «Verifica/ritenta».</div>';
                } else {
                    var miss = (bs.missing || []);
                    bx += '<div style="font-size:13px;margin-top:4px">' + (bs.busy ? '<b>download/estrazione in corso…</b>' : '') + 'Piattaforme presenti: <b>' + (7 - miss.length) + '/7</b>' + ((miss.length > 0) ? ' — mancanti: ' + EscapeHtml(miss.join(', ')) : ' ✓') + ((bs.attempts > 0) ? (' — tentativi: ' + bs.attempts) : '') + '</div>';
                    if (bs.lastError != null) { bx += '<div style="color:#b00;font-size:12px;margin-top:2px">Ultimo errore: ' + EscapeHtml(bs.lastError) + '</div>'; }
                    bx += '<div style="color:#888;font-size:12px;margin-top:2px">Sorgente: ' + EscapeHtml(bs.url || '') + '</div>';
                    bx += '<div style="color:#888;font-size:12px">Cartella: ' + EscapeHtml(bs.dir || '') + '/ (' + ((bs.files || []).length) + ' file)</div>';
                    if ((bs.files != null) && (bs.files.length > 0)) {
                        bx += '<table style="width:100%;font-size:12px;border-collapse:collapse;margin-top:4px">';
                        for (var bi = 0; bi < bs.files.length; bi++) {
                            var bf = bs.files[bi];
                            bx += '<tr><td style="padding:1px 6px">' + EscapeHtml(bf.name) + '</td><td style="padding:1px 6px;text-align:right;color:#888">' + Math.round((bf.size || 0) / 1048576) + ' MiB</td></tr>';
                        }
                        bx += '</table>';
                    }
                }
                x += '<div style="border:1px solid #eee;border-radius:6px;padding:8px 10px;margin-top:12px">' + bx + '</div>';
                // SEZIONE 2 — BINARI AGENTE (CORE MESHCENTRAL)
                var ab = window.pkgmanagerAgentBuild;
                var coreBtn = '<div style="margin-top:12px"><b>Binari agente (core MeshCentral)</b> <span style="color:#888;font-size:12px">— i meshcore/meshagent che il server scarica dai release GitHub verificati (agentbuilds)</span> <input type=button value="Aggiorna stato" onclick="pluginHandler.pkgmanager.pkgAgentBuildRequest()"></div>';
                if (ab == null) {
                    x += '<div style="border:1px solid #eee;border-radius:6px;padding:8px 10px;margin-top:6px">' + coreBtn + '<div style="color:#888;font-size:12px;margin-top:4px">Stato non ancora caricato — premi «Aggiorna stato».</div></div>';
                } else {
                var core = ab.core;
                var st = '';
                if (core == null) { st = '<span style="color:#888">Stato agentDefaults non disponibile su questa versione di MeshCentral (core senza agentbuilds.js).</span>'; }
                else {
                    st = 'Download agentDefaults: ' + (core.busy ? '<b>in corso</b>' : 'fermo') + ' — abilitato: ' + (core.enabled ? 'sì' : 'NO') + ' — errori: ' + (core.errors.length);
                    if ((core.errors != null) && (core.errors.length > 0)) { for (var ei = 0; ei < core.errors.length; ei++) { st += '<div style="color:#b00;font-size:12px">• ' + EscapeHtml(core.errors[ei]) + '</div>'; } }
                    var fl = (core.files || []);
                    st += '<table style="width:100%;font-size:12px;border-collapse:collapse;margin-top:6px">';
                    for (var fi = 0; fi < fl.length; fi++) {
                        var f = fl[fi];
                        var bar = '';
                        var pct = null;
                        if (f.status === 'Downloading') { pct = ((f.received || 0) / Math.max(1, f.size || 1)) * 100; }
                        else if (f.status === 'Ready') { pct = 100; }
                        if (pct != null) { bar = '<div style="background:#eee;width:100px;display:inline-block;vertical-align:middle;height:10px;margin-right:6px"><div style="background:#2a7;height:10px;width:' + pct.toFixed(0) + '%"></div></div>'; }
                        var extra = (f.status === 'Downloading') ? (' ' + Math.round((f.received || 0) / 1048576) + '/' + Math.round((f.size || 0) / 1048576) + ' MiB') : '';
                        st += '<tr><td style="padding:1px 6px">' + EscapeHtml(f.filename || '?') + '</td><td style="padding:1px 6px;white-space:nowrap">' + bar + EscapeHtml(f.status || '?') + extra + (f.error ? ' <span style="color:#b00">' + EscapeHtml(f.error) + '</span>' : '') + '</td></tr>';
                    }
                    st += '</table>';
                    if (fl.length == 0) { st += '<div style="color:#888;font-size:12px">Nessun file nel manifest agentbuilds (nessun download atteso).</div>'; }
                }
                // stato disco
                for (var di = 0; di < (ab.disk || []).length; di++) {
                    var d = ab.disk[di];
                    var tot = 0, n = 0;
                    for (var pi = 0; pi < d.items.length; pi++) { if (!d.items[pi].dir) { n++; tot += d.items[pi].size || 0; } }
                    st += '<div style="margin-top:6px;font-size:12px;color:#888">' + EscapeHtml(d.dir) + '/: ' + n + ' file, ' + Math.round(tot / 1048576) + ' MiB</div>';
                }
                x += '<div style="border:1px solid #eee;border-radius:6px;padding:8px 10px;margin-top:6px">' + coreBtn + '<div style="margin-top:6px">' + st + '</div></div>';
                }
                // SEZIONE 3 — LOG DEL PLUGIN
                var lt = window.pkgmanagerLogTail;
                var logX = '<div style="margin-top:12px"><b>Log del plugin</b> <span style="color:#888;font-size:12px">(ultime righe; file completo: pkgmanager.log in datapath/plugins/pkgmanager)</span> <input type=button value="Aggiorna" onclick="pluginHandler.pkgmanager.pkgLogTailRequest()"></div>';
                logX += '<pre style="background:#111;color:#cde;font-size:11px;padding:8px;border-radius:6px;max-height:320px;overflow:auto;margin-top:6px">' + (((lt != null) && (lt.lines != null)) ? EscapeHtml(lt.lines.join('\n')) : 'Premi «Aggiorna» per caricare le ultime righe.') + '</pre>';
                x += logX;
            }
            x += '<div style="margin-top:14px;color:#888;font-size:12px">Canali di aggiornamento: <b>online</b> (il server scarica dal sorgente configurato in config.json) oppure <b>file</b> (airgap: carichi il pkgmanager.js nuovo da qui). In alternativa la scheda «Plugins» di My Server gestisce l\'upgrade dallo zip dichiarato in downloadUrl.</div>';
            m.innerHTML = x;
        } catch (e) { console.log('pkgmanager osplugin render failed: ' + e); }
    };

    obj.pkgOsAdminOpen = function () {
        try {
            var w = document.getElementById('pkgmanagerMainWrap');
            if (w == null) return;
            try {
                if ((typeof xxcurrentView == 'number') && (xxcurrentView >= 0) && (xxcurrentView <= 60)) { QV('p' + xxcurrentView, false); }
                xxcurrentView = -1;
            } catch (e) { }
            w.style.display = '';
            window.pkgmanagerView = 'osadmin';
            window.pkgmanagerAdminMsg = '';
            pluginHandler.pkgmanager.pkgTabSetActive('osadmin');
            var b = document.getElementById('LeftMenuPackages');
            if (b != null) b.style.opacity = '';
            var bo = document.getElementById('LeftMenuOsUpdates');
            if (bo != null) bo.style.opacity = '1';
            pluginHandler.pkgmanager.pkgAdminRender();
            pluginHandler.pkgmanager.pkgOsStoreRequest(); // v2.1.0
        } catch (e) { console.log('pkgmanager os admin open failed: ' + e); }
    };

    // v2.1.0: STORE VIEW — elenco, filtro ed eliminazione dei file scaricati
    // (store/os-updates-<codename>/). Delete: POST /pkgstore.ashx?op=del
    // (già esistente, admin-only) + refresh lista.
    obj.pkgOsStoreRequest = function () {
        try { meshserver.send({ action: 'plugin', plugin: 'pkgmanager', pluginaction: 'osstorelist' }); } catch (e) { }
    };
    obj.pkgOsStoreList = function (server, message) {
        try {
            if ((message != null) && (message.store != null)) { window.pkgmanagerOsStore = { store: message.store }; } // v2.1.5: il render legge .store
            if (window.pkgmanagerView == 'osadmin') { pluginHandler.pkgmanager.pkgAdminRender(); }
        } catch (e) { console.log('pkgmanager osstorelist recv failed: ' + e); }
    };
    obj.pkgOsStoreSelChange = function () {
        try { var s2 = document.getElementById('pkgmanagerOsStoreSel'); if (s2 != null) { window.pkgmanagerOsStoreSel = s2.value; } pluginHandler.pkgmanager.pkgAdminRender(); } catch (e) { }
    };
    obj.pkgOsStoreDel = function (dir, file) {
        try {
            if (!confirm('Eliminare ' + file + ' dallo store? I bundle che lo referenziano lo segnaleranno come mancante.')) { return; }
            fetch('/pkgstore.ashx?op=del&p=' + encodeURIComponent(dir + '/' + file), { method: 'POST' })
                .then(function (r) { return r.json(); })
                .then(function (j) {
                    if (j.ok) { pluginHandler.pkgmanager.pkgOsStoreRequest(); window.pkgmanagerAdminMsg = 'File eliminato: ' + file; }
                    else { pluginHandler.pkgmanager.pkgAdminStatus('Eliminazione negata: ' + EscapeHtml(String(j.error || ''))); }
                })
                .catch(function (e2) { pluginHandler.pkgmanager.pkgAdminStatus('Eliminazione fallita: ' + e2); });
        } catch (e) { }
    };

    // v1.6.1: «Importa manifest…» — reads a meshos-fetch manifest.json in the
    // browser, asks the bundle id (the store folder the files were copied
    // into) and sends it to the server, which verifies every file and
    // builds+ saves the kind:'os' bundle through the normal save path.
    obj.pkgOsImportManifest = function () {
        try {
            var inp = document.getElementById('pkgOsManifestFile');
            if (inp == null) {
                inp = document.createElement('input');
                inp.type = 'file';
                inp.id = 'pkgOsManifestFile';
                inp.style.display = 'none';
                inp.accept = '.json,application/json';
                document.body.appendChild(inp);
                inp.addEventListener('change', function () { pluginHandler.pkgmanager.pkgOsImportManifest(); });
            }
            if (inp.value == '') { inp.click(); return; }
            var f = (inp.files != null) ? inp.files[0] : null;
            inp.value = '';
            if (f == null) return;
            f.text().then(function (txt) {
                var man = null;
                try { man = JSON.parse(txt); } catch (e) { pluginHandler.pkgmanager.pkgAdminStatus('Manifest non JSON: ' + e); return; }
                if ((man == null) || (Array.isArray(man.files) !== true) || (man.files.length === 0)) { pluginHandler.pkgmanager.pkgAdminStatus('Manifest non valido: serve files[] non vuoto (generato da meshos-fetch).'); return; }
                var pid = prompt('ID del bundle OS (cartella dello store in cui hai copiato i file, es. os-updates):', 'os-updates');
                if ((pid == null) || (String(pid).trim() == '')) { pluginHandler.pkgmanager.pkgAdminStatus('Import annullato.'); return; }
                var nm = prompt('Nome del bundle (mostrato nelle liste):', 'Aggiornamenti OS importati');
                if ((nm == null) || (String(nm).trim() == '')) nm = 'Aggiornamenti OS';
                meshserver.send({ action: 'plugin', plugin: 'pkgmanager', pluginaction: 'importmanifest', pkgid: String(pid).trim(), name: String(nm).trim(), manifest: man });
                pluginHandler.pkgmanager.pkgAdminStatus('Import manifest: ' + man.files.length + ' file — verifica file nello store e salvataggio in corso…');
            });
        } catch (e) { pluginHandler.pkgmanager.pkgAdminStatus('Import fallito: ' + e); }
    };

    obj.pkgAdminOpen = function () {
        try {
            var w = document.getElementById('pkgmanagerMainWrap');
            if (w == null) return;
            try {
                if ((typeof xxcurrentView == 'number') && (xxcurrentView >= 0) && (xxcurrentView <= 60)) { QV('p' + xxcurrentView, false); }
                xxcurrentView = -1;
            } catch (e) { }
            w.style.display = '';
            window.pkgmanagerView = 'admin';
            window.pkgmanagerAdminMsg = '';
            pluginHandler.pkgmanager.pkgTabSetActive('admin');
            var b = document.getElementById('LeftMenuPackages');
            if (b != null) b.style.opacity = '1';
            pluginHandler.pkgmanager.pkgAdminRender();
        } catch (e) { console.log('pkgmanager admin open failed: ' + e); }
    };

    obj.pkgAdminRefresh = function () {
        try {
            window.pkgmanagerAdminMsg = '';
            pluginHandler.pkgmanager.pkgRequestList();
            pluginHandler.pkgmanager.pkgAdminStatus('Ricarico catalogo…');
        } catch (e) { }
    };

    // ---- "Creazione pacchetti" (full site admins) ----
    // ENTRY ONLY for now (user request): the guided package builder lands in
    // a later version; the tab opens a placeholder page so the flow exists
    // end-to-end and the label sits in the gray bar as requested.
    obj.pkgCreateOpen = function () {
        try {
            var w = document.getElementById('pkgmanagerMainWrap');
            if (w == null) return;
            try {
                if ((typeof xxcurrentView == 'number') && (xxcurrentView >= 0) && (xxcurrentView <= 60)) { QV('p' + xxcurrentView, false); }
                xxcurrentView = -1;
            } catch (e) { }
            w.style.display = '';
            window.pkgmanagerView = 'create';
            // v1.5.0: entering the packages wizard with a pending OS draft
            // would prefill Categoria=os — start clean instead.
            if ((window.pkgmanagerDraftBase != null) && (window.pkgmanagerDraftBase.kind === 'os')) { window.pkgmanagerDraft = {}; window.pkgmanagerDraftBase = null; }
            window.pkgmanagerAdminMsg = '';
            if (window.pkgmanagerCatalog == null) { meshserver.send({ action: 'plugin', plugin: 'pkgmanager', pluginaction: 'list' }); }
            pluginHandler.pkgmanager.pkgTabSetActive('create');
            var b = document.getElementById('LeftMenuPackages');
            if (b != null) b.style.opacity = '1';
            pluginHandler.pkgmanager.pkgCreateRender();
        } catch (e) { console.log('pkgmanager create open failed: ' + e); }
    };

    obj.pkgCreateRender = function () {
        try {
            var m = document.getElementById('pkgmanagerMain');
            if (m == null) return;
            var isOsC = pluginHandler.pkgmanager.pkgIsOsView();
            var x = '<div style="margin-bottom:8px;font-size:16px"><b>' + (isOsC ? 'Creazione aggiornamenti OS' : 'Creazione pacchetti') + '</b> — wizard guidato</div>';
            x += '<div style="color:#888;padding:4px 0 10px 0">Costruisci un pacchetto airgap da un\'unica maschera: scegli il sistema operativo dal menu a discesa come le altre opzioni, carica l\'artefatto e genera il comando con i preset (download dal server in LAN + verifica SHA-384 + installazione locale). Il device non usa internet. Le definizioni salvate per gli altri OS restano nel pacchetto.</div>';
            x += '<div style="border:1px solid #ccc;border-radius:6px;padding:10px;margin-bottom:10px">';
            x += '<table style="border-collapse:collapse">';
            x += '<tr><td style="padding:4px">ID</td><td style="padding:4px"><input type=text id=pkgfId style=width:280px oninput="pluginHandler.pkgmanager.pkgCreateCheckId();pluginHandler.pkgmanager.pkgCreateDraftSync()"> <span id=pkgfIdHint style="color:#888"></span></td></tr>';
            x += '<tr><td style="padding:4px">Nome</td><td style="padding:4px"><input type=text id=pkgfName style=width:280px oninput="pluginHandler.pkgmanager.pkgCreateDraftSync()"></td></tr>';
            x += '<tr><td style="padding:4px">Descrizione</td><td style="padding:4px"><input type=text id=pkgfDesc style=width:420px oninput="pluginHandler.pkgmanager.pkgCreateDraftSync()"></td></tr>';
            x += '<tr><td style="padding:4px">Categoria</td><td style="padding:4px"><select id=pkgfKind style=width:280px onchange="pluginHandler.pkgmanager.pkgCreateDraftSync()"><option value="">Applicazione (gestione pacchetti)</option></select> <span style="color:#888;font-size:12px">gli aggiornamenti OS non si creano a mano: nascono dalla scansione con «Scarica aggiornamenti» (voce «Aggiornamenti OS»)</span></td></tr>';
            x += '<tr><td style="padding:4px">Sistema operativo</td><td style="padding:4px"><select id=pkgfOs onchange="pluginHandler.pkgmanager.pkgCreateOsChange()"><option value=linux selected>Linux</option><option value=windows>Windows</option><option value=macos>macOS</option></select> <span id=pkgfOsHint style="color:#888"></span></td></tr>';
            x += '<tr><td style="padding:4px">Artefatto (file nello store)</td><td style="padding:4px"><input type=text id=pkgfArt style=width:280px oninput="pluginHandler.pkgmanager.pkgCreateDraftSync()"> <input type=button value="Carica artefatto…" onclick="pluginHandler.pkgmanager.pkgCreateUpload()"> <input type=button value="Elimina artefatto" onclick="pluginHandler.pkgmanager.pkgCreateArtifactDel()"></td></tr>';
            x += '<tr><td style="padding:4px">Tipo comando</td><td style="padding:4px"><select id=pkgfType onchange="pluginHandler.pkgmanager.pkgCreateDraftSync()"><option value=3>Shell (Linux/macOS)</option><option value=1>cmd.exe (Windows)</option><option value=2>PowerShell (Windows)</option></select> · Timeout (s): <input type=text id=pkgfTo style=width:70px value=300 oninput="pluginHandler.pkgmanager.pkgCreateDraftSync()"></td></tr>';
            x += '</table>';
            x += '<div style="padding:4px 0">Comando: <input type=button value="Preset airgap" onclick="pluginHandler.pkgmanager.pkgCreatePreset()"> <input type=button value="Inserisci {{url}}" onclick="pluginHandler.pkgmanager.pkgCreateInsert(\'url\')"> <input type=button value="Inserisci {{sha384}}" onclick="pluginHandler.pkgmanager.pkgCreateInsert(\'sha384\')"></div>';
            x += '<textarea id="pkgfCmd" style="width:640px;height:80px;font-family:monospace" oninput="pluginHandler.pkgmanager.pkgCreateDraftSync()"></textarea>';
            x += '<div style="padding:4px 0">Comando di disinstallazione (' + (pluginHandler.pkgmanager.pkgIsOsView() ? 'consigliata, opzionale per gli aggiornamenti OS — generata dal preset quando automatizzabile' : 'obbligatoria — generata dal preset o scritta a mano') + '; eseguita dal tasto «Elimina selezionati»):</div>';
            x += '<textarea id="pkgfUn" style="width:640px;height:50px;font-family:monospace" oninput="pluginHandler.pkgmanager.pkgCreateDraftSync()"></textarea></div>';
            x += '<div style="margin-top:6px"><input type=button value="Salva pacchetto" onclick="pluginHandler.pkgmanager.pkgCreateSave()"> <input type=file id="pkgfFile" style="display:none"></div>';
            x += '<div id="pkgadminStatus" style="margin-top:6px;color:#888"></div>';
            m.innerHTML = x;
            // Restore the draft: tab re-open re-renders, typed data lives in memory.
            var db = window.pkgmanagerDraftBase;
            if (db != null) { Q('pkgfId').value = db.id || ''; Q('pkgfName').value = db.name || ''; Q('pkgfDesc').value = db.desc || ''; Q('pkgfKind').value = db.kind || ''; }
            var osCur = window.pkgmanagerDraftOs || 'linux';
            Q('pkgfOs').value = osCur;
            var dd = ((window.pkgmanagerDraft != null) ? window.pkgmanagerDraft[osCur] : null);
            Q('pkgfArt').value = ((dd != null) ? (dd.art || '') : '');
            Q('pkgfType').value = ((dd != null) && (dd.type != null)) ? dd.type : pluginHandler.pkgmanager.pkgCreateDefaultType(osCur);
            Q('pkgfTo').value = ((dd != null) && (dd.to != null)) ? dd.to : '300';
            Q('pkgfCmd').value = ((dd != null) && (dd.cmd != null)) ? dd.cmd : '';
            Q('pkgfUn').value = ((dd != null) && (dd.un != null)) ? dd.un : '';
            pluginHandler.pkgmanager.pkgCreateCheckId();
            pluginHandler.pkgmanager.pkgCreateOsHint();
        } catch (e) { console.log('pkgmanager create render failed: ' + e); }
    };

    // ---- v0.9.0 single-form wizard state ----
    // The OS dropdown swaps artifact/type/timeout/command fields; a per-OS
    // draft in window.pkgmanagerDraft (plus window.pkgmanagerDraftBase for
    // id/name/desc) means switching OS — or leaving the page and coming
    // back — never loses what was typed. Every input syncs the draft.
    obj.pkgCreateCurOs = function () { try { return String(Q('pkgfOs').value || 'linux'); } catch (e) { return 'linux'; } };
    obj.pkgCreateDefaultType = function (os) { return (os == 'windows') ? '1' : '3'; };
    obj.pkgCreateFieldSync = function (os) {
        try {
            if (window.pkgmanagerDraft == null) { window.pkgmanagerDraft = {}; }
            window.pkgmanagerDraft[os] = { art: Q('pkgfArt').value.trim(), type: String(Q('pkgfType').value), to: Q('pkgfTo').value.trim(), cmd: Q('pkgfCmd').value, un: Q('pkgfUn').value, kind: Q('pkgfKind').value };
        } catch (e) { }
    };
    // Sync base fields + the current-OS draft. Wizard-only: a no-op in the
    // management view (its form shares the pkgf* ids but must NOT pollute
    // the wizard draft).
    obj.pkgCreateDraftSync = function () {
        try {
            if (window.pkgmanagerView !== 'create') return;
            pluginHandler.pkgmanager.pkgCreateFieldSync(pluginHandler.pkgmanager.pkgCreateCurOs());
            window.pkgmanagerDraftBase = { id: Q('pkgfId').value.trim(), name: Q('pkgfName').value, desc: Q('pkgfDesc').value, kind: Q('pkgfKind').value };
        } catch (e) { }
    };
    obj.pkgCreateOsChange = function () {
        try {
            var prev = window.pkgmanagerDraftOs || 'linux';
            pluginHandler.pkgmanager.pkgCreateFieldSync(prev);
            var os = pluginHandler.pkgmanager.pkgCreateCurOs();
            var d = ((window.pkgmanagerDraft != null) ? window.pkgmanagerDraft[os] : null);
            Q('pkgfArt').value = ((d != null) ? (d.art || '') : '');
            Q('pkgfType').value = ((d != null) && (d.type != null)) ? d.type : pluginHandler.pkgmanager.pkgCreateDefaultType(os);
            Q('pkgfTo').value = ((d != null) && (d.to != null)) ? d.to : '300';
            Q('pkgfCmd').value = ((d != null) && (d.cmd != null)) ? d.cmd : '';
            Q('pkgfUn').value = ((d != null) && (d.un != null)) ? d.un : '';
            window.pkgmanagerDraftOs = os;
            pluginHandler.pkgmanager.pkgCreateOsHint();
        } catch (e) { }
    };
    obj.pkgCreateOsHint = function () {
        try {
            var h = document.getElementById('pkgfOsHint');
            if (h == null) return;
            var pid = Q('pkgfId').value.trim();
            var saved = {};
            var cat = window.pkgmanagerCatalog;
            for (var i = 0; i < ((cat != null) ? cat.packages.length : 0); i++) { if (cat.packages[i].id == pid) { var p = cat.packages[i]; if (p.linux != null) { saved.linux = 1; } if (p.windows != null) { saved.windows = 1; } if (p.macos != null) { saved.macos = 1; } break; } }
            var parts = [];
            var oses = [['linux', 'Linux'], ['windows', 'Windows'], ['macos', 'macOS']];
            for (var k = 0; k < oses.length; k++) {
                var os = oses[k][0];
                if ((window.pkgmanagerDraft != null) && (window.pkgmanagerDraft[os] != null) && (window.pkgmanagerDraft[os].cmd != null) && (window.pkgmanagerDraft[os].cmd != '')) { parts.push(oses[k][1] + ': bozza'); }
                else if (saved[os] != null) { parts.push(oses[k][1] + ': salvato'); }
            }
            h.innerText = parts.length ? ('Definizioni: ' + parts.join(' · ')) : '';
        } catch (e) { }
    };
    obj.pkgCreateUpload = function () {
        try {
            var f = document.getElementById('pkgfFile');
            if (f == null) return;
            f.value = '';
            var os = pluginHandler.pkgmanager.pkgCreateCurOs();
            f.onchange = function () { pluginHandler.pkgmanager.pkgAdminUploadDo(os); };
            f.click();
        } catch (e) { }
    };
    obj.pkgCreateArtifactDel = function () {
        try { pluginHandler.pkgmanager.pkgAdminArtifactDel(pluginHandler.pkgmanager.pkgCreateCurOs()); } catch (e) { }
    };
    // Single-form save: MERGE, never replace. Payload = every drafted OS
    // def + every def already saved in the catalog for this ID (untouched
    // OSes must survive: the server-side save replaces the whole record).
    obj.pkgCreateSave = function () {
        try {
            var pid = Q('pkgfId').value.trim();
            if (!/^[a-zA-Z0-9._-]+$/.test(pid)) { pluginHandler.pkgmanager.pkgAdminStatus('ID non valido (lettere, numeri, . _ -).'); return; }
            var name = Q('pkgfName').value.trim();
            if (name == '') { pluginHandler.pkgmanager.pkgAdminStatus('Nome mancante.'); return; }
            var os = pluginHandler.pkgmanager.pkgCreateCurOs();
            pluginHandler.pkgmanager.pkgCreateFieldSync(os);
            window.pkgmanagerDraftBase = { id: pid, name: name, desc: Q('pkgfDesc').value };
            var pkg = { id: pid, name: name, description: Q('pkgfDesc').value, kind: Q('pkgfKind').value };
            for (var k in window.pkgmanagerDraft) {
                var d = window.pkgmanagerDraft[k];
                if ((k == 'linux') || (k == 'windows') || (k == 'macos')) {
                    if ((d != null) && (d.cmd != null) && (d.cmd.trim() != '')) {
                        var def = { type: (parseInt(d.type) || pluginHandler.pkgmanager.pkgCreateDefaultType(k)), cmd: d.cmd.trim() };
                        var to = parseInt(d.to); if (to > 0) { def.timeout = to; }
                        if ((d.art != null) && (d.art.trim() != '')) {
                            // v1.3.0: a multi-name field builds a bundle list.
                            var an = d.art.trim().split(/[\s,]+/).filter(function (x) { return x != ''; });
                            if (an.length > 1) { def.artifacts = an; } else { def.artifact = an[0]; }
                        }
                        if ((d.un != null) && (d.un.trim() != '')) { def.uninstall = d.un.trim(); }
                        if ((d.kind != null) && (String(d.kind).trim() != '')) { def.kind = String(d.kind).trim(); }
                        pkg[k] = def;
                    }
                }
            }
            var cat = window.pkgmanagerCatalog;
            for (var i = 0; i < ((cat != null) ? cat.packages.length : 0); i++) {
                if (cat.packages[i].id == pid) {
                    var oses2 = ['linux', 'windows', 'macos'];
                    for (var j = 0; j < oses2.length; j++) {
                        var o2 = oses2[j];
                        if ((pkg[o2] == null) && (cat.packages[i][o2] != null)) { pkg[o2] = cat.packages[i][o2]; }
                    }
                    break;
                }
            }
            if ((pkg.linux == null) && (pkg.windows == null) && (pkg.macos == null)) { pluginHandler.pkgmanager.pkgAdminStatus('Compila il comando per il sistema operativo selezionato prima di salvare.'); return; }
            var osesChk = ['linux', 'windows', 'macos'];
            for (var c2 = 0; c2 < osesChk.length; c2++) {
                var d2 = pkg[osesChk[c2]];
                if ((d2 != null) && (d2.uninstall == null) && (String(d2.kind || '') != 'os')) { pluginHandler.pkgmanager.pkgAdminStatus('Comando di disinstallazione mancante per ' + osesChk[c2] + ' — generane uno col preset o scrivilo a mano (è obbligatorio come l\'installazione).'); return; }
            }
            // v1.9.10: al catalogo che conferma il salvataggio il wizard si
            // azzera (campi + draft) — pronto per un pacchetto nuovo senza
            // ritrovarsi l'ID gia esistente. Se il server risponde con errore
            // i campi restano compilati.
            window.pkgmanagerCreateSaved = pid;
            meshserver.send({ action: 'plugin', plugin: 'pkgmanager', pluginaction: 'save', pkg: pkg });
            pluginHandler.pkgmanager.pkgAdminStatus('Salvataggio…');
            pluginHandler.pkgmanager.pkgCreateOsHint();
        } catch (e) { pluginHandler.pkgmanager.pkgAdminStatus('Errore: ' + e); }
    };

    // Airgap command preset for one OS, chosen by the artifact extension:
    // download from THIS server over LAN ({{url}}), SHA-384 verification
    // ({{sha384}}), then the local install step. The generated command is a
    // starting point — the admin can edit it before saving.
    // v1.3.0: bundle preset — the artifact field accepts a space/comma
    // separated list of store files (OS-update bundles: multiple .deb/.rpm,
    // .msu/.cab, .pkg). Every file gets its own LAN download + SHA-384
    // verification with an INDEXED placeholder ({{url:N}}/{{sha384:N}});
    // single-file packages also keep the legacy {{url}}/{{sha384}} (= N 1).
    // Installers run chained in one command; the per-extension uninstall
    // covers every file where it is automatable.
    obj.pkgCreatePreset = function (os) {
        try {
            if (os == null) { os = pluginHandler.pkgmanager.pkgCreateCurOs(); }
            var field = Q('pkgfArt').value.trim();
            var names = field.split(/[\s,]+/).filter(function (x) { return x != ''; });
            if (names.length == 0) { names = ['pacchetto']; }
            var parts = [], insts = [], uns = [], manualUn = false;
            for (var i = 0; i < names.length; i++) {
                var a = names[i];
                var dot = a.lastIndexOf('.');
                var b = ((dot > 0) ? a.slice(0, dot) : a);
                var e = ((dot > 0) ? a.slice(dot + 1).toLowerCase() : '');
                var idx = i + 1;
                if (os == 'linux') {
                    parts.push("curl -kfsSL -o /tmp/" + a + " '{{url:" + idx + "}}' && echo '{{sha384:" + idx + "}}  /tmp/" + a + "' | sha384sum -c -");
                    if (e == 'deb') { insts.push('sudo -n dpkg -i /tmp/' + a); uns.push('sudo -n dpkg -r ' + b); }
                    else if (e == 'rpm') { insts.push('sudo -n rpm -Uvh --force /tmp/' + a); uns.push('sudo -n rpm -e ' + b); }
                    else if (e == 'apk') { insts.push('sudo -n apk add --allow-untrusted /tmp/' + a); uns.push('sudo -n apk del ' + b); }
                    else { insts.push('sh /tmp/' + a); manualUn = true; }
                } else if (os == 'windows') {
                    var dst = '"%TEMP%\\' + a + '"';
                    parts.push('curl -kfsSL -o ' + dst + ' "{{url:' + idx + '}}" && certutil -hashfile ' + dst + ' SHA384 | findstr /i "{{sha384:' + idx + '}}"');
                    if (e == 'msi') { insts.push('msiexec /i ' + dst + ' /qn'); uns.push('msiexec /x ' + dst + ' /qn'); }
                    else if (e == 'msu') { insts.push('wusa ' + dst + ' /quiet /norestart'); uns.push('wusa ' + dst + ' /uninstall /quiet /norestart'); }
                    else if (e == 'cab') { insts.push('dism /Online /Add-Package /PackagePath:' + dst + ' /NoRestart /Quiet'); manualUn = true; }
                    else { insts.push(dst + ' /S'); manualUn = true; }
                } else {
                    parts.push("curl -kfsSL -o /tmp/" + a + " '{{url:" + idx + "}}' && echo '{{sha384:" + idx + "}}  /tmp/" + a + "' | shasum -a 384 -c -");
                    if (e == 'pkg') { insts.push('sudo -n installer -pkg /tmp/' + a + ' -target /'); uns.push('sudo -n pkgutil --forget ' + b); }
                    else if (e == 'app') { insts.push('cp -R /tmp/' + a + ' /Applications/'); uns.push('sudo -n rm -rf "/Applications/' + b + '.app"'); }
                    else { insts.push('sh /tmp/' + a); manualUn = true; }
                }
            }
            var cmd = parts.join(' && ');
            if (insts.length > 0) { cmd += ' && ' + insts.join(' && '); }
            var un = uns.join(((os == 'windows') ? ' & ' : ' ; '));
            var unNote = ((manualUn) ? ' — disinstallazione non automatizzabile per alcuni file di questo elenco, completala a mano (è obbligatoria)' : '');
            Q('pkgfType').value = ((os == 'windows') ? '1' : '3');
            Q('pkgfCmd').value = cmd;
            Q('pkgfUn').value = un;
            pluginHandler.pkgmanager.pkgCreateDraftSync();
            pluginHandler.pkgmanager.pkgAdminDraftSync();
            if (window.pkgmanagerView == 'admin') { pluginHandler.pkgmanager.pkgAdminOsHint(); } else { pluginHandler.pkgmanager.pkgCreateOsHint(); }
            pluginHandler.pkgmanager.pkgAdminStatus('Preset ' + os + ' generato (' + names.length + ' file): download LAN + verifica SHA-384 per file + installazione' + ((un != '') ? ' + disinstallazione' : ' (solo installazione)') + ((field == '') ? ' (campo artefatto vuoto: usato "pacchetto" — compila e rigenera)' : '') + unNote + '. Controlla i comandi prima di salvare.');
        } catch (e) { pluginHandler.pkgmanager.pkgAdminStatus('Preset fallito: ' + e); }
    };

    // Insert {{url}} / {{sha384}} at the textarea cursor (not appended).
    obj.pkgCreateInsert = function (which) {
        try {
            var t = Q('pkgfCmd');
            var ph = (which == 'url') ? '{{url}}' : '{{sha384}}';
            var st = t.selectionStart; if (st == null) { st = t.value.length; }
            var en = t.selectionEnd; if (en == null) { en = st; }
            t.value = t.value.slice(0, st) + ph + t.value.slice(en);
            t.focus();
            t.selectionStart = (t.selectionEnd = (st + ph.length));
            pluginHandler.pkgmanager.pkgCreateDraftSync();
            pluginHandler.pkgmanager.pkgAdminDraftSync();
        } catch (e) { }
    };

    // Live ID check: pattern + duplicates against the current catalog.
    obj.pkgCreateCheckId = function () {
        try {
            var h = document.getElementById('pkgfIdHint');
            if (h == null) return;
            var pid = Q('pkgfId').value.trim();
            if (pid == '') { h.innerText = ''; return; }
            if (!/^[a-zA-Z0-9._-]+$/.test(pid)) { h.innerText = 'ID non valido (lettere, numeri, . _ -)'; h.style.color = '#a60'; return; }
            var cat = window.pkgmanagerCatalog;
            var dup = false;
            for (var i = 0; i < ((cat != null) ? cat.packages.length : 0); i++) { if (cat.packages[i].id == pid) { dup = true; break; } }
            if (dup) { h.innerText = 'ID già esistente — salvando lo AGGIORNERAI (per modifiche usa «Gestione pacchetti»)'; h.style.color = '#a60'; }
            else if (cat == null) { h.innerText = 'Verifica catalogo… (in arrivo)'; h.style.color = '#888'; }
            else { h.innerText = 'ID libero ✓'; h.style.color = '#080'; }
            pluginHandler.pkgmanager.pkgCreateOsHint();
        } catch (e) { }
    };

    // Catalog reply while the wizard is open: update ONLY acks and hints —
    // never re-render the form (a half-filled form must not be wiped).
    obj.pkgCreateCatalogArrived = function () {
        try {
            var msg = window.pkgmanagerAdminMsg;
            window.pkgmanagerAdminMsg = '';
            // v1.9.10: salvataggio riuscito -> wizard azzerato (campi vuoti,
            // nessun «ID gia esistente» al pacchetto successivo). Errore ->
            // i campi restano come li ha lasciati l'utente.
            if ((window.pkgmanagerCreateSaved != null) && (msg != null) && (msg.indexOf('Pacchetto salvato:') == 0)) {
                window.pkgmanagerCreateSaved = null;
                window.pkgmanagerDraft = {};
                window.pkgmanagerDraftBase = null;
                window.pkgmanagerDraftOs = null;
                pluginHandler.pkgmanager.pkgCreateRender();
                var st2 = document.getElementById('pkgadminStatus');
                if (st2 != null) { st2.innerText = msg + ' — campi azzerati, pronto per un nuovo pacchetto.'; st2.style.color = '#080'; }
                return;
            }
            window.pkgmanagerCreateSaved = null;
            if ((msg != null) && (msg != '')) {
                var st = document.getElementById('pkgadminStatus');
                if (st != null) { st.innerText = msg; st.style.color = '#080'; }
            }
            pluginHandler.pkgmanager.pkgCreateCheckId();
            pluginHandler.pkgmanager.pkgCreateOsHint();
        } catch (e) { }
    };

    obj.pkgAdminRender = function () {
        try {
            var m = document.getElementById('pkgmanagerMain');
            if (m == null) return;
            var cat = window.pkgmanagerCatalog;
            if ((cat == null) || (cat.packages == null)) { m.innerHTML = '<div style="color:#888">Caricamento catalogo…</div>'; return; }
            var isOs = pluginHandler.pkgmanager.pkgIsOsView();
            var x = '<div style="margin-bottom:8px;font-size:16px"><b>' + (isOs ? 'Gestione aggiornamenti OS' : 'Gestione pacchetti') + '</b> — ' + (isOs ? 'bundle OS airgap' : 'catalogo e artefatti airgap') + '</div>' + pluginHandler.pkgmanager.pkgBinBanner();
            // v2.1.0: filtro OS anche in modalità «Gestione aggiornamenti OS»
            x += '<div style="margin-bottom:8px">Sistema operativo: <select id="pkgmanagerAdminOsSel" onchange="pluginHandler.pkgmanager.pkgAdminOsFilter()" style="padding:3px 5px"><option value="all">Tutti</option><option value="linux">Linux</option><option value="windows">Windows</option><option value="macos">macOS</option></select> <span id="pkgmanagerAdminOsCount" style="color:#888;font-size:12px"></span></div>';
            // v1.9.13: i tasti «Aggiorna plugin» sono spostati nella scheda
            // «Aggiorna plugin» del menu Aggiornamenti OS (pkgOsPluginRender).
            x += '<div style="margin-bottom:8px">' + (isOs ? '' : '<input type=button value="Aggiungi pacchetto" onclick="pluginHandler.pkgmanager.pkgAdminAdd()"> ') + '<input type=button value="Ricarica catalogo" onclick="pluginHandler.pkgmanager.pkgAdminRefresh()"> ' + (isOs ? '<input type=button value="Ricarica store" onclick="pluginHandler.pkgmanager.pkgOsStoreRequest()" title="Ricarica l elenco dei file scaricati in store/os-updates-*"> <input type=button value="Importa manifest…" title="Importa un manifest.json generato da meshos-fetch (i file devono essere gia stati copiati nello store del server)" onclick="pluginHandler.pkgmanager.pkgOsImportManifest()">' : '') + '</div>';
            if ((window.pkgmanagerAdminMsg != null) && (window.pkgmanagerAdminMsg != '')) { x += '<div style="margin-bottom:8px;color:#080">' + EscapeHtml(window.pkgmanagerAdminMsg) + '</div>'; }
            // v2.1.0: SEZIONE STORE (solo modalità os) — i pacchetti scaricati
            // da «Scarica i mancanti» o copiati per airgap, con filtro per
            // release ed eliminazione SINGOLA.
            if (isOs) {
                var storeL = ((window.pkgmanagerOsStore != null) ? (window.pkgmanagerOsStore.store || []) : null);
                if (storeL == null) { pluginHandler.pkgmanager.pkgOsStoreRequest(); }
                var totalFiles = 0; if (storeL != null) { for (var sd2 = 0; sd2 < storeL.length; sd2++) { totalFiles += storeL[sd2].files.length; } }
                x += '<div style="margin-bottom:6px;margin-top:6px"><b>Pacchetti scaricati nello store</b> — <span style="color:#888">' + ((storeL != null) ? (storeL.length + ' release, ' + totalFiles + ' file (store/os-updates-*)') : 'caricamento…') + '</span></div>';
                if ((storeL != null) && (storeL.length > 0)) {
                    if (window.pkgmanagerOsStoreSel == null) { window.pkgmanagerOsStoreSel = 'all'; }
                    x += '<div style="margin-bottom:6px">Release: <select id="pkgmanagerOsStoreSel" onchange="pluginHandler.pkgmanager.pkgOsStoreSelChange()" style="padding:3px 5px">';
                    x += '<option value="all"' + (window.pkgmanagerOsStoreSel == 'all' ? ' selected' : '') + '>Tutte</option>';
                    for (var sd3 = 0; sd3 < storeL.length; sd3++) {
                        var dname = storeL[sd3].dir;
                        x += '<option value="' + EscapeHtml(dname) + '"' + (window.pkgmanagerOsStoreSel == dname ? ' selected' : '') + '>' + EscapeHtml(dname.slice('os-updates-'.length)) + ' (' + storeL[sd3].files.length + ' file)</option>';
                    }
                    x += '</select></div>';
                    for (var sd4 = 0; sd4 < storeL.length; sd4++) {
                        var dl = storeL[sd4];
                        if ((window.pkgmanagerOsStoreSel != 'all') && (window.pkgmanagerOsStoreSel != dl.dir)) { continue; }
                        x += '<div style="margin-bottom:6px;padding:6px;border:1px solid #ddd;border-radius:4px"><b>' + EscapeHtml(dl.dir.slice('os-updates-'.length)) + '</b> <span style="color:#888;font-size:12px">(' + dl.files.length + ' file — store/' + EscapeHtml(dl.dir) + '/)</span>';
                        x += '<table style="border-collapse:collapse;width:100%;margin-top:4px">';
                        x += '<tr style="text-align:left;border-bottom:1px solid #eee"><th style="padding:3px">File</th><th style="padding:3px">Dim.</th><th style="padding:3px"></th></tr>';
                        for (var fj2 = 0; fj2 < dl.files.length; fj2++) {
                            var fli = dl.files[fj2];
                            x += '<tr style="border-bottom:1px solid #f4f4f4"><td style="padding:3px;font-size:12px;word-break:break-all">' + EscapeHtml(fli.file) + '</td><td style="padding:3px;color:#888;font-size:12px">' + Math.round(fli.size / 1024) + 'KB</td><td style="padding:3px"><input type=button value="Elimina" onclick="pluginHandler.pkgmanager.pkgOsStoreDel(\'' + EscapeHtml(dl.dir) + '\',\'' + EscapeHtml(fli.file) + '\')"></td></tr>';
                        }
                        x += '</table></div>';
                    }
                }
            }
            x += '<div style="margin-bottom:6px;margin-top:10px"><b>' + (isOs ? 'Bundle OS (manifest airgap importati)' : 'Catalogo pacchetti') + '</b></div>';
            x += '<div style="max-height:420px;overflow:auto">'; // v2.2.6: piano scrollabile
            x += '<table style="border-collapse:collapse;width:100%">';
            x += '<tr style="text-align:left;border-bottom:1px solid #ccc"><th style="padding:4px">Pacchetto</th><th style="padding:4px">Definizioni OS / artefatto</th><th style="padding:4px">Azioni</th></tr>';
            var oses = ['linux', 'windows', 'macos'];
            // v1.9.5: filtro OS (stato, non DOM: al primo render la select non esiste ancora)
            var af = (window.pkgmanagerAdminOsVal == null) ? 'all' : String(window.pkgmanagerAdminOsVal); // v2.1.0: filtro anche in modalità os
            var aShown = 0, aTotal = 0;
            for (var i = 0; i < cat.packages.length; i++) {
                var p = cat.packages[i];
                if (isOs !== (pluginHandler.pkgmanager.pkgOsKind(p) == 'os')) continue; // v1.5.0: per-bar filtering
                aTotal++;
                if ((af != 'all') && (p[af] == null)) continue; // v1.9.5: solo pacchetti con definizione per l'OS scelto
                aShown++;
                var defs = '';
                for (var k = 0; k < oses.length; k++) {
                    var def = p[oses[k]];
                    if (def == null) continue;
                    var art = '—';
                    if (def.artifact != null) {
                        art = ((def.artifactMissing === true)
                            ? '<span style="color:#a60">artefatto mancante: ' + EscapeHtml(def.artifact) + '</span>'
                            : '<span style="color:#080">artefatto ✓ ' + EscapeHtml(def.artifact) + '</span>');
                    } else if (Array.isArray(def.artifacts) && (def.artifacts.length > 0)) {
                        // v2.0.7: i bundle (artifacts[]) erano INVISIBILI ('—'):
                        // ora mostrano il numero e l'ELENCO dei file per OS.
                        var lstA = def.artifacts;
                        var visA = lstA.slice(0, 12).map(function (s) { return EscapeHtml(String(s)); }).join(', ');
                        art = ((def.artifactMissing === true) ? '<span style="color:#a60">bundle con file mancanti — </span>' : '<span style="color:#080">bundle ✓ </span>')
                            + lstA.length + ' file: <div style="font-size:11px;color:#555;word-break:break-all;max-width:520px">' + visA
                            + ((lstA.length > 12) ? ' … <i>+' + (lstA.length - 12) + ' altri (file store/' + EscapeHtml(String((p != null) ? p.id : '') ) + '/)</i>' : '') + '</div>';
                    }
                    defs += '<div style="padding:2px 0"><b>' + oses[k] + '</b>: tipo ' + EscapeHtml(String(def.type)) + ', ' + art + '</div>';
                }
                if (defs == '') { defs = '<i>nessuna definizione</i>'; }
                x += '<tr style="border-bottom:1px solid #eee;vertical-align:top"><td style="padding:4px"><b>' + EscapeHtml(p.name) + '</b><br><span style="color:#888">' + EscapeHtml(p.id) + '</span></td><td style="padding:4px">' + defs + '</td><td style="padding:4px"><input type=button value="Modifica" onclick="pluginHandler.pkgmanager.pkgAdminEdit(\'' + EscapeHtml(p.id) + '\')"> <input type=button value="Elimina" onclick="pluginHandler.pkgmanager.pkgAdminDelete(\'' + EscapeHtml(p.id) + '\')"></td></tr>';
            }
            x += '</table>';
            x += '<div style="margin-top:8px;color:#888">Artefatti: cartella server plugins/pkgmanager/store/&lt;pacchetto&gt;/&lt;file&gt;. "Carica artefatto" li inserisce da questa pagina (serve amministratore del server).</div>';
            x += '<div id="pkgmanagerMsg" style="margin-top:10px;color:#080"></div>';
            m.innerHTML = x;
            var asel = document.getElementById('pkgmanagerAdminOsSel');
            if (asel != null) { asel.value = (window.pkgmanagerAdminOsVal == null) ? 'all' : String(window.pkgmanagerAdminOsVal); }
            var acnt = document.getElementById('pkgmanagerAdminOsCount');
            if (acnt != null) { acnt.textContent = ((af == 'all') ? '' : ('mostrati ' + aShown + ' di ' + aTotal + ' pacchetti')); }
        } catch (e) { console.log('pkgmanager admin render failed: ' + e); }
    };

    // v1.9.5: cambio filtro OS del catalogo (solo «Gestione pacchetti»)
    obj.pkgAdminOsFilter = function () {
        try {
            var s = document.getElementById('pkgmanagerAdminOsSel');
            if (s == null) return;
            window.pkgmanagerAdminOsVal = String(s.value);
            pluginHandler.pkgmanager.pkgAdminRender();
        } catch (e) { console.log('pkgmanager admin os filter failed: ' + e); }
    };

    obj.pkgAdminAdd = function () { pluginHandler.pkgmanager.pkgAdminForm(null); };

    obj.pkgAdminEdit = function (pkgid) {
        try {
            var pkg = null;
            var cat = window.pkgmanagerCatalog;
            for (var i = 0; i < ((cat != null) ? cat.packages.length : 0); i++) { if (cat.packages[i].id == pkgid) { pkg = cat.packages[i]; break; } }
            pluginHandler.pkgmanager.pkgAdminForm(pkg);
        } catch (e) { console.log('pkgmanager admin edit failed: ' + e); }
    };

    // ---- v0.9.1 management single-form state (same pattern as the builder,
    // SEPARATE draft so the wizard flow can never pollute it and vice versa) ----
    obj.pkgAdminCurOs = function () { try { return String(Q('pkgfOs').value || 'linux'); } catch (e) { return 'linux'; } };
    obj.pkgAdminFieldSync = function (os) {
        try {
            if (window.pkgmanagerAdminDraft == null) { window.pkgmanagerAdminDraft = {}; }
            window.pkgmanagerAdminDraft[os] = { art: Q('pkgfArt').value.trim(), type: String(Q('pkgfType').value), to: Q('pkgfTo').value.trim(), cmd: Q('pkgfCmd').value, un: Q('pkgfUn').value, kind: String(Q('pkgfKind').value || '') };
        } catch (e) { }
    };
    // Sync the CURRENT-OS fields into the management draft. Management-only:
    // a no-op outside the admin view (the builder draft stays untouched).
    obj.pkgAdminDraftSync = function () {
        try {
            if (window.pkgmanagerView !== 'admin') return;
            pluginHandler.pkgmanager.pkgAdminFieldSync(pluginHandler.pkgmanager.pkgAdminCurOs());
        } catch (e) { }
    };
    obj.pkgAdminOsChange = function () {
        try {
            var prev = window.pkgmanagerAdminDraftOs || 'linux';
            pluginHandler.pkgmanager.pkgAdminFieldSync(prev);
            var os = pluginHandler.pkgmanager.pkgAdminCurOs();
            var d = ((window.pkgmanagerAdminDraft != null) ? window.pkgmanagerAdminDraft[os] : null);
            Q('pkgfArt').value = ((d != null) ? (d.art || '') : '');
            Q('pkgfType').value = ((d != null) && (d.type != null)) ? d.type : pluginHandler.pkgmanager.pkgCreateDefaultType(os);
            Q('pkgfTo').value = ((d != null) && (d.to != null)) ? d.to : '300';
            Q('pkgfCmd').value = ((d != null) && (d.cmd != null)) ? d.cmd : '';
            Q('pkgfUn').value = ((d != null) && (d.un != null)) ? d.un : '';
            window.pkgmanagerAdminDraftOs = os;
            pluginHandler.pkgmanager.pkgAdminOsHint();
        } catch (e) { }
    };
    obj.pkgAdminOsHint = function () {
        try {
            var h = document.getElementById('pkgfOsHint');
            if (h == null) return;
            var pid = Q('pkgfId').value.trim();
            var saved = {};
            var cat = window.pkgmanagerCatalog;
            for (var i = 0; i < ((cat != null) ? cat.packages.length : 0); i++) { if (cat.packages[i].id == pid) { var p = cat.packages[i]; if (p.linux != null) { saved.linux = p.linux; } if (p.windows != null) { saved.windows = p.windows; } if (p.macos != null) { saved.macos = p.macos; } break; } }
            var parts = [];
            var oses = [['linux', 'Linux'], ['windows', 'Windows'], ['macos', 'macOS']];
            for (var k = 0; k < oses.length; k++) {
                var os = oses[k][0];
                var d = ((window.pkgmanagerAdminDraft != null) ? window.pkgmanagerAdminDraft[os] : null);
                if ((d != null) && (d.cmd != null) && (d.cmd != '')) {
                    // A draft that still MATCHES the saved def (just loaded into
                    // the form for editing) is 'salvato'; only real edits are 'bozza'.
                    var sd = saved[os];
                    var same = (sd != null) && (String(d.cmd) == String(sd.cmd || '')) && (String(d.art || '') == String(sd.artifact || '')) && (String(d.type) == String(sd.type)) && (String(parseInt(d.to) || '') == String(sd.timeout || ''));
                    parts.push(oses[k][1] + (same ? ': salvato' : ': bozza'));
                }
                else if (saved[os] != null) { parts.push(oses[k][1] + ': salvato'); }
            }
            h.innerText = parts.length ? ('Definizioni: ' + parts.join(' · ')) : '';
        } catch (e) { }
    };

    obj.pkgAdminForm = function (pkg) {
        try {
            var m = document.getElementById('pkgmanagerMain');
            if (m == null) return;
            var isNew = (pkg == null);
            var osKindOpt = ((pkg != null) && (String(pkg.kind || '').trim() == 'os')) ? '<option value="os">Aggiornamento del sistema operativo (airgap)</option>' : '';
            var x = '<div style="margin-bottom:8px;font-size:16px"><b>' + (isNew ? 'Aggiungi pacchetto' : 'Modifica pacchetto') + '</b></div>';
            x += '<table style="border-collapse:collapse">';
            x += '<tr><td style="padding:4px">ID</td><td style="padding:4px"><input type=text id=pkgfId style=width:280px value="' + EscapeHtml(isNew ? '' : pkg.id) + '"' + (isNew ? '' : ' readonly') + '></td></tr>';
            x += '<tr><td style="padding:4px">Nome</td><td style="padding:4px"><input type=text id=pkgfName style=width:280px value="' + EscapeHtml(isNew ? '' : (pkg.name || '')) + '"></td></tr>';
            x += '<tr><td style="padding:4px">Descrizione</td><td style="padding:4px"><input type=text id=pkgfDesc style=width:420px value="' + EscapeHtml(isNew ? '' : (pkg.description || '')) + '"></td></tr>';
            x += '<tr><td style="padding:4px">Categoria</td><td style="padding:4px"><select id=pkgfKind style=width:280px onchange="pluginHandler.pkgmanager.pkgAdminDraftSync()"><option value="">Applicazione (gestione pacchetti)</option>' + osKindOpt + '</select> <span style="color:#888;font-size:12px">gli aggiornamenti OS compaiono solo nel menu «Aggiornamenti OS» e non si creano a mano (scansione → Scarica aggiornamenti)</span></td></tr>';
            x += '</table>';
            // v0.9.1 single form: per-OS drafts seeded from the package, the OS
            // dropdown swaps the fields (same pattern as the builder).
            var draft = {};
            var oses = [['linux', 'Linux'], ['windows', 'Windows'], ['macos', 'macOS']];
            var osCur = '';
            for (var k = 0; k < oses.length; k++) {
                var os = oses[k][0];
                var def = ((pkg != null) ? pkg[os] : null);
                if (def != null) {
                    var seedArt = ((def.artifacts != null) && (def.artifacts.length > 0)) ? def.artifacts.join(' ') : ((def.artifact != null) ? String(def.artifact) : '');
                    draft[os] = { art: seedArt, type: String(def.type), to: ((def.timeout != null) ? String(def.timeout) : '300'), cmd: String(def.cmd || ''), un: ((def.uninstall != null) ? String(def.uninstall) : ''), kind: ((def.kind != null) ? String(def.kind) : ((pkg != null) ? String(pkg.kind || '') : '')) };
                    if (osCur == '') { osCur = os; }
                }
            }
            if (osCur == '') { osCur = 'linux'; }
            window.pkgmanagerAdminDraft = draft;
            window.pkgmanagerAdminDraftOs = osCur;
            var d0 = draft[osCur];
            x += '<tr><td style="padding:4px">Sistema operativo</td><td style="padding:4px"><select id=pkgfOs onchange="pluginHandler.pkgmanager.pkgAdminOsChange()">';
            for (var k2 = 0; k2 < oses.length; k2++) { x += '<option value="' + oses[k2][0] + '"' + ((oses[k2][0] == osCur) ? ' selected' : '') + '>' + oses[k2][1] + '</option>'; }
            x += '</select> <span id=pkgfOsHint style="color:#888"></span></td></tr>';
            x += '<tr><td style="padding:4px">Artefatto (file nello store)</td><td style="padding:4px"><input type=text id=pkgfArt style=width:280px oninput="pluginHandler.pkgmanager.pkgAdminDraftSync()" value="' + EscapeHtml(((d0 != null) ? (d0.art || '') : '')) + '"> <input type=button value="Carica artefatto…" onclick="pluginHandler.pkgmanager.pkgAdminUpload()"> <input type=button value="Elimina artefatto" onclick="pluginHandler.pkgmanager.pkgAdminArtifactDel()"></td></tr>';
            x += '<tr><td style="padding:4px">Tipo comando</td><td style="padding:4px"><select id=pkgfType onchange="pluginHandler.pkgmanager.pkgAdminDraftSync()"><option value=3' + (((d0 == null) || (d0.type == '3')) ? ' selected' : '') + '>Shell (Linux/macOS)</option><option value=1' + (((d0 != null) && (d0.type == '1')) ? ' selected' : '') + '>cmd.exe (Windows)</option><option value=2' + (((d0 != null) && (d0.type == '2')) ? ' selected' : '') + '>PowerShell (Windows)</option></select> · Timeout (s): <input type=text id=pkgfTo style=width:70px value="' + EscapeHtml(((d0 != null) && (d0.to != null)) ? d0.to : '300') + '" oninput="pluginHandler.pkgmanager.pkgAdminDraftSync()"></td></tr>';
            x += '</table>';
            x += '<div style="padding:4px 0">Comando: <input type=button value="Preset airgap" onclick="pluginHandler.pkgmanager.pkgCreatePreset()"> <input type=button value="Inserisci {{url}}" onclick="pluginHandler.pkgmanager.pkgCreateInsert(\'url\')"> <input type=button value="Inserisci {{sha384}}" onclick="pluginHandler.pkgmanager.pkgCreateInsert(\'sha384\')"></div>';
            x += '<textarea id=pkgfCmd style="width:640px;height:80px;font-family:monospace" oninput="pluginHandler.pkgmanager.pkgAdminDraftSync()">' + EscapeHtml(((d0 != null) ? (d0.cmd || '') : '')) + '</textarea>';
            x += '<div style="padding:4px 0">Comando di disinstallazione (' + (pluginHandler.pkgmanager.pkgIsOsView() ? 'consigliata, opzionale per gli aggiornamenti OS — generata dal preset quando automatizzabile' : 'obbligatoria — generata dal preset o scritta a mano') + '; eseguita dal tasto «Elimina selezionati»):</div>';
            x += '<textarea id=pkgfUn style="width:640px;height:50px;font-family:monospace" oninput="pluginHandler.pkgmanager.pkgAdminDraftSync()">' + EscapeHtml(((d0 != null) ? (d0.un || '') : '')) + '</textarea></div>';
            x += '<div style="margin-top:10px"><input type=button value="Salva" onclick="pluginHandler.pkgmanager.pkgAdminSave(' + (isNew ? 'true' : 'false') + ')"> <input type=button value="Annulla" onclick="pluginHandler.pkgmanager.pkgAdminRender()"> <input type=file id="pkgfFile" style="display:none"></div>';
            x += '<div id="pkgadminStatus" style="margin-top:6px;color:#888"></div>';
            m.innerHTML = x;
            Q('pkgfKind').value = ((pkg != null) && (pkg.kind != null)) ? String(pkg.kind) : '';
            pluginHandler.pkgmanager.pkgAdminOsHint();
        } catch (e) { console.log('pkgmanager admin form failed: ' + e); }
    };

    obj.pkgAdminStatus = function (t) {
        try {
            var s = document.getElementById('pkgadminStatus');
            if (s != null) { s.innerText = t; }
            console.log('pkgmanager: ' + t);
        } catch (e) { }
    };

    obj.pkgAdminUpload = function (os) {
        try {
            if (os == null) { os = pluginHandler.pkgmanager.pkgAdminCurOs(); } // v0.9.1 single-form management
            var f = document.getElementById('pkgfFile');
            if (f == null) return;
            f.value = '';
            f.onchange = function () { pluginHandler.pkgmanager.pkgAdminUploadDo(os); };
            f.click();
        } catch (e) { }
    };

    // Upload the picked file to the SERVER STORE over /pkgstore.ashx POST
    // (session-authenticated; server gates full site admins).
    obj.pkgAdminUploadDo = function (os) {
        try {
            var f = document.getElementById('pkgfFile');
            if ((f.files == null) || (f.files.length == 0)) return;
            var pid = Q('pkgfId').value.trim();
            var artInput = document.getElementById('pkgfArt_' + os);
            if (artInput == null) { artInput = document.getElementById('pkgfArt'); } // v0.9.0 single-form wizard
            if (artInput == null) { pluginHandler.pkgmanager.pkgAdminStatus('Campo artefatto mancante.'); return; }
            var art = artInput.value.trim();
            // v1.3.0: the field may hold a space/comma separated bundle
            // list — the PICKED file is uploaded under its own name and
            // appended to the list.
            var pickName = f.files[0].name;
            if (!/^[a-zA-Z0-9._-]+$/.test(art)) {
                var lst = art.split(/[\s,]+/).filter(function (x) { return x != ''; });
                if (lst.indexOf(pickName) < 0) { lst.push(pickName); }
                artInput.value = lst.join(' ');
                art = pickName;
            }
            if (art == '') { art = pickName; artInput.value = art; }
            if (!/^[a-zA-Z0-9._-]+$/.test(pid) || !/^[a-zA-Z0-9._ -]+$/.test(art)) { pluginHandler.pkgmanager.pkgAdminStatus('ID o nome artefatto non validi.'); return; }
            var fname = f.files[0].name;
            f.files[0].arrayBuffer().then(function (buf) {
                fetch('/pkgstore.ashx?op=upload&p=' + encodeURIComponent(pid + '/' + art), { method: 'POST', body: buf, headers: { 'Content-Type': 'application/octet-stream' } })
                    .then(function (r) { return r.json(); })
                    .then(function (j) {
                        if (j.ok) { pluginHandler.pkgmanager.pkgCreateDraftSync(); pluginHandler.pkgmanager.pkgAdminDraftSync(); pluginHandler.pkgmanager.pkgAdminStatus('Artefatto caricato: ' + art + ' (' + j.size + ' byte, sha384 ' + String(j.sha384).slice(0, 12) + '…). Salva per aggiornare il catalogo.'); }
                        else { pluginHandler.pkgmanager.pkgAdminStatus('Upload negato: ' + EscapeHtml(String(j.error || '')) + ' (serve amministratore del server).'); }
                    })
                    .catch(function (e2) { pluginHandler.pkgmanager.pkgAdminStatus('Upload fallito: ' + e2); });
            });
        } catch (e) { pluginHandler.pkgmanager.pkgAdminStatus('Upload fallito: ' + e); }
    };

    obj.pkgAdminArtifactDel = function (os) {
        try {
            if (os == null) { os = pluginHandler.pkgmanager.pkgAdminCurOs(); } // v0.9.1 single-form management
            var pid = Q('pkgfId').value.trim();
            var artInput = document.getElementById('pkgfArt_' + os);
            if (artInput == null) { artInput = document.getElementById('pkgfArt'); } // v0.9.0 single-form wizard
            if (artInput == null) { pluginHandler.pkgmanager.pkgAdminStatus('Campo artefatto mancante.'); return; }
            var art = artInput.value.trim();
            // v1.3.0: a bundle list deletes EVERY named file, then clears.
            var names = art.split(/[\s,]+/).filter(function (x) { return x != ''; });
            if (!/^[a-zA-Z0-9._-]+$/.test(pid) || (names.length == 0) || names.some(function (x) { return !/^[a-zA-Z0-9._-]+$/.test(x); })) { pluginHandler.pkgmanager.pkgAdminStatus('ID o nome artefatto non validi.'); return; }
            var left = names.length, gone = 0;
            for (var d = 0; d < names.length; d++) {
                (function (nm) {
                    fetch('/pkgstore.ashx?op=del&p=' + encodeURIComponent(pid + '/' + nm), { method: 'POST' })
                        .then(function (r) { return r.json(); })
                        .then(function (j) { if (j.ok) { gone++; } })
                        .catch(function (e2) { })
                        .then(function () {
                            left--;
                            if (left == 0) {
                                if (gone == names.length) { artInput.value = ''; pluginHandler.pkgmanager.pkgCreateDraftSync(); pluginHandler.pkgmanager.pkgAdminDraftSync(); }
                                pluginHandler.pkgmanager.pkgAdminStatus(gone + '/' + names.length + ' artefatti eliminati dallo store' + ((gone == names.length) ? '' : ' — alcuni file non trovati'));
                            }
                        });
                })(names[d]);
            }
        } catch (e) { }
    };

    obj.pkgAdminSave = function (isNew) {
        try {
            var pid = Q('pkgfId').value.trim();
            if (!/^[a-zA-Z0-9._-]+$/.test(pid)) { pluginHandler.pkgmanager.pkgAdminStatus('ID non valido (lettere, numeri, . _ -).'); return; }
            var name = Q('pkgfName').value.trim();
            if (name == '') { pluginHandler.pkgmanager.pkgAdminStatus('Nome mancante.'); return; }
            // v0.9.1 single form: current fields + per-OS drafts, MERGED with
            // the defs already saved for this ID (an untouched saved OS must
            // survive the server-side replace-on-id save).
            pluginHandler.pkgmanager.pkgAdminFieldSync(pluginHandler.pkgmanager.pkgAdminCurOs());
            var pkg = { id: pid, name: name, description: Q('pkgfDesc').value, kind: Q('pkgfKind').value };
            for (var k in window.pkgmanagerAdminDraft) {
                var d = window.pkgmanagerAdminDraft[k];
                if ((k == 'linux') || (k == 'windows') || (k == 'macos')) {
                    if ((d != null) && (d.cmd != null) && (d.cmd.trim() != '')) {
                        var def = { type: (parseInt(d.type) || pluginHandler.pkgmanager.pkgCreateDefaultType(k)), cmd: d.cmd.trim() };
                        var to = parseInt(d.to); if (to > 0) { def.timeout = to; }
                        if ((d.art != null) && (d.art.trim() != '')) {
                            // v1.3.0: a multi-name field builds a bundle list.
                            var an = d.art.trim().split(/[\s,]+/).filter(function (x) { return x != ''; });
                            if (an.length > 1) { def.artifacts = an; } else { def.artifact = an[0]; }
                        }
                        if ((d.un != null) && (d.un.trim() != '')) { def.uninstall = d.un.trim(); }
                        if ((d.kind != null) && (String(d.kind).trim() != '')) { def.kind = String(d.kind).trim(); }
                        pkg[k] = def;
                    }
                }
            }
            var cat = window.pkgmanagerCatalog;
            for (var i = 0; i < ((cat != null) ? cat.packages.length : 0); i++) {
                if (cat.packages[i].id == pid) {
                    var oses2 = ['linux', 'windows', 'macos'];
                    for (var j = 0; j < oses2.length; j++) {
                        var o2 = oses2[j];
                        if ((pkg[o2] == null) && (cat.packages[i][o2] != null)) { pkg[o2] = cat.packages[i][o2]; }
                    }
                    break;
                }
            }
            if ((pkg.linux == null) && (pkg.windows == null) && (pkg.macos == null)) { pluginHandler.pkgmanager.pkgAdminStatus('Compila il comando per il sistema operativo selezionato prima di salvare.'); return; }
            var osesChk = ['linux', 'windows', 'macos'];
            for (var c2 = 0; c2 < osesChk.length; c2++) {
                var d2 = pkg[osesChk[c2]];
                if ((d2 != null) && (d2.uninstall == null) && (String(d2.kind || '') != 'os')) { pluginHandler.pkgmanager.pkgAdminStatus('Comando di disinstallazione mancante per ' + osesChk[c2] + ' — generane uno col preset o scrivilo a mano (è obbligatorio come l\'installazione).'); return; }
            }
            meshserver.send({ action: 'plugin', plugin: 'pkgmanager', pluginaction: 'save', pkg: pkg });
            pluginHandler.pkgmanager.pkgAdminStatus('Salvataggio…');
            pluginHandler.pkgmanager.pkgAdminOsHint();
        } catch (e) { pluginHandler.pkgmanager.pkgAdminStatus('Errore: ' + e); }
    };

    obj.pkgAdminDelete = function (pkgid) {
        try {
            if (!confirm('Eliminare il pacchetto "' + pkgid + '" dal catalogo? Verranno rimossi anche i suoi artefatti dallo store del server.')) return;
            meshserver.send({ action: 'plugin', plugin: 'pkgmanager', pluginaction: 'delete', id: pkgid });
        } catch (e) { }
    };

    // ---- Install page: packages left, target machines right ----
    // v1.9.9: banner ambra finché i binari del downloader non sono completi
    obj.pkgBinBanner = function () {
        try {
            var miss = window.pkgmanagerBinMissing;
            if ((miss == null) || (miss == 0)) { return ''; }
            var busy = (window.pkgmanagerBinBusy === true);
            var attempts = (window.pkgmanagerBinAttempts || 0);
            var txt;
            if (busy || (attempts < 5)) {
                txt = '⏳ Binari del downloader compilato in scaricamento automatico in background (' + miss + ' piattaforme mancanti su 7) — finché non arrivano, «Esporta downloader» supporta solo la piattaforma «py». Il resto del plugin funziona normalmente.';
            } else {
                txt = '⚠️ Binari del downloader compilato non disponibili (' + miss + ' piattaforme mancanti su 7 — server senza internet?): «Esporta downloader» supporta solo «py». Per attivarli: copia la cartella bin/ a mano o configura settings.plugins.pkgmanagerBinariesUrl e riavvia MeshCentral.';
            }
            var errT = ((window.pkgmanagerBinError != null) ? (' <span style="color:#900">Ultimo errore: ' + EscapeHtml(window.pkgmanagerBinError) + '</span>') : '');
            return '<div style="margin:0 0 10px 0;padding:8px 10px;border:1px solid #d5a012;background:#fff7e0;border-radius:6px;color:#7a5b00;font-size:13px">' + txt + errT + '</div>';
        } catch (e) { return ''; }
    };

    obj.pkgSidebarRenderDevices = function () {
        try {
            var m = document.getElementById('pkgmanagerMain');
            if (m == null) return;
            var devlist = [];
            try { for (var i in nodes) { if (nodes[i] && nodes[i]._id) devlist.push(nodes[i]); } } catch (e) { }
            if (window.pkgmanagerSelPkg == null) { window.pkgmanagerSelPkg = {}; } // v1.2.0: survives table re-renders
            var x = '<div style="margin-bottom:8px;font-size:16px"><b>Installa/Elimina sui dispositivi</b></div>' + pluginHandler.pkgmanager.pkgBinBanner();
            x += '<div id="pkgmanagerSelSummary" style="margin-bottom:8px;color:#888"></div>';
            x += '<div style="display:flex;gap:16px;align-items:flex-start">';
            x += '<div style="flex:1 1 60%;min-width:0"><div style="margin-bottom:4px"><b>Pacchetti</b> <span id="pkgmanagerFilterNote" style="color:#888;font-weight:normal"></span> <span style="font-size:12px">[<a href=# onclick="pluginHandler.pkgmanager.pkgPkgSelectAll(true);return false">tutti</a> / <a href=# onclick="pluginHandler.pkgmanager.pkgPkgSelectAll(false);return false">nessuno</a>]</span></div>';
            x += '<div style="margin-bottom:6px"><input type=button value="Installa selezionati" onclick="pluginHandler.pkgmanager.pkgBatchRun(\'install\')"> <input type=button value="Elimina selezionati" title="Esegue il comando di disinstallazione sui dispositivi selezionati" onclick="pluginHandler.pkgmanager.pkgBatchRun(\'delete\')"> <span id="pkgmanagerPkgSummary" style="color:#888;font-weight:normal"></span></div><div id="pkgmanagerTableWrap"></div></div>';
            x += '<div style="flex:0 0 320px;border-left:1px solid #ddd;padding-left:12px">';
            x += '<div style="margin-bottom:4px"><b>Macchine di destinazione</b> — <span style="font-size:12px"><a href=# onclick="pluginHandler.pkgmanager.pkgDevSelectAll(true);return false">tutte</a> / <a href=# onclick="pluginHandler.pkgmanager.pkgDevSelectAll(false);return false">nessuna</a></span></div>';
            // v1.9.4: filtro per sistema operativo (menu a discesa)
            x += '<div style="margin-bottom:6px">Sistema operativo: <select id="pkgmanagerOsFilter" onchange="pluginHandler.pkgmanager.pkgDevOsFilter()" style="padding:3px 5px"><option value="all">Tutti</option><option value="linux">Linux</option><option value="windows">Windows</option><option value="macos">macOS</option></select> <span id="pkgmanagerDevCount" style="color:#888;font-size:12px"></span></div>';
            x += '<div id="pkgmanagerDeviceList" style="max-height:420px;overflow-y:auto"></div>';
            x += '<div style="margin-top:6px;color:#888;font-size:12px">Le macchine offline non sono selezionabili.</div>';
            x += '</div></div>';
            x += '<div id="pkgmanagerMsg" style="margin-top:10px;color:#888"></div>';
            m.innerHTML = x;
            var fs = document.getElementById('pkgmanagerOsFilter');
            if (fs != null) { fs.value = (window.pkgmanagerOsFilterVal == null) ? 'all' : String(window.pkgmanagerOsFilterVal); }
            pluginHandler.pkgmanager.pkgDevListRender();
            pluginHandler.pkgmanager.pkgSidebarRender();
        } catch (e) { console.log('pkgmanager device render failed: ' + e); }
    };

    // v1.9.4: righe delle macchine di destinazione della vista INSTALLA,
    // filtrate per sistema operativo (pkgmanagerOsFilterVal: all/linux/windows/macos).
    // NOTA: lo stato NON si chiama pkgmanagerOsFilter perche' gli elementi con id
    // diventano proprieta' di window (id-global): window.pkgmanagerOsFilter e'
    // la select stessa, non una variabile.
    // Il filtro e' VISUALE: le spunte sopravvivono ai cambi di filtro.
    obj.pkgDevListRender = function () {
        try {
            var el = document.getElementById('pkgmanagerDeviceList');
            if (el == null) return;
            var s = document.getElementById('pkgmanagerOsFilter');
            var f = (s != null) ? String(s.value) : ((window.pkgmanagerOsFilterVal == null) ? 'all' : String(window.pkgmanagerOsFilterVal));
            var devlist = [];
            try { for (var i in nodes) { if (nodes[i] && nodes[i]._id) devlist.push(nodes[i]); } } catch (e0) { }
            var x = '';
            var shown = 0;
            for (var i2 = 0; i2 < devlist.length; i2++) {
                var n = devlist[i2];
                var on = ((n.conn & 1) != 0);
                var os = pluginHandler.pkgmanager.pkgTargetOs(n);
                var vis = ((f == 'all') || (f == os));
                if (vis) { shown++; }
                x += '<label data-os="' + os + '" style="display:' + (vis ? 'block' : 'none') + ';padding:4px 2px;border-bottom:1px solid #eee;' + (on ? 'cursor:pointer' : 'color:#999;cursor:not-allowed') + '">';
                x += '<input type=checkbox class="pkgmanagerDevCb" data-os="' + os + '" value="' + EscapeHtml(n._id) + '"' + (on ? '' : ' disabled') + ' onchange="pluginHandler.pkgmanager.pkgDevToggle()"> ';
                x += '<b>' + EscapeHtml(n.name) + '</b> <span style="color:#888">· ' + os + (on ? ' · online' : ' · offline') + '</span></label>';
            }
            if (devlist.length == 0) { x = '<div style="color:#888;padding:4px">Nessun dispositivo</div>'; }
            el.innerHTML = x;
            var cnt = document.getElementById('pkgmanagerDevCount');
            if (cnt != null) { cnt.textContent = ((f == 'all') ? '' : ('mostrate ' + shown + ' di ' + devlist.length)); }
        } catch (e) { console.log('pkgmanager dev list render failed: ' + e); }
    };

    // v1.9.4: cambio filtro OS dal menu a discesa (solo vista INSTALLA).
    // NON ricostruisce la lista: alterna la visibilita' delle etichette esistenti
    // (il ricostruire svuoterebbe le spunte — il filtro deve restare visuale).
    obj.pkgDevOsFilter = function () {
        try {
            var s = document.getElementById('pkgmanagerOsFilter');
            if (s == null) return;
            window.pkgmanagerOsFilterVal = String(s.value);
            var f = String(s.value);
            var labels = document.querySelectorAll('#pkgmanagerDeviceList label');
            var shown = 0, total = 0;
            for (var i = 0; i < labels.length; i++) {
                total++;
                var os = labels[i].getAttribute('data-os');
                var vis = ((f == 'all') || (f == os));
                labels[i].style.display = vis ? 'block' : 'none';
                if (vis) { shown++; }
            }
            var cnt = document.getElementById('pkgmanagerDevCount');
            if (cnt != null) { cnt.textContent = ((f == 'all') ? '' : ('mostrate ' + shown + ' di ' + total)); }
        } catch (e) { console.log('pkgmanager os filter failed: ' + e); }
    };

    obj.pkgDevToggle = function () { if (window.pkgmanagerView == 'os') { pluginHandler.pkgmanager.pkgOsTable(); } else { pluginHandler.pkgmanager.pkgSidebarRender(); } }; // v1.4.0: view-aware

    obj.pkgDevSelectAll = function (v) {
        try {
            var s = document.getElementById('pkgmanagerOsFilter'); // v1.9.4: il filtro esiste solo nella vista INSTALLA
            var f = (s != null) ? String(s.value) : 'all';
            var cbs = document.querySelectorAll('.pkgmanagerDevCb');
            for (var i = 0; i < cbs.length; i++) {
                if (cbs[i].disabled) continue;
                if ((f != 'all') && (cbs[i].getAttribute('data-os') != f)) continue; // "tutte/nessuna" rispetta il filtro OS
                cbs[i].checked = v;
            }
        } catch (e) { }
        pluginHandler.pkgmanager.pkgSidebarRender();
    };

    obj.pkgSelectedNodes = function () {
        var out = [];
        try {
            var cbs = document.querySelectorAll('.pkgmanagerDevCb');
            for (var i = 0; i < cbs.length; i++) {
                if (!cbs[i].checked) continue;
                for (var j in nodes) { if (nodes[j] && (nodes[j]._id == cbs[i].value)) { out.push(nodes[j]); break; } }
            }
        } catch (e) { }
        return out;
    };

    // Re-render ONLY the package table (the checkbox panel keeps its state):
    // a package is visible only if it has an install def for every OS selected.
    obj.pkgSidebarRender = function () {
        try {
            var w = document.getElementById('pkgmanagerTableWrap');
            if (w == null) return;
            var cat = window.pkgmanagerCatalog;
            if ((cat == null) || (cat.packages == null)) { w.innerHTML = '<div style="color:#888">Caricamento catalogo…</div>'; return; }
            var sel = pluginHandler.pkgmanager.pkgSelectedNodes();
            var oses = {}; for (var i = 0; i < sel.length; i++) { oses[pluginHandler.pkgmanager.pkgTargetOs(sel[i])] = 1; }
            var osList = Object.keys(oses);
            var shown = [];
            for (var i = 0; i < cat.packages.length; i++) {
                var p = cat.packages[i];
                if (pluginHandler.pkgmanager.pkgOsKind(p) == 'os') { continue; } // v1.4.0: apps only
                var okp = true;
                for (var k = 0; k < osList.length; k++) { if (p[osList[k]] == null) { okp = false; break; } }
                if (okp) { shown.push(p); }
            }
            var note = document.getElementById('pkgmanagerFilterNote');
            if (note != null) { note.innerText = (osList.length ? ('(' + shown.length + ' di ' + cat.packages.length + ' mostrati — OS di destinazione: ' + osList.join(', ') + ')') : '(' + cat.packages.length + ' di ' + cat.packages.length + ' — seleziona le macchine per filtrare per OS)'); }
            var sum = document.getElementById('pkgmanagerSelSummary');
            if (sum != null) { sum.innerText = (sel.length ? (sel.length + ' macchina/e selezionata/e — Install gira su TUTTE, raggruppate per OS.') : 'Seleziona le macchine di destinazione a destra; l\'elenco dei pacchetti si filtra per i loro OS.'); }
            w.innerHTML = pluginHandler.pkgmanager.pkgTableHtml(shown, 'sidebar', osList);
            pluginHandler.pkgmanager.pkgPkgSummary();
        } catch (e) { console.log('pkgmanager sidebar table failed: ' + e); }
    };

    // meshserver.send() is a silent no-op until the user WS is connected (connectstate==1):
    // retry the catalog request until the socket is ready instead of firing it into the void.
    obj.pkgRequestList = function () {
        try {
            if ((typeof meshserver == 'undefined') || (meshserver == null) || (meshserver.connectstate != 1)) {
                console.log('pkgmanager: WS not ready (' + ((meshserver != null) ? meshserver.connectstate : 'null') + '), retry in 1s');
                setTimeout(function () { pluginHandler.pkgmanager.pkgRequestList(); }, 1000);
                return;
            }
            console.log('pkgmanager: requesting catalog');
            meshserver.send({ action: 'plugin', plugin: 'pkgmanager', pluginaction: 'list' });
        } catch (e) { console.log('pkgmanager request failed: ' + e); }
    };

    // v2.0.1: classificazione OS prima dal TIPO AGENTE (n.agent.id, sempre
    // presente anche quando os_title/os sono vuoti o non ancora popolati),
    // poi fallback sul testo os_title/os. Prima il default era 'linux', quindi
    // una macchina Windows senza os_title veniva trattata come Linux.
    // Tabella agenttypes di MeshCentral: win32 = 1,2,3,4,21,22,42,43,10003,10004,10043,11000,11001,11002 (+ assistant 34,10006);
    // osx = 8,16,29,10005; tutto il resto = linux/freebsd/altro.
    obj.pkgTargetOs = function (n) {
        // 1) segnale positivo dal testo (quando c'è, è quello più esplicito)
        var t = '';
        try { t = String(((n != null) && (n.os_title != null)) ? n.os_title : (((n != null) && (n.os != null)) ? n.os : '')); } catch (e) { }
        if (/win/i.test(t)) { return 'windows'; }
        if (/mac os x|darwin/i.test(t)) { return 'macos'; }
        // 2) tipo agente (sempre presente, anche con os_title vuoto/non popolato)
        try {
            var aid = ((n != null) && (n.agent != null)) ? parseInt(n.agent.id) : NaN;
            if (!isNaN(aid)) {
                if ((aid == 1) || (aid == 2) || (aid == 3) || (aid == 4) || (aid == 21) || (aid == 22) || (aid == 42) || (aid == 43) || (aid == 34) || (aid == 10003) || (aid == 10004) || (aid == 10006) || (aid == 10043) || (aid == 11000) || (aid == 11001) || (aid == 11002)) { return 'windows'; }
                if ((aid == 8) || (aid == 16) || (aid == 29) || (aid == 10005)) { return 'macos'; }
                if (aid > 0) { return 'linux'; }
            }
        } catch (e) { }
        return 'linux';
    };

    // The template dispatcher calls pluginHandler[plugin][method](server, message):
    // first argument is the server object, the payload lives in message.
    obj.pkgList = function (server, message) {
        console.log('pkgmanager: pkgList called');
        try {
            window.pkgmanagerCatalog = message.catalog;
            window.pkgmanagerToken = message.token;
            window.pkgmanagerBinMissing = message.binMissing;
            window.pkgmanagerBinBusy = message.binBusy;
            window.pkgmanagerBinAttempts = message.binAttempts;
            window.pkgmanagerBinError = (message.binError || null);
            if (message.pluginVersion != null) { window.pkgmanagerPluginVersion = message.pluginVersion; }
            if (message.opAck != null) { window.pkgmanagerAdminMsg = message.opAck; }
            if (message.error != null) { window.pkgmanagerAdminMsg = message.error; pluginHandler.pkgmanager.pkgMsg(message.error); } // v1.8.0: gli errori del server (es. osfetch su server airgap) ora sono VISIBILI
            // v1.9.1 sticky view: dopo un bounce (go(0) ha salvato la vista)
            // il core si e' riconnesso ed e' atterrato sulla pagina 1 —
            // riapri la vista plugin DA SOLA. Solo se nessuna vista plugin e'
            // attiva (il bounce l'ha smontata) e il core e' davvero atterrato
            // sulla pagina principale; il marker viene consumato comunque.
            var stickyV = null;
            try { stickyV = sessionStorage.getItem('pkgmanagerStickyView'); sessionStorage.removeItem('pkgmanagerStickyView'); } catch (e2) { }
            if ((stickyV != null) && (window.pkgmanagerView == null) && (typeof xxcurrentView !== 'undefined') && (xxcurrentView === 1)) {
                try {
                    if (stickyV === 'install') { pluginHandler.pkgmanager.pkgSidebarOpen(); }
                    else if (stickyV === 'os') { pluginHandler.pkgmanager.pkgOsSidebarOpen(); }
                    else if (stickyV === 'admin') { pluginHandler.pkgmanager.pkgAdminOpen(); }
                    else if (stickyV === 'osadmin') { pluginHandler.pkgmanager.pkgOsAdminOpen(); }
                    else if (stickyV === 'osplugin') { pluginHandler.pkgmanager.pkgOsPluginOpen(); }
                    else if (stickyV === 'create') { pluginHandler.pkgmanager.pkgCreateOpen(); }
                    console.log('pkgmanager: sticky view ripristinata dopo il bounce: ' + stickyV);
                } catch (e3) { }
            }
            pluginHandler.pkgmanager.pkgTabSetActive(window.pkgmanagerView);
            var cat = window.pkgmanagerCatalog;
            var d = document.getElementById('pkgmanagerTab');
            if (d != null) {
                if ((cat == null) || (cat.packages == null)) {
                    d.innerHTML = '<div style="padding:12px;color:#888">Catalogo non disponibile.</div>';
                } else {
                    var x = '<div style="padding:12px;font-family:Arial,Helvetica,sans-serif">';
                    x += '<div style="margin-bottom:8px">Installa un pacchetto su <b>questo dispositivo</b> (canale comandi remoti standard, permessi verificati).</div>';
                    var apps = [];
                    for (var ap = 0; ap < cat.packages.length; ap++) { if (pluginHandler.pkgmanager.pkgOsKind(cat.packages[ap]) != 'os') { apps.push(cat.packages[ap]); } }
                    x += pluginHandler.pkgmanager.pkgTableHtml(apps, 'tab');
                    x += '<div id="pkgmanagerMsgTab" style="margin-top:10px;color:#888"></div></div>';
                    d.innerHTML = x;
                }
            }
            if ((window.pkgmanagerView == 'admin') || (window.pkgmanagerView == 'osadmin')) { pluginHandler.pkgmanager.pkgAdminRender(); }
            else if (window.pkgmanagerView == 'osplugin') { pluginHandler.pkgmanager.pkgOsPluginRender(); }
            else if (window.pkgmanagerView == 'create') { pluginHandler.pkgmanager.pkgCreateCatalogArrived(); }
            else if (window.pkgmanagerView == 'os') { if (document.getElementById('pkgmanagerTableWrap') != null) { pluginHandler.pkgmanager.pkgOsTable(); } else { pluginHandler.pkgmanager.pkgOsRender(); } if (message.opAck != null) { pluginHandler.pkgmanager.pkgMsg(message.opAck); } }
            else { pluginHandler.pkgmanager.pkgSidebarRender(); }
        } catch (e) { console.log('pkgmanager render failed: ' + e); }
    };

    // Server-side rejection of management ops from non-admins.
    // v1.9.6: auto-aggiornamento del plugin (solo full admin)
    obj.pkgBinStatusRequest = function () { try { meshserver.send({ action: 'plugin', plugin: 'pkgmanager', pluginaction: 'binstatus' }); } catch (e) { } };
    obj.pkgBinRetry = function () { try { meshserver.send({ action: 'plugin', plugin: 'pkgmanager', pluginaction: 'binretry' }); } catch (e) { } };
    obj.pkgBinStatus = function (server, message) {
        try { window.pkgmanagerBinStatus = message; pluginHandler.pkgmanager.pkgOsPluginRender(); } catch (e) { }
    };
    obj.pkgLogTailRequest = function () { try { meshserver.send({ action: 'plugin', plugin: 'pkgmanager', pluginaction: 'plogtail' }); } catch (e) { } };
    obj.pkgLogTail = function (server, message) {
        try {
            window.pkgmanagerLogTail = message;
            pluginHandler.pkgmanager.pkgOsPluginRender();
        } catch (e) { }
    };
    obj.pkgAgentBuildRequest = function () {
        try { meshserver.send({ action: 'plugin', plugin: 'pkgmanager', pluginaction: 'agentbuildinfo' }); } catch (e) { }
    };
    obj.pkgAgentBuild = function (server, message) { // v2.1.10: firma UI (server, message) — senza server il messaggio arrivava come oggetto server e il pannello restava sul placeholder
        // v2.1.9: pannello "Binari agente" — stato agentDefaults del core con
        // barra di avanzamento per i file in download, stato disco e errori.
        try {
            var info = ((message != null) ? message.info : null);
            window.pkgmanagerAgentBuild = info;
            pluginHandler.pkgmanager.pkgOsPluginRender();
            // auto-refresh mentre qualcosa scarica (massimo un poll/5s)
            var downloading = false;
            if ((info != null) && (info.core != null)) {
                if (info.core.busy === true) { downloading = true; }
                for (var i = 0; i < (info.core.files || []).length; i++) { if (info.core.files[i].status === 'Downloading') { downloading = true; } }
            }
            if (downloading && (window.pkgmanagerAgentBuildTimer == null)) { window.pkgmanagerAgentBuildTimer = setTimeout(function () { window.pkgmanagerAgentBuildTimer = null; pluginHandler.pkgmanager.pkgAgentBuildRequest(); }, 5000); }
            else if (!downloading && (window.pkgmanagerAgentBuildTimer != null)) { clearTimeout(window.pkgmanagerAgentBuildTimer); window.pkgmanagerAgentBuildTimer = null; }
        } catch (e) { }
    };
    obj.pkgRestartNow = function () {
        try {
            if (!window.confirm('Riavviare MeshCentral ora? Tutti gli utenti collegati verranno disconnessi e riconnessi al ritorno del server.')) { return; }
            pluginHandler.pkgmanager.pkgMsg('Riavvio di MeshCentral richiesto…');
            meshserver.send({ action: 'plugin', plugin: 'pkgmanager', pluginaction: 'serverrestart' });
        } catch (e) { pluginHandler.pkgmanager.pkgMsg('Riavvio fallito: ' + e); }
    };
    obj.pkgUpdateOnline = function () {
        try { pluginHandler.pkgmanager.pkgMsg('Controllo aggiornamento plugin dal sorgente remoto…'); meshserver.send({ action: 'plugin', plugin: 'pkgmanager', pluginaction: 'pluginupdate-check' }); } catch (e) { pluginHandler.pkgmanager.pkgMsg('Aggiornamento plugin fallito: ' + e); }
    };
    obj.pkgUpdateFile = function () {
        try {
            var inp = document.getElementById('pkgUpdateFileInput');
            if (inp == null) {
                inp = document.createElement('input'); inp.type = 'file'; inp.id = 'pkgUpdateFileInput'; inp.style.display = 'none'; inp.accept = '.js,application/javascript,text/javascript'; document.body.appendChild(inp);
                inp.addEventListener('change', function () { pluginHandler.pkgmanager.pkgUpdateUpload(); });
            }
            inp.value = ''; inp.click();
        } catch (e) { pluginHandler.pkgmanager.pkgMsg('Aggiornamento plugin fallito: ' + e); }
    };
    obj.pkgUpdateUpload = function () {
        try {
            var inp = document.getElementById('pkgUpdateFileInput');
            var f = ((inp != null) && (inp.files != null)) ? inp.files[0] : null;
            if (f == null) { pluginHandler.pkgmanager.pkgMsg('Nessun file selezionato.'); return; }
            inp.value = '';
            pluginHandler.pkgmanager.pkgMsg('Caricamento del file di aggiornamento (' + Math.round(f.size / 1024) + 'KB)…');
            f.arrayBuffer().then(function (buf) {
                return fetch('/pkgstore.ashx?op=plugupd', { method: 'POST', body: buf, headers: { 'Content-Type': 'application/octet-stream' } });
            }).then(function (r) { return r.json(); }).then(function (j) {
                if (!j.ok) { pluginHandler.pkgmanager.pkgMsg('Caricamento fallito: ' + j.error); return; }
                pluginHandler.pkgmanager.pkgMsg('File caricato (sha384 ' + String(j.sha384).slice(0, 16) + '...) — verifica e installazione…');
                meshserver.send({ action: 'plugin', plugin: 'pkgmanager', pluginaction: 'pluginupdate-airgap-apply' });
            }).catch(function (err) { pluginHandler.pkgmanager.pkgMsg('Caricamento fallito: ' + err); });
        } catch (e) { pluginHandler.pkgmanager.pkgMsg('Aggiornamento plugin fallito: ' + e); }
    };
    obj.pkgUpdateInfo = function (server, message) {
        try {
            if (message.newer === true) {
                pluginHandler.pkgmanager.pkgMsg('Aggiornamento plugin disponibile: v' + message.latest + ' (corrente v' + message.current + ', sha384 ' + String(message.sha384).slice(0, 16) + '...) — installazione…');
                meshserver.send({ action: 'plugin', plugin: 'pkgmanager', pluginaction: 'pluginupdate-apply', sha: message.sha384 });
            } else { pluginHandler.pkgmanager.pkgMsg('Plugin gia aggiornato (v' + message.current + '). Nessun aggiornamento dal sorgente remoto.'); }
        } catch (e) { }
    };
    obj.pkgUpdateApplied = function (server, message) {
        try { pluginHandler.pkgmanager.pkgMsg(message.msg || 'Plugin aggiornato.'); } catch (e) { }
    };

    obj.pkgDenied = function (server, message) {
        try {
            window.pkgmanagerAdminMsg = ((message != null) && (message.msg != null)) ? message.msg : 'Operazione negata.';
            if (window.pkgmanagerView == 'admin') { pluginHandler.pkgmanager.pkgAdminRender(); }
            else if (window.pkgmanagerView == 'create') { pluginHandler.pkgmanager.pkgCreateCatalogArrived(); }
            else { pluginHandler.pkgmanager.pkgMsg(window.pkgmanagerAdminMsg); }
            console.log('pkgmanager: negato: ' + window.pkgmanagerAdminMsg);
        } catch (e) { }
    };

    // Compose the device-side install command for a package def. Airgap: when the
    // def carries an artifact, substitute {{url}} (LAN download URL from THIS
    // server, token included) and {{sha384}} (server-computed artifact hash).
    // Returns null if the artifact is missing in the server store.
    obj.pkgCompose = function (pkg, def) {
        try {
            if (def == null) { return null; }
            // v1.3.0 bundle: def.artifacts[] (server-enriched def.sha384s).
            if ((def.artifacts != null) && (def.artifacts.length > 0)) {
                if ((def.artifactMissing === true) || (window.pkgmanagerToken == null)) { return null; }
                var cmd = String(def.cmd);
                var base = location.origin + '/pkgstore.ashx?t=' + encodeURIComponent(window.pkgmanagerToken) + '&p=';
                for (var i = 0; i < def.artifacts.length; i++) {
                    var url2 = base + encodeURIComponent(pkg.id + '/' + def.artifacts[i]);
                    var h2 = ((def.sha384s != null) ? def.sha384s[i + 1] : null);
                    if (h2 == null) { return null; }
                    cmd = cmd.split('{{url:' + (i + 1) + '}}').join(url2).split('{{sha384:' + (i + 1) + '}}').join(h2);
                    if (i == 0) { cmd = cmd.split('{{url}}').join(url2).split('{{sha384}}').join(h2); }
                }
                return cmd;
            }
            if (def.artifact != null) {
                if ((def.artifactMissing === true) || (def.sha384 == null) || (window.pkgmanagerToken == null)) { return null; }
                var url = location.origin + '/pkgstore.ashx?t=' + encodeURIComponent(window.pkgmanagerToken) + '&p=' + encodeURIComponent(pkg.id + '/' + def.artifact);
                return String(def.cmd).split('{{url}}').join(url).split('{{sha384}}').join(def.sha384);
            }
            return String(def.cmd);
        } catch (e) { return null; }
    };

    // ---- v1.4.0: SEPARATE OS-updates view (second sidebar icon) ----
    // Opens its OWN view ('os'): same open/close mechanics as pkgSidebarOpen
    // (hide the current core panel, reset xxcurrentView so a later go(x)
    // fully restores it), but the list shows ONLY kind:'os' bundles.
    obj.pkgOsSidebarOpen = function () {
        try {
            var w = document.getElementById('pkgmanagerMainWrap');
            if (w == null) return;
            try {
                if ((typeof xxcurrentView == 'number') && (xxcurrentView >= 0) && (xxcurrentView <= 60)) { QV('p' + xxcurrentView, false); }
                xxcurrentView = -1;
            } catch (e) { }
            w.style.display = '';
            window.pkgmanagerView = 'os';
            pluginHandler.pkgmanager.pkgTabSetActive('os');
            var b = document.getElementById('LeftMenuPackages');
            if (b != null) b.style.opacity = '';
            var bo = document.getElementById('LeftMenuOsUpdates');
            if (bo != null) bo.style.opacity = '1';
            pluginHandler.pkgmanager.pkgOsRender();
        } catch (e) { console.log('pkgmanager os open failed: ' + e); }
    };

    // kind helper: a package is an OS-update bundle when a def carries
    // kind:'os'; everything else is an app (pre-v1.4.0 defs default to app).
    obj.pkgOsKind = function (p) {
        try {
            var oses = ['linux', 'windows', 'macos'];
            for (var k = 0; k < oses.length; k++) {
                var d = ((p != null) ? p[oses[k]] : null);
                if ((d != null) && (String(d.kind || '').trim() != '')) { return String(d.kind).trim(); }
            }
        } catch (e) { }
        return '';
    };

    // v2.0.8: vista Aggiornamenti OS RIDISEGNATA — niente bundle nel catalogo:
    // menu a discesa per GRUPPO OS (release/codename), tabella del piano
    // (pacchetto, versione installata min, candidata, stato sul server
    // ✓/✗), download dei solo mancanti e install diretto dal piano.
    obj.pkgOsRender = function () {
        try {
            var m = document.getElementById('pkgmanagerMain');
            if (m == null) return;
            var osfAdm = ((typeof userinfo != 'undefined') && (userinfo != null) && (userinfo.siteadmin === 0xFFFFFFFF));
            var x = '<div style="margin-bottom:8px;font-size:16px"><b>Aggiornamenti del sistema operativo</b> <span style="color:#888;font-weight:normal;font-size:12px">(inventario per macchina — scaricamento su questo server, installazione airgap in LAN)</span></div>' + pluginHandler.pkgmanager.pkgBinBanner();
            x += '<div id="pkgmanagerPlanSelWrap" style="margin-bottom:8px"></div>';
            x += '<div style="margin-bottom:6px"><input type=button value="Scansiona macchine" onclick="pluginHandler.pkgmanager.pkgOsScan()"> ' + '<input type=button value="Installa aggiornamenti" onclick="pluginHandler.pkgmanager.pkgOsPlanInstall()"> ' + (osfAdm ? '<input type=button value="Ricalcola piano" onclick="pluginHandler.pkgmanager.pkgOsPlanRequest()" title="Ricalcola il piano senza riscansionare le macchine"> ' : '') + (osfAdm ? '<input type=button value="Esporta downloader…" title="Genera il downloader COMPILATO per la piattaforma scelta con l inventario della scansione incorporato: eseguilo su una macchina con internet, copia os-updates/ nello store (My Files) e importa il manifest — LA via per i server airgap (py = script Python)" onclick="pluginHandler.pkgmanager.pkgOsExportDownloader()"> ' : '') + '<input type=button value="Esporta report (.json)" onclick="pluginHandler.pkgmanager.pkgOsScanExport()"> <span id="pkgmanagerPlanMsg" style="color:#888"></span></div>';
            // v2.2.1: DUE RIQUADRI — sinistra macchine scansionate, destra pacchetti
            // rilevati (unici per release, deduplicati tra macchine) con selezione
            // e scarico di SOLO i selezionati.
            // v2.2.7: SEZIONI A POSIZIONE FISSA in colonna — il selettore del
            // gruppo sta sopra tutte; ogni sezione ha altezza fissa e scolle
            // DENTRO, cosi' l'ordine non si sposta mai con il contenuto.
            var secH = 380; // altezza contenuto per sezione
            var secHead = function (t, span) { return '<div style="background:#e8e8e8;border-bottom:1px solid #ddd;border-radius:6px 6px 0 0;padding:6px 10px;font-weight:bold">' + t + ((span != null) ? ' <span id="' + span + '" style="color:#888;font-weight:normal;font-size:12px"></span>' : '') + '</div>'; };
            // v2.2.8: Macchine e Pacchetti AFFIANCATI (due colonne flex), come nel layout a due riquadri
            x += '<div style="display:flex;flex-wrap:wrap;gap:10px;align-items:stretch;margin-bottom:10px">';
            x += '<div style="flex:1;min-width:280px;border:1px solid #ddd;border-radius:6px">' + secHead('Macchine scansionate', 'pkgmanagerOsMachinesSummary') + '<div id="pkgmanagerOsMachines" style="font-size:12px;height:' + secH + 'px;overflow:auto"></div></div>';
            x += '<div style="flex:1.5;min-width:340px;border:1px solid #ddd;border-radius:6px">' + secHead('Pacchetti rilevati', 'pkgmanagerOsPkgsSummary') + '<div id="pkgmanagerOsPkgs" style="font-size:12px;height:' + secH + 'px;overflow:auto"></div><div id="pkgmanagerOsPkgsActions" style="padding:6px 10px"></div></div>';
            x += '</div>';
            x += '<div style="border:1px solid #ddd;border-radius:6px;margin-bottom:10px">' + secHead('Avanzamento download') + '<div id="pkgmanagerOsFetchProg" style="font-size:12px;height:' + Math.round(secH / 2) + 'px;overflow:auto"></div></div>';
            x += '<div style="border:1px solid #ddd;border-radius:6px;margin-bottom:10px">' + secHead('Piano aggiornamenti') + '<div id="pkgmanagerPlanWrap" style="padding:6px 10px;max-height:420px;overflow:auto"></div></div>';
            x += '<div style="border:1px solid #ddd;border-radius:6px;margin-bottom:10px">' + secHead('Riassunto mancanti') + '<div id="pkgmanagerOsSummary" style="font-size:12px;height:220px;overflow:auto"></div></div>';
            x += '<div id="pkgmanagerMsg" style="margin-top:10px;color:#888"></div>';
            m.innerHTML = x;
            pluginHandler.pkgmanager.pkgOsPlanRender();
            pluginHandler.pkgmanager.pkgOsScanRender();
            pluginHandler.pkgmanager.pkgOsMachinesRender();
            pluginHandler.pkgmanager.pkgOsPkgsRender();
            pluginHandler.pkgmanager.pkgOsSummaryRender();
            pluginHandler.pkgmanager.pkgOsFetchProgRender();
        } catch (e) { console.log('pkgmanager os render failed: ' + e); }
    };

    // v2.2.7: AVANZAMENTO DOWNLOAD — riceve i progressi per-file di osfetch
    // (start/ok/fail/end) e li mostra nella sezione dedicata.
    obj.pkgOsFetchProgress = function (server, message) {
        try {
            if (message == null) { return; }
            if (window.pkgmanagerOsFetchProg == null) { window.pkgmanagerOsFetchProg = { running: false, done: 0, total: null, rows: [] }; }
            var fp = window.pkgmanagerOsFetchProg;
            fp.total = ((message.total != null) ? message.total : fp.total);
            if (message.state == 'start') { fp.running = true; }
            else if (message.state == 'end') { fp.running = false; }
            else if ((message.state == 'ok') || (message.state == 'fail')) {
                fp.done = ((message.done != null) ? message.done : fp.done + 1);
                fp.rows.push({ file: message.current, state: message.state, bytes: (message.bytes || 0), reason: message.reason });
                if (fp.rows.length > 500) { fp.rows.splice(0, fp.rows.length - 500); }
            }
            pluginHandler.pkgmanager.pkgOsFetchProgRender();
        } catch (e) { console.log('pkgmanager osfetch progress failed: ' + e); }
    };

    obj.pkgOsFetchProgRender = function () {
        try {
            var el = document.getElementById('pkgmanagerOsFetchProg');
            if (el == null) return;
            var fp = window.pkgmanagerOsFetchProg;
            if ((fp == null) || (fp.rows.length == 0)) { el.innerHTML = '<div style="color:#888">Nessun download in corso: seleziona i pacchetti in «Pacchetti rilevati» e premi «Scarica selezionati».</div>'; return; }
            var pct = ((fp.total != null) && (fp.total > 0)) ? Math.round((fp.done / fp.total) * 100) : 0;
            var x = ((fp.running ? '<div style="margin-bottom:4px">Download in corso: <b>' + fp.done + '/' + fp.total + '</b> (' + pct + '%)</div>' : '<div style="margin-bottom:4px;color:#080">Download completato: ' + fp.done + '/' + fp.total + '</div>') + '<div style="height:10px;background:#ddd;border-radius:5px;margin-bottom:6px"><div style="height:10px;background:#080;border-radius:5px;width:' + pct + '%"></div></div>');
            for (var i = 0; i < fp.rows.length; i++) {
                var r = fp.rows[i];
                x += '<div style="padding:1px 0;border-bottom:1px solid #f2f2f2">' + ((r.state == 'ok') ? '<span style="color:#080">✓</span>' : '<span style="color:#d00">✗</span>') + ' <b>' + EscapeHtml(r.file) + '</b> ' + ((r.state == 'ok') ? '<span style="color:#888">' + Math.round(r.bytes / 1048576) + ' MiB</span>' : '<span style="color:#d00;font-size:11px">' + EscapeHtml(r.reason || 'errore') + '</span>') + '</div>';
            }
            el.innerHTML = x;
        } catch (e) { console.log('pkgmanager osfetch prog render failed: ' + e); }
    };

    // v2.2.6: BARRA RIASSUNTO in fondo alla vista — una riga per gruppo
    // (release): macchine, mancanti, dimensione da scaricare, selezionati;
    // ultima riga con i totali. Si aggiorna con piano, selezioni e scan.
    obj.pkgOsSummaryRender = function () {
        try {
            var el = document.getElementById('pkgmanagerOsSummary');
            if (el == null) return;
            var run = window.pkgmanagerOsScan;
            var plan = window.pkgmanagerOsPlan;
            if (window.pkgmanagerOsSelPkg == null) { window.pkgmanagerOsSelPkg = {}; }
            var x = '<b>Riassunto mancanti</b>';
            var selTot = 0, selByte = 0;
            if ((plan == null) || (plan.groupKeys == null) || (plan.groupKeys.length == 0)) {
                x += '<span style="color:#888"> — nessun piano: premi «Scansiona macchine».</span>';
                var msum = document.getElementById('pkgmanagerOsMachinesSummary');
                if ((msum != null) && (run != null) && (run.machs != null)) { var t = 0, g = 0; for (var nm0 in run.machs) { t++; if (run.machs[nm0].got) g++; } msum.innerText = '(' + g + '/' + t + ' inventari ok)'; }
                el.innerHTML = x; return;
            }
            x += '<table style="border-collapse:collapse;margin-top:4px;width:100%">';
            x += '<tr style="text-align:left;border-bottom:1px solid #ccc"><th style="padding:3px 6px">Release</th><th style="padding:3px 6px">OS</th><th style="padding:3px 6px;text-align:right">Macchine</th><th style="padding:3px 6px;text-align:right">Mancanti</th><th style="padding:3px 6px;text-align:right">Da scaricare</th><th style="padding:3px 6px;text-align:right">In store</th><th style="padding:3px 6px;text-align:right">Selezionati</th></tr>';
            var tMach = 0, tMiss = 0, tDl = 0, tDlByte = 0, tStore = 0, tSel = 0, tSelByte = 0;
            for (var i = 0; i < plan.groupKeys.length; i++) {
                var grp = plan.groups[plan.groupKeys[i]];
                if ((grp == null) || (grp.updates == null)) { continue; }
                var rel = ((grp.codename != null) ? grp.codename : ((grp.displayVer != null) && (grp.displayVer != '') ? grp.displayVer : grp.ver));
                var miss = 0, dl = 0, dlByte = 0, store = 0;
                for (var u = 0; u < grp.updates.length; u++) {
                    var up = grp.updates[u];
                    var key = (grp.storeDirName || '?') + '/' + up.file;
                    var isSel = (window.pkgmanagerOsSelPkg[key] === true) && (up.inStore !== true);
                    if (isSel) { selTot++; selByte += (up.size || 0); tSel++; tSelByte += (up.size || 0); }
                    if (up.inStore === true) { store++; continue; }
                    miss++; tMiss++;
                    dl++; tDl++; dlByte += (up.size || 0); tDlByte += (up.size || 0);
                }
                var machN = 0; for (var mk in grp.machines) { machN++; } tMach += machN;
                x += '<tr style="border-bottom:1px solid #eee"><td style="padding:3px 6px"><b>' + EscapeHtml(rel) + '</b></td><td style="padding:3px 6px;color:#888">' + EscapeHtml(grp.os) + '</td><td style="padding:3px 6px;text-align:right">' + machN + '</td><td style="padding:3px 6px;text-align:right">' + miss + '</td><td style="padding:3px 6px;text-align:right">' + ((dlByte > 0) ? (Math.round(dlByte / 1048576) + ' MiB') : '—') + '</td><td style="padding:3px 6px;text-align:right;color:#080">' + store + '</td><td style="padding:3px 6px;text-align:right">' + selTot + '</td></tr>';
            }
            x += '<tr style="border-top:2px solid #ccc;font-weight:bold"><td style="padding:3px 6px">TOTALE</td><td style="padding:3px 6px"></td><td style="padding:3px 6px;text-align:right">' + tMach + '</td><td style="padding:3px 6px;text-align:right">' + tMiss + '</td><td style="padding:3px 6px;text-align:right">' + ((tDlByte > 0) ? (Math.round(tDlByte / 1048576) + ' MiB') : '—') + '</td><td style="padding:3px 6px;text-align:right">' + tStore + '</td><td style="padding:3px 6px;text-align:right">' + tSel + '</td></tr>';
            x += '</table>';
            if (selTot > 0) { x += '<div style="color:#888;margin-top:3px">«Scarica selezionati» scarica ' + selTot + ' pacchett' + ((selTot == 1) ? 'o' : 'i') + ' (' + Math.round(selByte / 1048576) + ' MiB) nel rispettivo store.</div>'; }
            el.innerHTML = x;
        } catch (e) { console.log('pkgmanager os summary render failed: ' + e); }
    };

    // v2.2.1: RIQUADRO MACCHINE — elenco macchine della scansione con
    // OS/codename, numero mancanti e stato dpkg.
    obj.pkgOsMachinesRender = function () {
        try {
            var el = document.getElementById('pkgmanagerOsMachines');
            if (el == null) return;
            var run = window.pkgmanagerOsScan;
            if ((run == null) || (run.machs == null)) { el.innerHTML = '<div style="color:#888">Premi «Scansiona macchine».</div>'; return; }
            var x = '';
            var n = 0;
            for (var nid in run.machs) {
                var mm = run.machs[nid];
                n++;
                var info = (mm.info != null) ? mm.info : [];
                var osLabel = EscapeHtml(mm.os || '?');
                if (mm.os == 'linux') { osLabel = ((info[0] || 'Linux') + ' ' + (info[1] || '') + ' (' + (info[2] || '?') + ')'); }
                else if (((mm.os == 'windows') || (mm.os == 'macos')) && ((info != null) && (info.length > 1) && (info[1] != null) && (info[1] != ''))) { osLabel += ' ' + info[1]; } // v2.2.3: versione OS nella riga
                var audit = ((mm.audit != null) && (mm.audit.length > 0)) ? ' <span style="color:#a60" title="' + EscapeHtml(mm.audit.join('; ')) + '">⚠ dpkg</span>' : '';
                var stato = ((mm.got == true) ? '<span style="color:#080">inventario ✓</span>' : '<span style="color:#888">in attesa…</span>');
                x += '<div style="padding:2px 0;border-bottom:1px solid #f2f2f2"><b>' + EscapeHtml(mm.name || nid) + '</b> <span style="color:#888">· ' + osLabel + '</span>' + audit + '<br><span style="color:#888;font-size:11px">' + (((mm.items != null) && (mm.got == true)) ? (mm.items.length + ' voci inventario · ') : '') + stato + '</span></div>';
            }
            if (n == 0) { x = '<div style="color:#888">Nessuna macchina nella scansione.</div>'; }
            el.innerHTML = x;
            var msum2 = document.getElementById('pkgmanagerOsMachinesSummary');
            if (msum2 != null) { var t2 = 0, g2 = 0; for (var nm2 in run.machs) { t2++; if (run.machs[nm2].got) { g2++; } } msum2.innerText = '(' + g2 + '/' + t2 + ' inventari ok)'; }
            try { pluginHandler.pkgmanager.pkgOsSummaryRender(); } catch (e5) { } // v2.2.6
        } catch (e) { }
    };

    // v2.2.1: RIQUADRO PACCHETTI — elenco univo dal piano (gia' deduplicato per
    // codename: stesso pacchetto su piu' macchine = UNA riga), con selezione
    // checkbox persistente in window.pkgmanagerOsSelPkg.
    obj.pkgOsPkgsRender = function () {
        try {
            var el = document.getElementById('pkgmanagerOsPkgs');
            if (el == null) return;
            var plan = window.pkgmanagerOsPlan;
            if ((plan == null) || (plan.groupKeys == null)) { el.innerHTML = '<div style="color:#888">Il piano si calcola al termine della scansione…</div>'; var s2 = document.getElementById('pkgmanagerOsPkgsSummary'); if (s2 != null) s2.innerText = ''; var a2 = document.getElementById('pkgmanagerOsPkgsActions'); if (a2 != null) a2.innerHTML = ''; return; }
            if (window.pkgmanagerOsSelPkg == null) { window.pkgmanagerOsSelPkg = {}; }
            var rows = [];
            var keys = plan.groupKeys;
            for (var gi = 0; gi < keys.length; gi++) {
                var grp = plan.groups[keys[gi]];
                if ((grp == null) || (grp.updates == null) || (grp.updates.length == 0)) { continue; } // v2.2.5: anche windows
                for (var ui = 0; ui < grp.updates.length; ui++) {
                    var u = grp.updates[ui];
                    rows.push({ key: grp.storeDirName + '/' + u.file, name: u.package, ver: u.version, code: ((grp.os == 'linux') ? grp.codename : ((grp.displayVer || grp.ver || grp.distro) + ' x64')), nmach: Object.keys(u.targets || {}).length, size: (u.size || 0), inStore: (u.inStore === true), title: u.title });
                }
            }
            window.pkgmanagerOsPkgsRows = rows;
            var sel = 0, totBytes = 0, selBytes = 0;
            var x = '';
            if (rows.length == 0) {
                // v2.2.4: "tutte aggiornate" era FALSO se ci sono macchine
                // windows/macos — il piano non deduce i mancanti non-Linux.
                var nonLinux = 0;
                var runS = window.pkgmanagerOsScan;
                if ((runS != null) && (runS.machs != null)) { for (var nidS in runS.machs) { var mmS = runS.machs[nidS]; if ((mmS.got == true) && (mmS.os != null) && (mmS.os != 'linux')) { nonLinux++; } } }
                if (nonLinux > 0) {
                    x = '<div style="color:#888">Nessun pacchetto Linux mancante. Per le ' + nonLinux + ' macchine Windows/macOS i mancanti non si deducono dal piano: usa «Esporta downloader…».</div>';
                } else {
                    x = '<div style="color:#888">Nessun pacchetto mancante: tutte le macchine sono aggiornate.</div>';
                }
            } else {
                x += '<div style="margin-bottom:4px"><input type=checkbox id="pkgmanagerOsPkgsAll" onchange="pluginHandler.pkgmanager.pkgOsPkgsSelAll(this.checked)"> <b>Seleziona tutte le mancanti</b></div>';
                x += '<table style="width:100%;border-collapse:collapse">';
                for (var ri = 0; ri < rows.length; ri++) {
                    var r = rows[ri];
                    var on = (window.pkgmanagerOsSelPkg[r.key] === true);
                    if (on) { sel++; selBytes += r.size; }
                    if (!r.inStore) { totBytes += r.size; }
                    x += '<tr><td style="padding:1px 4px"><input type=checkbox data-pkey="' + EscapeHtml(r.key) + '" ' + (r.inStore ? 'disabled ' : '') + (on ? 'checked' : '') + ' onchange="pluginHandler.pkgmanager.pkgOsPkgsToggle(this)"></td>';
                    x += '<td style="padding:1px 4px"><b>' + EscapeHtml(r.name) + '</b> ' + EscapeHtml(r.ver) + ((r.title != null) ? ' <span style="color:#666;font-size:11px">' + EscapeHtml(r.title) + '</span>' : '') + '</td>'; // v2.2.5: titolo catalogo per windows
                    x += '<td style="padding:1px 4px;color:#888">' + EscapeHtml(r.code) + '</td>';
                    x += '<td style="padding:1px 4px;text-align:right;color:#888">' + r.nmach + ' macch.</td>';
                    x += '<td style="padding:1px 4px;text-align:right;color:#888">' + (r.inStore ? '<span style="color:#080">✓ in store</span>' : Math.round(r.size / 1024) + ' KB') + '</td></tr>';
                }
                x += '</table>';
            }
            if ((plan.skipped != null) && (plan.skipped.length > 0)) { x = '<div style="color:#a60;font-size:11px;margin-bottom:4px">Nota del piano: ' + EscapeHtml(plan.skipped.slice(0, 3).map(function (k2) { return k2.reason; }).join(' · ')) + ((plan.skipped.length > 3) ? ' (+' + (plan.skipped.length - 3) + ')' : '') + '</div>' + x; } // v2.2.5: errori piano visibili nel riquadro
            el.innerHTML = x;
            var summ = document.getElementById('pkgmanagerOsPkgsSummary');
            if (summ != null) { summ.innerText = rows.length + ' pacchetti — selezionati: ' + sel + ' (' + Math.round(selBytes / 1048576) + ' MiB)'; }
            var act = document.getElementById('pkgmanagerOsPkgsActions');
            if (act != null) { act.innerHTML = ((rows.length > 0) ? '<input type=button value="Scarica selezionati" onclick="pluginHandler.pkgmanager.pkgOsPlanDownload()" title="Scarica SOLO i pacchetti spuntati nello store del server (union versione massima per release)">' : ''); }
            try { pluginHandler.pkgmanager.pkgOsSummaryRender(); } catch (e6) { } // v2.2.6 // v2.2.4: niente bottone a piano vuoto
        } catch (e) { }
    };

    obj.pkgOsPkgsToggle = function (cb) {
        try {
            if (window.pkgmanagerOsSelPkg == null) { window.pkgmanagerOsSelPkg = {}; }
            window.pkgmanagerOsSelPkg[cb.getAttribute('data-pkey')] = (cb.checked === true);
            pluginHandler.pkgmanager.pkgOsPkgsRender();
        } catch (e) { }
    };

    obj.pkgOsPkgsSelAll = function (on) {
        try {
            if (window.pkgmanagerOsSelPkg == null) { window.pkgmanagerOsSelPkg = {}; }
            var rows = (window.pkgmanagerOsPkgsRows || []);
            for (var i = 0; i < rows.length; i++) { if (!rows[i].inStore) { window.pkgmanagerOsSelPkg[rows[i].key] = (on === true); } }
            pluginHandler.pkgmanager.pkgOsPkgsRender();
        } catch (e) { }
    };

    // v2.0.8: richiesta piano (calcolo server, senza download).
    obj.pkgOsPlanRequest = function () {
        try {
            var run = window.pkgmanagerOsScan;
            if ((run == null) || (!run.done)) { pluginHandler.pkgmanager.pkgMsg('Nessuna scansione completata: prima fai «Scansiona macchine».'); return; }
            var machines = [];
            for (var nid in run.machs) {
                var m = run.machs[nid];
                machines.push({ id: nid, name: m.name, os: m.os, osInfo: { name: ((m.info != null) && (m.info.length > 0)) ? m.info[0] : '', version: ((m.info != null) && (m.info.length > 1)) ? m.info[1] : '', codename: ((m.info != null) && (m.info.length > 2)) ? m.info[2] : '' }, items: m.items.slice(0) });
            }
            meshserver.send({ action: 'plugin', plugin: 'pkgmanager', pluginaction: 'osplan', machines: machines });
            pluginHandler.pkgmanager.pkgMsg('Calcolo piano aggiornamenti in corso (indici vendor lato server: puo\' volere qualche minuto)…');
        } catch (e) { console.log('pkgmanager osplan request failed: ' + e); }
    };

    // v2.0.8: ricezione piano dal server.
    obj.pkgOsPlan = function (server, message) {
        try {
            if ((message == null) || (message.plan == null)) { return; }
            window.pkgmanagerOsPlan = message.plan;
            if (message.opAck != null) { pluginHandler.pkgmanager.pkgMsg(message.opAck); }
            if ((window.pkgmanagerOsFetchProg != null) && (window.pkgmanagerOsFetchProg.running == true)) { window.pkgmanagerOsFetchProg.running = false; pluginHandler.pkgmanager.pkgOsFetchProgRender(); } // v2.2.7
            pluginHandler.pkgmanager.pkgOsPlanRender();
            pluginHandler.pkgmanager.pkgOsPkgsRender(); // v2.2.1: riquadro pacchetti si aggiorna col piano
            pluginHandler.pkgmanager.pkgOsSummaryRender(); // v2.2.6
        } catch (e) { console.log('pkgmanager osplan recv failed: ' + e); }
    };

    obj.pkgOsPlanSelChange = function () {
        try { var s2 = document.getElementById('pkgmanagerOsPlanSel'); if (s2 != null) { window.pkgmanagerOsPlanSel = s2.value; } pluginHandler.pkgmanager.pkgOsPlanRender(); } catch (e) { }
    };


    // v2.0.9: gestione selezione macchine per gruppo (checkbox + tutte/nessuna).
    obj.pkgOsPlanMachToggle = function () {
        try {
            var selKey = window.pkgmanagerOsPlanSel;
            if ((window.pkgmanagerOsPlanMachSel == null) || (selKey == null) || (window.pkgmanagerOsPlanMachSel[selKey] == null)) { return; }
            var cbs = document.querySelectorAll('.pkgmanagerOsPlanMachCb');
            for (var i = 0; i < cbs.length; i++) { window.pkgmanagerOsPlanMachSel[selKey][cbs[i].value] = cbs[i].checked; }
        } catch (e) { }
    };
    obj.pkgOsPlanMachSelAll = function (on) {
        try {
            var selKey = window.pkgmanagerOsPlanSel;
            if ((selKey == null) || (window.pkgmanagerOsPlan == null) || (window.pkgmanagerOsPlan.groups[selKey] == null)) { return; }
            if (window.pkgmanagerOsPlanMachSel[selKey] == null) { window.pkgmanagerOsPlanMachSel[selKey] = {}; }
            var grp = window.pkgmanagerOsPlan.groups[selKey];
            for (var nid in grp.machines) { window.pkgmanagerOsPlanMachSel[selKey][nid] = (on === true); }
            pluginHandler.pkgmanager.pkgOsPlanRender();
        } catch (e) { }
    };
    // v2.0.8: rendering piano — menu a discesa gruppi + tabella pacchetti.
    obj.pkgOsPlanRender = function () {
        try {
            var w = document.getElementById('pkgmanagerPlanWrap');
            if (w == null) return;
            var plan = window.pkgmanagerOsPlan;
            if ((plan == null) || (plan.groupKeys == null) || (plan.groupKeys.length == 0)) {
                var nl = 0; var runP = window.pkgmanagerOsScan;
                if ((runP != null) && (runP.machs != null)) { for (var nidP in runP.machs) { var mmP = runP.machs[nidP]; if ((mmP.got == true) && (mmP.os != null) && (mmP.os != 'linux')) { nl++; } } }
                w.innerHTML = '<div style="color:#888;padding:6px">' + ((nl > 0) ? ('Nessun piano: solo macchine Windows/macOS (' + nl + ') — i mancanti arrivano dal catalogo Microsoft alla prossima scansione.') : ('Nessun piano: fai «Scansiona macchine» — il piano (pacchetti mancanti per release + stato sul server) viene calcolato al termine della scansione.')) + '</div>';
                var sw2 = document.getElementById('pkgmanagerPlanSelWrap');
                if (sw2 != null) { sw2.innerHTML = ''; }
                return; }
            var keys = plan.groupKeys;
            if ((window.pkgmanagerOsPlanSel == null) || (keys.indexOf(window.pkgmanagerOsPlanSel) < 0)) { window.pkgmanagerOsPlanSel = keys[0]; }
            var grp = plan.groups[window.pkgmanagerOsPlanSel];
            var x = '';
            var scanTime = ((window.pkgmanagerOsScan != null) && (window.pkgmanagerOsScan.started != null)) ? new Date(window.pkgmanagerOsScan.started).toLocaleTimeString() : '?';
            // v2.2.7: selettore nel SUO div sopra tutte le sezioni
            var selX = '<span style="font-weight:bold">Sistema operativo:</span> <select id="pkgmanagerOsPlanSel" onchange="pluginHandler.pkgmanager.pkgOsPlanSelChange()" style="padding:3px 6px">';
            for (var i = 0; i < keys.length; i++) {
                var g = plan.groups[keys[i]];
                var label = g.distro + ' ' + g.ver + ((g.codename != null) ? ' (' + g.codename + ')' : '') + ' — ' + Object.keys(g.machines).length + ' macchina/e';
                selX += '<option value="' + EscapeHtml(keys[i]) + '"' + (keys[i] == window.pkgmanagerOsPlanSel ? ' selected' : '') + '>' + EscapeHtml(label) + '</option>';
            }
            selX += '</select> <span style="color:#888;font-size:12px">' + ((grp.updates.length > 0) ? (grp.updates.length + ' aggiornamenti nel piano — ' + ((grp.machNames != null) ? grp.machNames.join(', ') : '') + ((grp.os == 'windows') ? ' (dal catalogo Microsoft, primissimi 30 per data)' : '')) : ((grp.os == 'windows') ? 'nessun aggiornamento mancante nel catalogo per questa release' : 'mancanti non deducibili dalla scansione (best effort)')) + '</span> <span style="color:#a60;font-size:12px">piano basato sulla scansione delle ' + EscapeHtml(scanTime) + ' — dopo un install o installazioni locali rilancia «Scansiona macchine».</span>';
            var selWrap = document.getElementById('pkgmanagerPlanSelWrap');
            if (selWrap != null) { selWrap.innerHTML = selX; }
            selX = null;
            // v2.1.2: macchine con stato dpkg incoerente (dpkg --audit non vuoto)
            var broken = [];
            try {
                var runS = window.pkgmanagerOsScan;
                if ((runS != null) && (runS.machs != null)) {
                    for (var nidB in runS.machs) {
                        var mmB = runS.machs[nidB];
                        if ((mmB.audit != null) && (mmB.audit.length > 0) && (grp.machines[nidB] != null)) { broken.push(grp.machines[nidB]); }
                    }
                }
            } catch (eB) { }
            if (broken.length > 0) {
                x += '<div style="margin-bottom:6px;padding:6px;border:1px solid #d80;border-radius:4px;background:#fff8ee"><span style="color:#a60"><b>⚠ Stato dpkg incoerente</b> su: ' + EscapeHtml(broken.join(', ')) + '</span> — ci sono dipendenze insoddisfatte (dpkg --audit non vuoto). Il piano potrebbe non elencarle tutte: esegui <code>sudo apt --fix-broken install</code> sulla macchina, o installa comunque il piano (porta anche le dipendenze mancanti).</div>';
            }
            // v2.2.5: la tabella del piano e' IDENTICA per linux e windows;
            // il blocco install-machines e il footer restano solo linux.
            var isLinux = (grp.os == 'linux');
            if ((grp.updates == null) || (grp.updates.length == 0)) {
                if (!isLinux) { x += '<div style="color:#888;padding:6px">Per ' + EscapeHtml(grp.distro) + ' nessun aggiornamento mancante nel catalogo per questa release: tutte le macchine del gruppo risultano aggiornate (o il catalogo non risponde — vedi «Ricalcola piano» e Log).</div>'; }
                else { x += '<div style="color:#080;padding:6px">Tutte le macchine del gruppo sono aggiornate.</div>'; }
                w.innerHTML = x; return;
            }
            var nMiss = 0;
            // v2.0.9: SELEZIONE MACCHINE per gruppo (non tutte insieme:
            // aggiornamenti scaglionati). Default: tutte spunte.
            if (window.pkgmanagerOsPlanMachSel == null) { window.pkgmanagerOsPlanMachSel = {}; }
            if (window.pkgmanagerOsPlanMachSel[window.pkgmanagerOsPlanSel] == null) { window.pkgmanagerOsPlanMachSel[window.pkgmanagerOsPlanSel] = {}; }
            var msel = window.pkgmanagerOsPlanMachSel[window.pkgmanagerOsPlanSel];
            var onlineMap = {};
            try { for (var oi in nodes) { var n0 = nodes[oi]; if (n0 && n0._id && ((n0.conn & 1) != 0)) { onlineMap[n0._id] = 1; } } } catch (e0) { }
            if (isLinux) { x += '<div style="margin-bottom:8px;padding:6px;border:1px solid #ddd;border-radius:4px"><b>Macchine del gruppo (installazione)</b> — <a href=# onclick="pluginHandler.pkgmanager.pkgOsPlanMachSelAll(true);return false">tutte</a> / <a href=# onclick="pluginHandler.pkgmanager.pkgOsPlanMachSelAll(false);return false">nessuna</a>';
            var machIds = Object.keys(grp.machines);
            for (var mx = 0; mx < machIds.length; mx++) {
                var mid2 = machIds[mx];
                if (msel[mid2] == null) { msel[mid2] = true; }
                var isOn = (onlineMap[mid2] != null);
                x += '<label style="display:block;padding:2px 0"><input type=checkbox class="pkgmanagerOsPlanMachCb" value="' + EscapeHtml(mid2) + '"' + (msel[mid2] ? ' checked' : '') + (isOn ? '' : ' title="al momento offline: l installazione su di lei verra rifiutata dal server"') + ' onchange="pluginHandler.pkgmanager.pkgOsPlanMachToggle()"> ' + EscapeHtml(grp.machines[mid2]) + (isOn ? ' <span style="color:#080;font-size:11px">online</span>' : ' <span style="color:#a60;font-size:11px">offline</span>') + '</label>';
            }
            x += '</div>';
            } // v2.2.5: fine blocchetto install (solo linux)
            x += '<div style="max-height:420px;overflow:auto">'; // v2.2.6: piano scrollabile
            x += '<table style="border-collapse:collapse;width:100%">';
            x += '<tr style="text-align:left;border-bottom:1px solid #ccc"><th style="padding:4px">Pacchetto</th><th style="padding:4px">Installata (min nel gruppo)</th><th style="padding:4px">Disponibile</th><th style="padding:4px">Dim.</th><th style="padding:4px">Sul server</th><th style="padding:4px">Motivo</th></tr>';
            for (var u = 0; u < grp.updates.length; u++) {
                var up = grp.updates[u];
                var st = (up.inStore === true) ? '<span style="color:#080">✓ disponibile</span>' : '<span style="color:#a60">✗ mancante</span>';
                if (up.inStore !== true) { nMiss++; }
                var motivo = ((up.reason != null) && (up.reason != '')) ? up.reason : 'aggiornamento disponibile';
                x += '<tr style="border-bottom:1px solid #eee"><td style="padding:4px">' + EscapeHtml(up.package) + '</td><td style="padding:4px;color:#888">' + EscapeHtml(up.installed || '—') + '</td><td style="padding:4px">' + EscapeHtml(up.version) + '</td><td style="padding:4px;color:#888">' + Math.round((up.size || 0) / 1024) + 'KB</td><td style="padding:4px">' + st + '</td><td style="padding:4px;color:#888;font-size:12px">' + EscapeHtml(motivo) + '</td></tr>';
            }
            x += '</table>';
            x += '<div style="margin-top:4px;color:#888;font-size:12px">' + (grp.updates.length - nMiss) + ' già nello store · ' + nMiss + ' mancanti — ' + ((isLinux) ? '«Scarica i mancanti sul server» li recupera dai repo vendor; «Installa aggiornamenti» porta le macchine del gruppo alla stessa versione (la più recente). Nota: il conteggio può superare quello di <code>apt upgrade</code> perché include anche le NUOVE dipendenze richieste dalle versioni aggiornate (colonna Motivo).' : 'il download dei .msu selezionati avviene dal catalogo Microsoft nel riquadro «Pacchetti rilevati» (Scarica selezionati).') + '</div></div>'; // v2.2.6: chiusura scroll
            w.innerHTML = x;
            try { pluginHandler.pkgmanager.pkgOsSummaryRender(); } catch (e7) { } // v2.2.6
        } catch (e) { console.log('pkgmanager osplan render failed: ' + e); }
    };

    // v2.0.8: download dei SOLO mancanti (server), poi il piano si aggiorna.
    obj.pkgOsPlanDownload = function () {
        try {
            var run = window.pkgmanagerOsScan;
            if ((run == null) || (!run.done)) { pluginHandler.pkgmanager.pkgMsg('Nessuna scansione completata: prima fai «Scansiona macchine».'); return; }
            var machines = [];
            for (var nid in run.machs) {
                var m = run.machs[nid];
                machines.push({ id: nid, name: m.name, os: m.os, osInfo: { name: ((m.info != null) && (m.info.length > 0)) ? m.info[0] : '', version: ((m.info != null) && (m.info.length > 1)) ? m.info[1] : '', codename: ((m.info != null) && (m.info.length > 2)) ? m.info[2] : '' }, items: m.items.slice(0) });
            }
            // v2.2.1: SOLO i pacchetti SELEZIONATI nel riquadro di destra
            var fsel = [];
            if (window.pkgmanagerOsSelPkg != null) { for (var sk in window.pkgmanagerOsSelPkg) { if (window.pkgmanagerOsSelPkg[sk] === true) { fsel.push(sk); } } }
            if (fsel.length == 0) { pluginHandler.pkgmanager.pkgMsg('Seleziona almeno un pacchetto nel riquadro «Pacchetti rilevati», poi «Scarica selezionati».'); return; }
            window.pkgmanagerOsFetchProg = { running: true, done: 0, total: null, rows: [] }; // v2.2.7
            pluginHandler.pkgmanager.pkgOsFetchProgRender();
            meshserver.send({ action: 'plugin', plugin: 'pkgmanager', pluginaction: 'osfetch', machines: machines, packages: fsel });
            pluginHandler.pkgmanager.pkgMsg('Download server-side avviato: ' + fsel.length + ' pacchetti selezionati — il piano si aggiorna all esito.');
        } catch (e) { pluginHandler.pkgmanager.pkgMsg('Download fallito: ' + e); }
    };

    // v2.0.8: install DIRETTO dal piano (niente bundle nel catalogo): per il
    // gruppo selezionato, download+verifica per file dallo store LAN + UN
    // dpkg -i con tutti i deb, sulle macchine del gruppo.
    obj.pkgOsPlanInstall = function () {
        try {
            var plan = window.pkgmanagerOsPlan;
            var selKey = window.pkgmanagerOsPlanSel;
            if ((plan == null) || (selKey == null) || (plan.groups[selKey] == null)) { pluginHandler.pkgmanager.pkgMsg('Nessun piano: fai «Scansiona macchine».'); return; }
            var grp = plan.groups[selKey];
            if (grp.os == 'windows') { pluginHandler.pkgmanager.pkgMsg('Installazione Windows non ancora attiva dalla vista OS (scarico nello store gia operativo): per applicare i .msu usa «Installa aggiornamenti» dopo il prossimo aggiornamento del plugin.'); return; }
            if (grp.os != 'linux') { pluginHandler.pkgmanager.pkgMsg('Install per ' + grp.os + ' non deducibile dalla scansione: usa meshos-fetch (--macos).'); return; }
            if (window.pkgmanagerToken == null) { pluginHandler.pkgmanager.pkgMsg('Token store non disponibile — attendi il caricamento del catalogo e riprova.'); return; }
            var have = grp.updates.filter(function (u) { return (u.inStore === true) && (u.sha384 != null); });
            if (have.length == 0) { pluginHandler.pkgmanager.pkgMsg('Nessun file disponibile nello store: usa «Scarica i mancanti sul server» prima di installare.'); return; }
            var missCnt = grp.updates.length - have.length;
            var base = location.origin + '/pkgstore.ashx?t=' + encodeURIComponent(window.pkgmanagerToken) + '&p=' + encodeURIComponent(grp.storeDirName + '/');
            var parts = [];
            for (var i = 0; i < have.length; i++) {
                var u = have[i]; var f = u.file;
                parts.push("curl -kfsSL -o /tmp/" + f + " '" + base + encodeURIComponent(f) + "' && echo '" + u.sha384 + "  /tmp/" + f + "' | sha384sum -c -");
            }
            var debs = have.map(function (u2) { return '/tmp/' + u2.file; });
            parts.push('sudo -n dpkg -i ' + debs.join(' '));
            var cmd = parts.join(' && ');
            // v2.0.9: solo le macchine SCELTE (checkbox per gruppo) e online;
            // offline vengono segnalate ma escluse (il server rifiuterebbe).
            var picked = [], skippedOff = [];
            var msel2 = ((window.pkgmanagerOsPlanMachSel != null) && (window.pkgmanagerOsPlanMachSel[selKey] != null)) ? window.pkgmanagerOsPlanMachSel[selKey] : {};
            var onlineMap2 = {};
            try { for (var oi2 in nodes) { var n2 = nodes[oi2]; if (n2 && n2._id && ((n2.conn & 1) != 0)) { onlineMap2[n2._id] = 1; } } } catch (e0) { }
            for (var nid3 in grp.machines) {
                if (msel2[nid3] === false) { continue; }
                if (onlineMap2[nid3] != null) { picked.push(nid3); } else { skippedOff.push(grp.machines[nid3]); }
            }
            var online = picked;
            if (online.length == 0) { pluginHandler.pkgmanager.pkgMsg('Nessuna macchina selezionata online' + ((skippedOff.length > 0) ? (' (' + skippedOff.join(', ') + ' offline)') : '') + ' — spunta le macchine da aggiornare (online) e riprova.'); return; }
            var hasD2Dialog = (typeof d2runBegin == 'function');
            var responseid = hasD2Dialog ? d2runBegin(online) : pluginHandler.pkgmanager.pkgD2Pending(online);
            meshserver.send({ action: 'runcommands', nodeids: online, type: 3, cmds: cmd, runAsUser: 0, reply: true, responseid: responseid, timeout: 1800 });
            pluginHandler.pkgmanager.pkgMsg('Installazione aggiornamenti (' + grp.distro + ' ' + grp.ver + ') avviata su ' + online.length + ' macchina/e — ' + have.length + ' pacchetti' + ((missCnt > 0) ? (' (' + missCnt + ' NON nello store: scaricali prima)') : '') + ((skippedOff.length > 0) ? (' — offline saltate: ' + skippedOff.join(', ')) : '') + (hasD2Dialog ? ' — output nel dialogo dei risultati.' : ' — riepilogo qui a fine esecuzione.'));
            if (!hasD2Dialog) { pluginHandler.pkgmanager.pkgD2PollSummary(responseid, Date.now(), 'Installazione aggiornamenti completata', 2040000); }
        } catch (e) { pluginHandler.pkgmanager.pkgMsg('Install fallito: ' + e); }
    };

    // ---- v1.6.0: OS-update inventory scanner (all online machines) ----
    // Sends ONE per-OS inventory command to every online machine using the
    // same reply channel as Run Commands (own responseid in d2runPending,
    // polled — no modal). Linux: os-release + dpkg-query list. Windows:
    // caption/build + Get-HotFix. macOS: sw_vers + softwareupdate history.
    obj.pkgOsScan = function () {
        try {
            var machs = [];
            try { for (var i in nodes) { var n = nodes[i]; if (n && n._id && ((n.conn & 1) != 0)) { machs.push(n); } } } catch (e) { }
            if (machs.length == 0) { pluginHandler.pkgmanager.pkgMsg('Nessuna macchina connessa da scansionare.'); return; }
            var groups = {};
            for (var i2 = 0; i2 < machs.length; i2++) {
                var os = pluginHandler.pkgmanager.pkgTargetOs(machs[i2]);
                if (groups[os] == null) { groups[os] = []; }
                groups[os].push(machs[i2]._id);
            }
            var allids = [];
            for (var g in groups) { allids = allids.concat(groups[g]); }
            // v2.0.5 FIX: l'ordine era rotto (pkgD2Pending chiamata PRIMA che
            // allids esistesse + riga morta su d2runPending, assente
            // sull'ufficiale) -> pkgOsScan moriva in silenzio nel try/catch.
            var rid = pluginHandler.pkgmanager.pkgD2Pending(allids);
            window.pkgmanagerOsScan = { rid: rid, started: Date.now(), done: false, machs: {} };
            for (var j2 = 0; j2 < machs.length; j2++) { window.pkgmanagerOsScan.machs[machs[j2]._id] = { name: machs[j2].name, os: pluginHandler.pkgmanager.pkgTargetOs(machs[j2]), info: null, items: [], got: false }; }
            for (var os2 in groups) {
                var cmd = null, type = 3;
                if (os2 == 'linux') {
                    type = 3;
                    // v2.0.6: tr -d '"' — VERSION_ID su Ubuntu arriva QUOTATO
                    // ("26.04"); il codename finisce nell URL dei repo vendor.
                    cmd = 'printf "__osinfo:%s|%s|%s\\n" "$(grep ^NAME= /etc/os-release | cut -d= -f2 | tr -d \'"\')" "$(grep ^VERSION_ID= /etc/os-release | cut -d= -f2 | tr -d \'"\')" "$(grep ^VERSION_CODENAME= /etc/os-release | cut -d= -f2 | tr -d \'"\')" ; dpkg-query -W -f=\'${db:Status-Abbrev} ${Package} ${Version}\\n\' 2>/dev/null | grep -E \'^.i \' | sed -E \'s/^... //\' ; echo \'__audit:start\' ; dpkg --audit 2>/dev/null | sed -n \'1,50p\'';
                } else if (os2 == 'windows') {
                    type = 2;
                    // v2.0.6: la colonna Versione mostrava la versione API di
                    // Windows (10.0.x ANCHE su Windows 11 — comportamento
                    // noto): usa la release REALE dal registry (DisplayVersion,
                    // es. 25H2) con il build tra parentesi.
                    cmd = '$c = Get-CimInstance Win32_OperatingSystem; $r = Get-ItemProperty \'HKLM:\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\'; $dv = $r.DisplayVersion; if ($dv -eq $null) { $dv = $r.ReleaseId }; Write-Output "__osinfo:$($c.Caption)|$dv ($($c.Version))"; Get-HotFix | ForEach-Object { Write-Output "$($_.HotFixID) $($_.Description)" }';
                } else {
                    type = 3;
                    cmd = 'echo "__osinfo:$(sw_vers -productName)|$(sw_vers -productVersion)|$(sw_vers -buildVersion)" ; softwareupdate --history 2>/dev/null | tail -30';
                }
                meshserver.send({ action: 'runcommands', nodeids: groups[os2], type: type, cmds: cmd, runAsUser: 0, reply: true, responseid: rid, timeout: 120 });
            }
            pluginHandler.pkgmanager.pkgMsg('Scansione avviata su ' + machs.length + ' macchina/e online — inventari in arrivo, poi «Scarica aggiornamenti» per far scaricare i mancanti al server (amministratore).');
            pluginHandler.pkgmanager.pkgOsScanRender();
            pluginHandler.pkgmanager.pkgOsScanPoll();
        } catch (e) { console.log('pkgmanager os scan failed: ' + e); }
    };

    // Parse ONE machine's raw inventory: first "__osinfo:a|b|c" line, then
    // one "name rest..." item per line (dpkg / KB / history rows).
    obj.pkgOsScanParse = function (raw) {
        var out = { info: null, items: [], audit: null };
        var auditMode = false;
        try {
            var lines = String(raw || '').split(/\r?\n/);
            for (var i = 0; i < lines.length; i++) {
                var t = lines[i].trim();
                if (t == '') { continue; }
                if (t.indexOf('__audit:start') === 0) { auditMode = true; continue; } // v2.1.2
                if (auditMode) { if (out.audit == null) { out.audit = []; } out.audit.push(t); continue; }
                if ((out.info == null) && (t.indexOf('__osinfo:') === 0)) {
                    out.info = t.slice(9).split('|');
                    continue;
                }
                if (t.indexOf('__osinfo:') === 0) { continue; }
                out.items.push(t);
            }
        } catch (e) { }
        return out;
    };

    // Poll the pending scan (1s) until every machine answered or 180s cap.
    obj.pkgOsScanPoll = function () {
        try {
            var run = window.pkgmanagerOsScan;
            if ((run == null) || (run.done)) { return; }
            var p = ((window.pkgmanagerD2 != null) && (window.pkgmanagerD2[run.rid] != null)) ? window.pkgmanagerD2[run.rid] : null;
            var got = 0, total = 0;
            if (p != null) {
                for (var nid in run.machs) {
                    var r = p.results[nid];
                    if (r == null) { continue; }
                    var parsed = pluginHandler.pkgmanager.pkgOsScanParse(r);
                    run.machs[nid].info = parsed.info;
                    run.machs[nid].items = parsed.items;
                    run.machs[nid].audit = parsed.audit; // v2.1.2
                    run.machs[nid].got = true;
                }
            }
            for (var nid2 in run.machs) { total++; if (run.machs[nid2].got) { got++; } }
            pluginHandler.pkgmanager.pkgOsScanRender();
            if ((got < total) && ((Date.now() - run.started) < 180000)) {
                setTimeout(function () { pluginHandler.pkgmanager.pkgOsScanPoll(); }, 1000);
            } else {
                try { delete window.pkgmanagerD2[run.rid]; } catch (e2) { }
                run.done = true;
                pluginHandler.pkgmanager.pkgOsScanRender();
                pluginHandler.pkgmanager.pkgOsMachinesRender(); // v2.2.1
                pluginHandler.pkgmanager.pkgOsPlanRequest(); // v2.0.8: piano automatico a scansione finita
                pluginHandler.pkgmanager.pkgMsg('Scansione completata: ' + got + '/' + total + ' macchine — «Scarica aggiornamenti» fa scaricare i pacchetti mancanti al server e crea il bundle da solo.');
            }
        } catch (e) { console.log('pkgmanager os scan poll failed: ' + e); }
    };

    // Per-machine scan table (machine, OS, level, item count, stato).
    // v2.2.3: la tabella "Scansione aggiornamenti OS" e' stata tolta: le
    // stesse informazioni (versione OS, voci inventario, stato) stanno nelle
    // righe del riquadro "Macchine scansionate". Il render esiste solo per
    // non toccare i punti di poll/call esistenti.
    obj.pkgOsScanRender = function () {
        try { pluginHandler.pkgmanager.pkgOsMachinesRender(); } catch (e) { console.log('pkgmanager os scan render failed: ' + e); }
    };

    // Download the scan report as JSON (the downloader's input file).
    obj.pkgOsScanExport = function () {
        try {
            var run = window.pkgmanagerOsScan;
            if ((run == null) || (!run.done)) { pluginHandler.pkgmanager.pkgMsg('Nessuna scansione completata da esportare: prima fai «Scansiona macchine».'); return; }
            var machines = [];
            for (var nid in run.machs) {
                var m = run.machs[nid];
                machines.push({ id: nid, name: m.name, os: m.os, osInfo: { name: ((m.info != null) && (m.info.length > 0)) ? m.info[0] : '', version: ((m.info != null) && (m.info.length > 1)) ? m.info[1] : '', codename: ((m.info != null) && (m.info.length > 2)) ? m.info[2] : '' }, items: m.items.slice(0) });
            }
            var report = { tool: 'pkgmanager', pluginVersion: '1.8.0', generated: new Date().toISOString(), machines: machines };
            var blob = new Blob([JSON.stringify(report, null, 2)], { type: 'application/json' });
            var a = document.createElement('a');
            var d = new Date();
            a.href = URL.createObjectURL(blob);
            a.download = 'os-scan-' + d.getFullYear() + ('0' + (d.getMonth() + 1)).slice(-2) + ('0' + d.getDate()).slice(-2) + '-' + ('0' + d.getHours()).slice(-2) + ('0' + d.getMinutes()).slice(-2) + '.json';
            document.body.appendChild(a); a.click();
            setTimeout(function () { try { URL.revokeObjectURL(a.href); a.remove(); } catch (e) { } }, 2000);
            pluginHandler.pkgmanager.pkgMsg('Report esportato (' + machines.length + ' macchine) — fallback meshos-fetch: il percorso principale è «Scarica aggiornamenti» nel server.');
        } catch (e) { pluginHandler.pkgmanager.pkgMsg('Esportazione fallita: ' + e); }
    };

    // v1.7.0: «Scarica aggiornamenti» — the INTEGRATED downloader. Sends the
    // completed scan inventory to the server, which fetches the vendor
    // indexes, computes the missing updates per Linux machine (delta +
    // dependency closure), downloads the .deb files DIRECTLY into
    // store/<bundle-id>/ and builds+saves the kind:'os' bundle by itself
    // (through the v1.6.1 import path: every file re-verified server-side,
    // admin-guarded). The managed machines never touch the internet —
    // installs keep flowing from THIS server over the LAN. Windows/macOS
    // machines come back as "skipped" in the bundle description (best
    // effort: meshos-fetch.js --kb/--macos stays the fallback).
    // v1.9.0: «Esporta downloader…» — COMPILED, one binary per OS (like the
    // meshagents). Asks the platform (auto-detected from the admin browser),
    // the SERVER patches the scan inventory into the binary's embedded slot
    // and serves it over /pkgstore.ashx (LAN). THE flow for an AIRGAP server:
    // run it on any machine with internet, copy os-updates/ into the store
    // (My Files -> Pacchetti (pkgmanager)) and «Importa manifest…».
    // 'py' keeps the v1.8.0 stand-alone Python script as the fallback.
    obj.pkgOsExportDownloader = function () {
        try {
            var run = window.pkgmanagerOsScan;
            if ((run == null) || (!run.done)) { pluginHandler.pkgmanager.pkgMsg('Nessuna scansione completata: prima fai «Scansiona macchine».'); return; }
            var guess = 'linux-x64';
            try {
                var np = (String(navigator.platform || '') + ' ' + String(navigator.userAgent || '')).toLowerCase();
                if (np.indexOf('win') >= 0) { guess = 'win-x64'; }
                else if (np.indexOf('mac') >= 0) { guess = ((np.indexOf('arm64') >= 0) ? 'macos-arm64' : 'macos-x64'); }
            } catch (e2) { }
            // v1.9.2: menu a discesa inline invece del prompt testuale
            var bar = document.getElementById('pkgOsExportBar');
            if (bar == null) {
                bar = document.createElement('div');
                bar.id = 'pkgOsExportBar';
                bar.style.cssText = 'margin:8px 0;padding:10px;border:1px solid #bbb;border-radius:6px;background:#f9f9f9;display:none';
                var sum = document.getElementById('pkgmanagerPkgSummary');
                var tw = document.getElementById('pkgmanagerTableWrap');
                if ((sum != null) && (sum.parentNode != null) && (sum.parentNode.parentNode != null)) { sum.parentNode.parentNode.insertBefore(bar, sum.parentNode.nextSibling); }
                else if (tw != null) { tw.parentNode.insertBefore(bar, tw); }
                else { bar.style.cssText += ';position:fixed;top:60px;left:40%;z-index:1000'; document.body.appendChild(bar); }
                bar.innerHTML = '<span style="font-weight:bold">Piattaforma del downloader compilato:</span> <select id="pkgOsExportSel" style="padding:3px 5px">' +
                    '<option value="linux-x64">Linux 64 bit (linux-x64)</option>' +
                    '<option value="linux-arm64">Linux ARM64 (linux-arm64)</option>' +
                    '<option value="linux-arm">Linux ARM (linux-arm)</option>' +
                    '<option value="win-x64">Windows 64 bit (win-x64)</option>' +
                    '<option value="win-x86">Windows 32 bit (win-x86)</option>' +
                    '<option value="macos-x64">macOS Intel (macos-x64)</option>' +
                    '<option value="macos-arm64">macOS Apple Silicon (macos-arm64)</option>' +
                    '<option value="py">Script Python standalone (py)</option>' +
                    '</select> <input type=button value="Esporta" onclick="pluginHandler.pkgmanager.pkgOsExportGo()"> <input type=button value="Annulla" onclick="var b=document.getElementById(\'pkgOsExportBar\'); if(b!=null){b.style.display=\'none\';}">';
            }
            var sel = document.getElementById('pkgOsExportSel');
            if (sel != null) { sel.value = guess; }
            bar.style.display = '';
        } catch (e) { pluginHandler.pkgmanager.pkgMsg('Esportazione fallita: ' + e); }
    };

    // v1.9.2: conferma del menu a discesa — costruisce e invia la richiesta
    obj.pkgOsExportGo = function () {
        try {
            var sel = document.getElementById('pkgOsExportSel');
            var xplat = (sel != null) ? String(sel.value) : '';
            if (xplat.trim() == '') { pluginHandler.pkgmanager.pkgMsg('Seleziona una piattaforma.'); return; }
            var bar = document.getElementById('pkgOsExportBar');
            if (bar != null) { bar.style.display = 'none'; }
            var run = window.pkgmanagerOsScan;
            var machines = [];
            for (var nid in run.machs) {
                var m = run.machs[nid];
                machines.push({ id: nid, name: m.name, os: m.os, osInfo: { name: ((m.info != null) && (m.info.length > 0)) ? m.info[0] : '', version: ((m.info != null) && (m.info.length > 1)) ? m.info[1] : '', codename: ((m.info != null) && (m.info.length > 2)) ? m.info[2] : '' }, items: m.items.slice(0) });
            }
            meshserver.send({ action: 'plugin', plugin: 'pkgmanager', pluginaction: 'exportdownloader', platform: xplat.trim(), machines: machines });
            pluginHandler.pkgmanager.pkgMsg('Generazione del downloader ' + xplat.trim() + ' in corso (inventario incorporato)…');
        } catch (e) { pluginHandler.pkgmanager.pkgMsg('Esportazione fallita: ' + e); }
    };

    // v1.9.0: server reply carrying the export. Binary path: the patched
    // per-platform binary sits in store/_downloader/ (inventory embedded,
    // patched byte-for-byte server-side) — fetched over /pkgstore.ashx (LAN)
    // and saved. Python path (platform 'py'): the script text arrives in the
    // message and is saved directly.
    obj.pkgDownloaderReady = function (server, message) {
        try {
            var m = (message != null) ? message : {};
            if (m.platform != null) {
                var fn = String(m.file || ('meshos-downloader-' + m.platform));
                var url = location.origin + '/pkgstore.ashx?t=' + encodeURIComponent(window.pkgmanagerToken) + '&p=' + encodeURIComponent('_downloader/' + fn);
                fetch(url).then(function (r) {
                    if (!r.ok) { throw new Error('HTTP ' + r.status); }
                    return r.blob();
                }).then(function (blob) {
                    var a = document.createElement('a');
                    a.href = URL.createObjectURL(blob);
                    a.download = fn;
                    document.body.appendChild(a); a.click();
                    setTimeout(function () { try { URL.revokeObjectURL(a.href); a.remove(); } catch (e3) { } }, 2000);
                    var runCmd = ((String(m.platform).indexOf('win') === 0) ? (fn + ' --max 3') : ('chmod +x ' + fn + ' && ./' + fn + ' --max 3'));
                    pluginHandler.pkgmanager.pkgMsg('Downloader COMPILATO esportato: ' + fn + ' (' + Math.round(blob.size / 1048576) + 'MB, inventario incorporato) — su una macchina con internet: ' + runCmd + ' (o senza --max per tutto) → copia os-updates/ nello store (My Files) → «Importa manifest…».');
                }).catch(function (err) { pluginHandler.pkgmanager.pkgMsg('Download del downloader fallito: ' + err); });
                return;
            }
            var script = String(m.script || '');
            if (script == '') { pluginHandler.pkgmanager.pkgMsg('Il server non ha prodotto il downloader.'); return; }
            var blob2 = new Blob([script], { type: 'text/x-python' });
            var a2 = document.createElement('a');
            a2.href = URL.createObjectURL(blob2);
            a2.download = String(m.filename || 'meshos-downloader.py');
            document.body.appendChild(a2); a2.click();
            setTimeout(function () { try { URL.revokeObjectURL(a2.href); a2.remove(); } catch (e4) { } }, 2000);
            pluginHandler.pkgmanager.pkgMsg('Downloader Python esportato: ' + a2.download + ' (' + Math.round(script.length / 1024) + 'KB, inventario incorporato) — eseguilo con python3 su una macchina con internet, copia os-updates/ nello store (My Files) e «Importa manifest…».');
        } catch (e) { pluginHandler.pkgmanager.pkgMsg('Esportazione fallita: ' + e); }
    };

    obj.pkgOsTable = function () {
        try {
            var cat = window.pkgmanagerCatalog;
            var w = document.getElementById('pkgmanagerTableWrap');
            if ((cat == null) || (cat.packages == null) || (w == null)) return;
            var bundles = [];
            for (var i = 0; i < cat.packages.length; i++) {
                if (pluginHandler.pkgmanager.pkgOsKind(cat.packages[i]) == 'os') { bundles.push(cat.packages[i]); }
            }
            var sel = pluginHandler.pkgmanager.pkgSelectedNodes();
            var oses = {}; for (var q = 0; q < sel.length; q++) { oses[pluginHandler.pkgmanager.pkgTargetOs(sel[q])] = 1; }
            var osList = Object.keys(oses);
            var shown = [];
            for (var q2 = 0; q2 < bundles.length; q2++) {
                var p2 = bundles[q2]; var okp = true;
                for (var k2 = 0; k2 < osList.length; k2++) { if (p2[osList[k2]] == null) { okp = false; break; } }
                if (okp) { shown.push(p2); }
            }
            var note = document.getElementById('pkgmanagerFilterNote');
            if (note != null) { note.innerText = (osList.length ? ('(' + shown.length + ' di ' + bundles.length + ' mostrati — OS di destinazione: ' + osList.join(', ') + ')') : '(' + bundles.length + ' di ' + bundles.length + ' — seleziona le macchine per filtrare per OS)'); }
            w.innerHTML = pluginHandler.pkgmanager.pkgTableHtml(shown, 'sidebar', osList);
            var sum = document.getElementById('pkgmanagerSelSummary');
            if (sum != null) { sum.innerText = (sel.length ? (sel.length + ' macchina/e selezionata/e — Install gira su TUTTE, raggruppate per OS.') : 'Seleziona le macchine di destinazione a destra; l\'elenco dei bundle si filtra per i loro OS.'); }
            pluginHandler.pkgmanager.pkgPkgSummary();
        } catch (e) { console.log('pkgmanager os table failed: ' + e); }
    };

    obj.pkgTableHtml = function (pkgs, mode, osList) {
        try {
            var sidebar = (mode == 'sidebar');
            var click = 'pluginHandler.pkgmanager.pkgInstall'; // per-row Install kept in the per-device tab mode only
            var x = '<table style="border-collapse:collapse;width:100%">';
            x += '<tr style="text-align:left;border-bottom:1px solid #ccc">' + (sidebar ? '<th style="padding:4px;width:26px"></th>' : '') + '<th style="padding:4px">Pacchetto</th><th style="padding:4px">OS</th><th style="padding:4px">Descrizione</th><th style="padding:4px"></th></tr>';
            for (var i = 0; i < ((pkgs != null) ? pkgs.length : 0); i++) {
                var p = pkgs[i];
                var osl = [];
                if (p.linux != null) { osl.push('Linux'); }
                if (p.windows != null) { osl.push('Windows'); }
                if (p.macos != null) { osl.push('macOS'); }
                // Airgap: a def that needs a store artifact missing on the server
                // gets its Install button disabled (drop the file on the server).
                var missing = false;
                if (mode == 'sidebar') {
                    for (var k = 0; k < ((osList != null) ? osList.length : 0); k++) {
                        var def = p[osList[k]];
                        if ((def != null) && (def.artifact != null) && ((def.artifactMissing === true) || (def.sha384 == null))) { missing = true; break; }
                    }
                }
                // v1.2.0: SELECTABLE rows. Sidebar mode has NO per-row button —
                // ONE "Installa selezionati" + ONE "Elimina selezionati" above the
                // table run the whole batch (selection kept in
                // window.pkgmanagerSelPkg so re-renders never lose it).
                var cbtd = '';
                if (sidebar) {
                    var on = ((window.pkgmanagerSelPkg != null) && (window.pkgmanagerSelPkg[p.id] === true));
                    cbtd = '<td style="padding:4px;width:26px"><input type=checkbox class="pkgmanagerPkgCb" value="' + EscapeHtml(p.id) + '"' + (on ? ' checked' : '') + (missing ? ' title="Artefatto mancante nello store: l\'installazione verra rifiutata"' : '') + ' onchange="pluginHandler.pkgmanager.pkgPkgToggle()"></td>';
                }
                var btntd = '<td style="padding:4px"></td>';
                if (!sidebar) {
                    var btn = (missing
                        ? '<input type=button value="Install" disabled title="Artefatto mancante nello store del server (plugins/pkgmanager/store/' + EscapeHtml(p.id) + ')" style="opacity:0.5">'
                        : '<input type=button value="Install" onclick="' + click + '(\'' + EscapeHtml(p.id) + '\')">');
                    btntd = '<td style="padding:4px">' + btn + '</td>';
                }
                // v2.0.7: i bundle OS (def.artifacts[]) mostrano il CONTENUTO
                // per OS: numero + elenco file in un <details> espandibile.
                var contents = '';
                var oslB = ['linux', 'windows', 'macos'];
                for (var cb = 0; cb < oslB.length; cb++) {
                    var defB = p[oslB[cb]];
                    if ((defB == null) || (Array.isArray(defB.artifacts) !== true) || (defB.artifacts.length == 0)) { continue; }
                    var lstB = defB.artifacts;
                    var visB = lstB.slice(0, 25).map(function (s) { return EscapeHtml(String(s)); }).join('<br>');
                    contents += '<div style="margin-top:4px"><b>' + oslB[cb] + '</b>: ' + lstB.length + ' file <details style="display:inline-block"><summary style="cursor:pointer;color:#06c;font-size:11px">elenco</summary><div style="font-size:11px;color:#555;max-height:200px;overflow-y:auto;word-break:break-all;padding:4px;border:1px solid #ddd;border-radius:4px;margin-top:4px;max-width:420px">' + visB + ((lstB.length > 25) ? '<br>… <i>+' + (lstB.length - 25) + ' altri</i>' : '') + '</div></details></div>';
                }
                var descHtml = EscapeHtml(p.description || '');
                if (contents != '') { descHtml += contents; }
                x += '<tr style="border-bottom:1px solid #eee">' + cbtd + '<td style="padding:4px"><b>' + EscapeHtml(p.name) + '</b></td><td style="padding:4px">' + EscapeHtml(osl.join(', ')) + '</td><td style="padding:4px">' + descHtml + '</td>' + btntd + '</tr>';
            }
            x += '</table>';
            return x;
        } catch (e) { return '<div style="color:red">render error</div>'; }
    };

    // MULTI-TARGET install: run the package on ALL selected machines in ONE
    // pending/results dialog. Group the targets by OS, open a single d2runBegin
    // tracking every nodeid, then send one rights-checked runcommands per OS
    // group reusing that responseid. Airgap: each group command is composed from
    // the group OS def ({{url}} LAN artifact URL + {{sha384}} verification).
    // v1.2.0 — package SELECTION (checkbox rows) + batch Install/Delete.
    // Selection lives in window.pkgmanagerSelPkg so a table re-render (e.g.
    // a machine checkbox change) never loses it; the summary counts it.
    obj.pkgPkgToggle = function () {
        try {
            if (window.pkgmanagerSelPkg == null) { window.pkgmanagerSelPkg = {}; }
            var cbs = document.querySelectorAll('.pkgmanagerPkgCb');
            for (var i = 0; i < cbs.length; i++) { window.pkgmanagerSelPkg[cbs[i].value] = cbs[i].checked; }
            pluginHandler.pkgmanager.pkgPkgSummary();
        } catch (e) { }
    };
    obj.pkgPkgSelectAll = function (on) {
        try {
            if (window.pkgmanagerSelPkg == null) { window.pkgmanagerSelPkg = {}; }
            var cbs = document.querySelectorAll('.pkgmanagerPkgCb');
            for (var i = 0; i < cbs.length; i++) { cbs[i].checked = (on === true); window.pkgmanagerSelPkg[cbs[i].value] = (on === true); }
            pluginHandler.pkgmanager.pkgPkgSummary();
        } catch (e) { }
    };
    obj.pkgPkgSummary = function () {
        try {
            var el = document.getElementById('pkgmanagerPkgSummary');
            if (el == null) return;
            var n = 0;
            var cbs = document.querySelectorAll('.pkgmanagerPkgCb');
            for (var i = 0; i < cbs.length; i++) { if (cbs[i].checked) { n++; } }
            el.innerText = (n > 0) ? (n + ' pacchett' + ((n == 1) ? 'o selezionato' : 'i selezionati')) : 'nessun pacchetto selezionato';
        } catch (e) { }
    };
    // BATCH RUN: every selected package x every selected machine. One
    // runcommands per OS|type group, the group's package commands joined
    // with newlines so each machine reports ONE combined result in the
    // shared pending/results dialog. Delete runs the optional per-OS
    // "uninstall" command (no artifact required).
    obj.pkgBatchRun = function (kind) {
        try {
            var cat = window.pkgmanagerCatalog;
            if ((cat == null) || (cat.packages == null)) { pluginHandler.pkgmanager.pkgMsg('Catalogo non caricato.'); return; }
            pluginHandler.pkgmanager.pkgPkgToggle(); // sync checkboxes -> store
            var selPkg = [];
            var cbs = document.querySelectorAll('.pkgmanagerPkgCb');
            for (var i = 0; i < cbs.length; i++) {
                if (!cbs[i].checked) { continue; }
                for (var j = 0; j < cat.packages.length; j++) { if (cat.packages[j].id == cbs[i].value) { selPkg.push(cat.packages[j]); break; } }
            }
            if (selPkg.length == 0) { pluginHandler.pkgmanager.pkgMsg('Seleziona almeno un pacchetto (checkbox a sinistra).'); return; }
            var sel = pluginHandler.pkgmanager.pkgSelectedNodes();
            if (sel.length == 0) { pluginHandler.pkgmanager.pkgMsg('Seleziona almeno una macchina di destinazione a destra.'); return; }
            var groups = {}, allids = [];
            for (var i = 0; i < sel.length; i++) {
                var n = sel[i];
                if ((n.conn & 1) == 0) { continue; }
                var os = pluginHandler.pkgmanager.pkgTargetOs(n);
                if (groups[os] == null) { groups[os] = []; }
                groups[os].push(n._id); allids.push(n._id);
            }
            if (allids.length == 0) { pluginHandler.pkgmanager.pkgMsg('Nessuna macchina connessa selezionata.'); return; }
            var sends = {};
            for (var os in groups) {
                for (var pi = 0; pi < selPkg.length; pi++) {
                    var pkg = selPkg[pi];
                    var def = pkg[os];
                    if (def == null) { pluginHandler.pkgmanager.pkgMsg('"' + pkg.name + '" non ha una definizione per ' + os + '.'); return; }
                    var cmd = null;
                    if (kind == 'delete') {
                        if ((def.uninstall == null) || (String(def.uninstall).trim() == '')) {
                            if (String(def.kind || '') == 'os') { continue; } // v1.6.0: OS bundle without uninstall: skipped, not fatal
                            pluginHandler.pkgmanager.pkgMsg('"' + pkg.name + '" (' + os + '): comando di disinstallazione mancante — aggiungilo in «Gestione pacchetti» o «Creazione pacchetti».'); return;
                        }
                        cmd = pluginHandler.pkgmanager.pkgCompose(pkg, { type: def.type, cmd: String(def.uninstall), timeout: def.timeout });
                    } else {
                        cmd = pluginHandler.pkgmanager.pkgCompose(pkg, def);
                    }
                    if (cmd == null) { pluginHandler.pkgmanager.pkgMsg('"' + pkg.name + '" (' + os + '): artefatto mancante nello store — copialo in plugins/pkgmanager/store/' + EscapeHtml(pkg.id) + '/ sul server.'); return; }
                    var key = os + '|' + def.type;
                    if (sends[key] == null) { sends[key] = { type: def.type, cmds: [], timeout: 0, nodeids: groups[os] }; }
                    sends[key].cmds.push(String(cmd));
                    var to = (def.timeout || 300); if (to > sends[key].timeout) { sends[key].timeout = to; }
                }
            }
            // v2.0.2: se c'è il dialogo del fork (d2runBegin) usalo; altrimenti
            // pending interno + riassunto via pkgMsg (UI ufficiale).
            var hasD2Dialog = (typeof d2runBegin == 'function');
            var responseid = hasD2Dialog ? d2runBegin(allids) : pluginHandler.pkgmanager.pkgD2Pending(allids);
            for (var key in sends) {
                var g = sends[key];
                meshserver.send({ action: 'runcommands', nodeids: g.nodeids, type: g.type, cmds: g.cmds.join('\n'), runAsUser: 0, reply: true, responseid: responseid, timeout: g.timeout });
            }
            pluginHandler.pkgmanager.pkgMsg(((kind == 'delete') ? 'Eliminazione' : 'Installazione') + ' airgap di ' + selPkg.length + ' pacchett' + ((selPkg.length == 1) ? 'o' : 'i') + ' su ' + allids.length + ' macchina/e avviata — artefatti serviti da questo server in LAN' + (hasD2Dialog ? '; output nel dialogo dei risultati.' : '; riepilogo qui a fine esecuzione.'));
            if (!hasD2Dialog) { pluginHandler.pkgmanager.pkgD2PollSummary(responseid, Date.now(), ((kind == 'delete') ? 'Eliminazione' : 'Installazione') + ' completata', (sends[key] != null ? ((parseInt(sends[key].timeout) || 300) + 120) * 1000 : 420000)); }
        } catch (e) { console.log('pkgmanager batch run failed: ' + e); }
    };

    // Compose and run on ONE machine (per-device tab path).
    obj.pkgRunOn = function (n, pkgid) {
        try {
            var cat = window.pkgmanagerCatalog;
            if ((cat == null) || (cat.packages == null)) { pluginHandler.pkgmanager.pkgMsg('Catalogo non caricato.'); return; }
            var pkg = null;
            for (var i = 0; i < cat.packages.length; i++) { if (cat.packages[i].id == pkgid) { pkg = cat.packages[i]; break; } }
            if (pkg == null) { pluginHandler.pkgmanager.pkgMsg('Pacchetto sconosciuto.'); return; }
            if ((n == null) || ((n.conn & 1) == 0)) { pluginHandler.pkgmanager.pkgMsg('Dispositivo di destinazione non connesso.'); return; }
            var os = pluginHandler.pkgmanager.pkgTargetOs(n);
            var def = pkg[os];
            if (def == null) { pluginHandler.pkgmanager.pkgMsg('Nessun install per questo OS (' + os + ').'); return; }
            var cmd = pluginHandler.pkgmanager.pkgCompose(pkg, def);
            if (cmd == null) { pluginHandler.pkgmanager.pkgMsg('"' + pkg.name + '" (' + os + '): artefatto mancante nello store del server.'); return; }
            var hasD2Dialog2 = (typeof d2runBegin == 'function');
            var responseid = hasD2Dialog2 ? d2runBegin([n._id]) : pluginHandler.pkgmanager.pkgD2Pending([n._id]);
            meshserver.send({ action: 'runcommands', nodeids: [n._id], type: def.type, cmds: cmd, runAsUser: 0, reply: true, responseid: responseid, timeout: (def.timeout || 300) });
            pluginHandler.pkgmanager.pkgMsg('Installazione airgap di "' + pkg.name + '" avviata su ' + n.name + (hasD2Dialog2 ? ' — output nel dialogo dei risultati.' : ' — riepilogo qui a fine esecuzione.'));
            if (!hasD2Dialog2) { pluginHandler.pkgmanager.pkgD2PollSummary(responseid, Date.now(), 'Installazione di "' + pkg.name + '" su ' + n.name + ' completata', ((parseInt(def.timeout) || 300) + 120) * 1000); }
        } catch (e) { console.log('pkgmanager run failed: ' + e); }
    };

    // Per-device tab (p19 "Plugins") entry: single target, the current device.
    obj.pkgInstall = function (pkgid) {
        pluginHandler.pkgmanager.pkgRunOn((typeof currentNode != 'undefined') ? currentNode : null, pkgid);
    };

    obj.pkgMsg = function (t) {
        try {
            var m = document.getElementById('pkgmanagerMsg');
            if (m != null) { m.innerText = t; }
            var m2 = document.getElementById('pkgmanagerMsgTab');
            if (m2 != null) { m2.innerText = t; }
        } catch (e) { }
    };

    // ---- Server-side ----
    // AIRGAP STORE: artifacts are dropped manually on the server in
    // <datapath>/plugins/pkgmanager/store/<package-id>/<artifact-file> (or
    // uploaded from the management page) and are served to the AGENT over the
    // LAN via /pkgstore.ashx (GET download: per-process token; POST
    // upload/delete: session-authenticated full site admin). Devices download
    // from THIS server only — no internet is ever involved.
    obj.dlToken = crypto.randomBytes(24).toString('hex');
    obj.storePath = parent.path.join(parent.parent.datapath, 'plugins', 'pkgmanager', 'store');
    obj.artifactCache = {}; // "<pkgid>/<file>" -> { sha384, mtime }
    // v2.0.7: MUTEX per le scritture del catalogo. I bundle multipli creati
    // in un solo osfetch fanno save CONCORRENTI: read-modify-write paralleli
    // su catalog.json si perdono a vicenda (un bundle spariva). Catena di
    // promise: ogni save/delete si accoda.
    obj.catalogWriteChain = Promise.resolve();
    obj.enqueueCatalogWrite = function (fn) {
        obj.catalogWriteChain = obj.catalogWriteChain.then(fn, fn);
        return obj.catalogWriteChain;
    };
    obj.webRef = null;      // webserver module ref (session users), set by the hook
    try { parent.fs.mkdirSync(obj.storePath, { recursive: true }); } catch (e) { }

    // ---- v1.1.0: the store as a NAVIGABLE FOLDER in "My Files" ----
    // Symlink "Pacchetti (pkgmanager)" -> store inside the My Files area of
    // every FULL SITE ADMIN. The core tree follows symlinks (readFilesRec
    // statSync), so the folder is browsable + downloadable via the standard
    // downloadfile.ashx with ZERO core changes. Non-admins never get the
    // link; stale links (admin rights revoked) are removed. A real file/dir
    // the user made with the same name is NEVER touched. Non-recursive
    // delete of the link removes only the link; the plugin recreates both
    // the store dir and the link at every startup.
    obj.storeLinkName = 'Pacchetti (pkgmanager)';
    obj.syncStoreLinks = function () {
        try {
            var db = parent.parent.db;
            if ((db == null) || (typeof db.GetAllType != 'function')) { return; }
            db.GetAllType('user', function (err, docs) {
                if (err != null) { obj.plog('user scan failed: ' + err); return; }
                if (docs == null) { return; }
                for (var i = 0; i < docs.length; i++) {
                    var u = docs[i];
                    if ((u == null) || (u._id == null)) { continue; }
                    var isAdmin = (u.siteadmin === 0xFFFFFFFF);
                    var us = String(u._id).split('/');
                    var domainx = ((us[1] != null) && (us[1].length > 0)) ? ('domain-' + us[1]) : 'domain';
                    var userdir = parent.path.join(parent.parent.filespath, domainx, 'user-' + us[2]);
                    var link = parent.path.join(userdir, obj.storeLinkName);
                    try { parent.fs.mkdirSync(userdir, { recursive: true }); } catch (e) { }
                    var st = null;
                    try { st = parent.fs.lstatSync(link); } catch (e) { }
                    if (st != null) {
                        // Never touch a real (non-symlink) item the user made.
                        if (st.isSymbolicLink() !== true) { continue; }
                        try { parent.fs.unlinkSync(link); } catch (e) { }
                    }
                    if (isAdmin) {
                        try { parent.fs.symlinkSync(obj.storePath, link, 'junction'); }
                        catch (e) { obj.plog('store link failed for ' + u._id + ': ' + e); }
                    }
                }
            });
        } catch (e) { obj.plog('syncStoreLinks failed: ' + e); }
    };
    // callHook('server_startup') fires after the DB is assigned: the links
    // exist before any admin can log in and browse "My Files".
    obj.server_startup = function () {
        try { parent.fs.mkdirSync(obj.storePath, { recursive: true }); } catch (e) { }
        obj.syncStoreLinks();
        obj.pkgConfigInvariantCheck(); // v2.0.4
        obj.pkgAutoRestartCheck(); // v2.1.6
        if (!obj.pkgPollStarted) { // v2.1.7: poll — copre anche l'install dalla
            // schermata Plugin, dove il core chiama require() che restituisce il
            // modulo IN CACHE (codice vecchio): questo modulo nota il nuovo
            // config.json a disco entro 60s e riavvia via canale launcher.
            obj.pkgPollStarted = true;
            obj.pkgPollTimer = setInterval(function () { obj.pkgAutoRestartCheck(); }, 60000);
            if (obj.pkgPollTimer.unref) { try { obj.pkgPollTimer.unref(); } catch (e4) { } }
        }
    };

    // v2.1.6: AUTO-RESTART dopo install/update del plugin. Dopo l'install il
    // core fa require() del modulo, ma Node restituisce il modulo IN CACHE
    // (codice vecchio) e chiama comunque server_startup(): se la versione nel
    // config.json A DISCO e' diversa da quella in esecuzione, i file sono
    // aggiornati ma non attivi -> riavvio graceful del server. Il launcher
    // MeshCentral rileva la riga 'Server restart...' su stdout e rilancia il
    // figlio in 500ms (stesso canale del comando console 'restartserver').
    // Disattivabile con "autoRestartOnUpdate": false in config.json.
    obj.pkgRestartScheduled = false;
    obj.pkgAutoRestartCheck = function () {
        try {
            var disk = JSON.parse(parent.fs.readFileSync(obj.pkgLocalConfigPath));
            var auto = (disk.autoRestartOnUpdate !== false);
            var active = (globalThis.__pkgmanagerActiveVersion || obj.version);
            if (auto && (typeof disk.version == 'string') && (disk.version !== obj.version) && (disk.version !== active) && !obj.pkgRestartScheduled) {
                obj.pkgRestartScheduled = true;
                obj.plog('versione ' + disk.version + ' installata su disco (in esecuzione ' + obj.version + '); riavvio del server tra 2 secondi per caricare il nuovo codice...');
                setTimeout(function () { console.log('Server restart...'); process.exit(0); }, 2000);
                return true;
            }
        } catch (e) { }
        return false;
    };

    // v2.0.4: GUARDIA INVARIANTE configUrl (prevenzione crash-loop schermata
    // Plugin). Il core (pluginHandler.getPluginLatest) MATCHA il campo
    // configUrl DENTRO il config.json scaricato contro l'URL registrato del
    // record plugin; se non coincidono fa reject() dentro un forEach (che non
    // interrompe il loop) -> TypeError + unhandled rejection -> Node 24 ESCE.
    // Difese:
    //  1) forza i campi configUrl/downloadUrl del config.json LOCALE ai
    //     valori canonici (il core copia il file locale nel record DB al load:
    //     record sempre allineato al prossimo avvio; qui aggiorniamo anche il
    //     record subito via db.updatePlugin, stessa chiamata del core);
    //  2) verifica il config REMOTO: logga un ERRORE chiaro se il campo non
    //     e' auto-riferente (release sbagliata -> da correggere sul repo).
    obj.canonicalConfigUrl = 'https://raw.githubusercontent.com/hitclawagent/MeshCentral-pkgmanager/main/config.json';
    obj.canonicalDownloadUrl = 'https://raw.githubusercontent.com/hitclawagent/MeshCentral-pkgmanager/main/pkgmanager-code-latest.zip';
    obj.pkgLocalConfigPath = parent.path.join(parent.parent.datapath, 'plugins', 'pkgmanager', 'config.json');
    obj.pkgConfigInvariantCheck = function () {
        var local = null;
        try { local = JSON.parse(parent.fs.readFileSync(obj.pkgLocalConfigPath)); } catch (e) { obj.plog('config invariant: config.json locale non leggibile: ' + e); return; }
        try {
            var changed = false;
            if (local.configUrl !== obj.canonicalConfigUrl) { local.configUrl = obj.canonicalConfigUrl; changed = true; }
            if (local.downloadUrl !== obj.canonicalDownloadUrl) { local.downloadUrl = obj.canonicalDownloadUrl; changed = true; }
            if (changed) {
                parent.fs.writeFileSync(obj.pkgLocalConfigPath, JSON.stringify(local, null, 2));
                obj.plog('config invariant: config.json locale RIPUNTATO ai canonical URL (era disallineato).');
                try {
                    parent.parent.db.getPlugins(function (err, docs) {
                        if ((err != null) || (docs == null)) { return; }
                        for (var i in docs) {
                            if (docs[i].shortName == 'pkgmanager') { try { parent.parent.db.updatePlugin(docs[i]._id, local); } catch (e2) { } break; }
                        }
                    });
                } catch (e) { }
            }
        } catch (e) { obj.plog('config invariant (locale) failed: ' + e); }
        // 2) verifica remota (best effort)
        try {
            fetch(obj.canonicalConfigUrl).then(function (r) { return r.text(); }).then(function (t) {
                try {
                    var rc = JSON.parse(t);
                    if (rc.configUrl !== obj.canonicalConfigUrl) {
                        obj.plog('ERRORE INVARIANTE config: il config.json REMOTO (' + obj.canonicalConfigUrl + ') dichiara configUrl="' + rc.configUrl + '" != URL servito — la schermata Plugin CRASHERA\' su MeshCentral ufficiale (correggere il campo nel repo, release nuova).');
                    } else {
                        obj.plog('config invariant OK (remoto auto-riferente, v' + rc.version + ').');
                    }
                } catch (e2) { obj.plog('config invariant: config remoto non JSON: ' + e2); }
            }).catch(function (e3) { obj.plog('config invariant: verifica remota saltata (' + e3 + ')'); });
        } catch (e) { }
    };

    // Route registration follows the core pattern (webserver.js setupHTTPHandlers:
    // callHook('hook_setupHttpHandlers', webserverObj, serverObj) -> obj.app).
    obj.hook_setupHttpHandlers = function (webserver, server) {
        try {
            obj.webRef = webserver;
            for (var i in server.config.domains) {
                var d = server.config.domains[i];
                if ((d.dns != null) || (d.share != null)) { continue; }
                webserver.app.get(d.url + 'pkgstore.ashx', function (req, res) { obj.handleStoreGet(req, res); });
                webserver.app.post(d.url + 'pkgstore.ashx', webserver.bodyParser.raw({ type: function () { return true; }, limit: '512mb' }), function (req, res) { obj.handleStorePost(req, res); });
            }
            obj.plog('/pkgstore.ashx registered (airgap artifact route: GET download + POST upload/delete)');
        } catch (e) { obj.plog('route registration failed: ' + e); }
    };

    // GET: agent/browser download, gated by the per-process token (composed
    // into {{url}}). Same path-safety rules as POST.
    obj.handleStoreGet = function (req, res) {
        try {
            if ((req.query == null) || (req.query.t !== obj.dlToken)) { res.status(403).send('Forbidden'); return; }
            var p = String(req.query.p || '');
            var full = parent.path.join(obj.storePath, p);
            if ((full.indexOf(obj.storePath) !== 0) || (full == obj.storePath) || (p.indexOf('..') >= 0)) { res.status(400).send('Bad path'); return; }
            parent.fs.stat(full, function (err, st) {
                if ((err != null) || (!st.isFile())) { res.status(404).send('Not found'); return; }
                res.setHeader('Content-Length', st.size);
                res.setHeader('Content-Type', 'application/octet-stream');
                parent.fs.createReadStream(full).pipe(res);
            });
        } catch (e) { try { res.status(500).send('Error'); } catch (e2) { } }
    };

    // POST: artifact upload (raw body = file bytes) and artifact delete.
    // Session-authenticated (cookie), FULL SITE ADMIN only.
    obj.handleStorePost = function (req, res) {
        try {
            var wu = ((obj.webRef != null) && (req.session != null) && (req.session.userid != null)) ? obj.webRef.users[req.session.userid] : null;
            if ((wu == null) || (wu.siteadmin !== 0xFFFFFFFF)) { res.status(403).json({ ok: false, error: 'Solo gli amministratori del server possono gestire gli artefatti.' }); return; }
            var p = String(req.query.p || '');
            var op = String(req.query.op || '');
            if (op == 'plugupd') {
                // v1.9.6: file di aggiornamento del plugin -> .update-pending.js
                // (path FISSO, nessun parametro di percorso: zero traversal).
                // PRIMA della validazione del percorso: questa opzione non usa `p`.
                // NB: le dichiarazioni p/op stanno SOPRA il ramo (var hoisting: se
                // il ramo le precedesse, op sarebbe undefined e il ramo morto).
                if (!(Buffer.isBuffer(req.body)) || (req.body.length == 0)) { res.status(400).json({ ok: false, error: 'Corpo vuoto.' }); return; }
                parent.fs.writeFile(obj.updatePendingPath, req.body, function (e4) {
                    if (e4 != null) { try { res.status(500).json({ ok: false, error: String(e4) }); } catch (e5) { } return; }
                    var hu = crypto.createHash('sha384').update(req.body).digest('hex');
                    obj.plog('plugin update uploaded (' + req.body.length + ' bytes, sha384=' + hu.slice(0, 16) + '...) by ' + wu._id);
                    try { res.json({ ok: true, sha384: hu, size: req.body.length }); } catch (e5) { }
                });
                return;
            }
            var full = parent.path.join(obj.storePath, p);
            if ((full.indexOf(obj.storePath) !== 0) || (full == obj.storePath) || (p.indexOf('..') >= 0)) { res.status(400).json({ ok: false, error: 'Percorso non valido.' }); return; }
            if (op == 'del') {
                parent.fs.stat(full, function (err, st) {
                    if ((err != null) || (!st.isFile())) { res.status(404).json({ ok: false, error: 'Artefatto non presente.' }); return; }
                    parent.fs.unlink(full, function (e2) {
                        if (e2 != null) { res.status(500).json({ ok: false, error: String(e2) }); return; }
                        obj.plog('artifact deleted: ' + p);
                        res.json({ ok: true });
                    });
                });
                return;
            }
            if (op != 'upload') { res.status(400).json({ ok: false, error: 'Operazione sconosciuta.' }); return; }
            var body = req.body;
            if (!(Buffer.isBuffer(body)) || (body.length == 0)) { res.status(400).json({ ok: false, error: 'Corpo vuoto.' }); return; }
            parent.fs.mkdir(parent.path.dirname(full), { recursive: true }, function (e3) {
                if (e3 != null) { res.status(500).json({ ok: false, error: String(e3) }); return; }
                parent.fs.writeFile(full, body, function (e4) {
                    if (e4 != null) { res.status(500).json({ ok: false, error: String(e4) }); return; }
                    var h = crypto.createHash('sha384').update(body).digest('hex');
                    obj.plog('artifact uploaded: ' + p + ' (' + body.length + ' bytes) by ' + wu._id);
                    res.json({ ok: true, sha384: h, size: body.length });
                });
            });
        } catch (e) { try { res.status(500).json({ ok: false, error: String(e) }); } catch (e2) { } }
    };

    // SHA-384 + size of a store artifact (cached by mtime); flags artifactMissing.
    // v1.3.0: enrich ONE def file (name + 1-based index) with its SHA-384
    // from the store. Bundles collect per-index hashes in def.sha384s; index
    // 1 also back-fills the legacy def.sha384. Any missing file marks the
    // whole def unusable (airgap safety: install is refused).
    obj.pkgArtifactInfo = function (pkgid, name, idx, def, callback) {
        var key = pkgid + '/' + name;
        var full = parent.path.join(obj.storePath, pkgid, name);
        parent.fs.stat(full, function (err, st) {
            var miss = function () { def.artifactMissing = true; delete def.sha384; delete def.sha384s; callback(); return; };
            if ((err != null) || (!st.isFile())) { miss(); return; }
            var c = obj.artifactCache[key];
            var fill = function (h) {
                if (def.sha384s == null) { def.sha384s = {}; }
                def.sha384s[idx] = h;
                if (idx == 1) { def.sha384 = h; def.artifactSize = st.size; }
                def.artifactMissing = false; callback();
            };
            if ((c != null) && (c.mtime == st.mtimeMs)) { fill(c.sha384); return; }
            parent.fs.readFile(full, function (err2, data) {
                if (err2 != null) { miss(); return; }
                var h = crypto.createHash('sha384').update(data).digest('hex');
                obj.artifactCache[key] = { sha384: h, mtime: st.mtimeMs };
                fill(h);
            });
        });
    };

    // Sanitize one per-OS def coming from the management UI.
    obj.sanitizeDef = function (def) {
        if ((def == null) || (typeof def.cmd != 'string') || (def.cmd.trim() == '')) return null;
        var out = { type: ((def.type == 1) || (def.type == 2)) ? def.type : 3, cmd: def.cmd };
        var to = parseInt(def.timeout); if (to > 0) { out.timeout = to; }
        if ((typeof def.artifact == 'string') && (def.artifact.trim() != '') && (/^[a-zA-Z0-9._ -]+$/.test(def.artifact.trim()))) { out.artifact = def.artifact.trim(); }
        // v1.3.0 OS-update bundle: ordered list of store files.
        if (Array.isArray(def.artifacts)) {
            var arts = [];
            for (var i = 0; (i < def.artifacts.length) && (arts.length < 32); i++) {
                var nm = String(def.artifacts[i]).trim();
                if ((nm != '') && (/^[a-zA-Z0-9._+~:-]+$/.test(nm))) { arts.push(nm); }
            }
            if (arts.length > 0) { out.artifacts = arts; }
        }
        if ((typeof def.uninstall == 'string') && (def.uninstall.trim() != '')) { out.uninstall = def.uninstall.trim().slice(0, 4096); }
        if ((typeof def.kind == 'string') && (def.kind.trim() == 'os')) { out.kind = 'os'; } // v1.4.0: OS-update bundle marker
        return out;
    };

    // Read catalog + enrich defs (artifact presence, sha384) + reply pkgList.
    // v2.0.8: CALCOLO PIANO AGGIORNAMENTI (condiviso da «osplan» e «osfetch»).
    // Per ogni codename (release distro): union dei delta+dipendenze di TUTTE
    // le macchine del gruppo, dedupe per nome pacchetto con VERSIONE MASSIMA
    // (sistemi identici a livelli diversi convergono al piu' recente), e
    // verifica di ogni .deb nello store (inStore + sha384). Windows/macOS:
    // gruppo segnalato ma senza update deducibili (best effort).
    obj.osPlanCompute = async function (fmachs, fget, fskipped) {
        var zlib2 = zlib;
        var fhasDpkg = false; try { if (childProcess != null) { childProcess.execFileSync('dpkg', ['--version'], { stdio: 'ignore' }); fhasDpkg = true; } } catch (e) { }
        var fverGe = function (a, b) { if (a === b) { return true; } if (fhasDpkg) { try { childProcess.execFileSync('dpkg', ['--compare-versions', String(a), 'ge', String(b)], { stdio: 'ignore' }); return true; } catch (e) { return false; } } return (verDebCmp(a, b) >= 0); };
        var fparseIdx = function (txt) { var idx = {}; var st = String(txt).split('\n\n'); for (var s = 0; s < st.length; s++) { var o = {}; var ls = st[s].split('\n'); for (var l = 0; l < ls.length; l++) { var c = ls[l].indexOf(':'); if (c > 0) { var k = ls[l].slice(0, c).trim(); var v = ls[l].slice(c + 1).trim(); if (!(k in o)) { o[k] = v; } } } if (o.Package && o.Version && (o.Architecture === 'amd64' || o.Architecture === 'all') && o.Filename) { if (idx[o.Package] == null) { idx[o.Package] = []; } idx[o.Package].push(o); } } return idx; };
        var fbest = function (arr) { var b = arr[0]; for (var i = 0; i < arr.length; i++) { if (fverGe(arr[i].Version, b.Version)) { b = arr[i]; } } return b; };
        var fdeps = function (st) { var out = []; var gs = String(st || '').split(','); for (var g = 0; g < gs.length; g++) { var t = gs[g].trim(); if (t == '') { continue; } var alts = t.split('|'); var names = []; for (var a = 0; a < alts.length; a++) { var n0 = alts[a].trim().split(/[ (]/)[0].trim(); if (n0 != '') { names.push(n0); } } if (names.length > 0) { out.push(names); } } return out; };
        var fidxCache = {};
        var fIndex = async function (codename) {
            if (fidxCache[codename] != null) { return fidxCache[codename]; }
            var idx = {};
            var pockets = ['https://security.ubuntu.com/ubuntu/dists/' + codename + '-security', 'https://archive.ubuntu.com/ubuntu/dists/' + codename + '-updates'];
            var areas = ['main', 'universe'];
            for (var p = 0; p < pockets.length; p++) {
                for (var ar = 0; ar < areas.length; ar++) {
                    var url = pockets[p] + '/' + areas[ar] + '/binary-amd64/Packages.gz';
                    var txt = null;
                    try { txt = zlib2.gunzipSync(await fget(url)).toString('utf8'); } catch (e) { try { txt = zlib2.gunzipSync(await fget(url.replace('https://', 'http://'))).toString('utf8'); } catch (e2) { } }
                    if (txt == null) { fskipped.push({ machine: '(indice)', reason: 'indice vendor non raggiungibile: ' + url }); continue; }
                    var sub = fparseIdx(txt);
                    for (var nm in sub) { if (idx[nm] == null) { idx[nm] = []; } for (var q = 0; q < sub[nm].length; q++) { idx[nm].push(sub[nm][q]); } }
                }
            }
            fidxCache[codename] = idx;
            return idx;
        };
        var groupsBy = {}; var groupMeta = {};
        for (var mi = 0; mi < fmachs.length; mi++) {
            var mm = fmachs[mi];
            var mos = String((mm != null) ? (mm.os || '') : '').toLowerCase();
            var mname = String((mm != null) ? (mm.name || '') : '?');
            var mid = String((mm != null) ? (mm.id || mm.name || '') : '');
            if ((mos == 'windows') || (mos == 'macos') || (mos == 'darwin')) {
                var isWin = (mos == 'windows');
                var gk = ((isWin ? 'windows' : 'macos')) + ':' + String(((mm.osInfo != null) && (mm.osInfo.name != null)) ? mm.osInfo.name : mos);
                if (groupsBy[gk] == null) { groupsBy[gk] = { os: isWin ? 'windows' : 'macos', distro: String(((mm.osInfo != null) && (mm.osInfo.name != null)) ? mm.osInfo.name : mos), ver: String(((mm.osInfo != null) && (mm.osInfo.version != null)) ? mm.osInfo.version : ''), codename: null, machines: {}, updates: [] }; }
                groupsBy[gk].machines[mid] = mname;
                if (!isWin) { continue; }
                // v2.2.5: PIANO WINDOWS — il catalogo Microsoft e' pubblico e
                // lo stesso usato da meshos-fetch --kb: mancanti = KB presenti
                // nel catalogo per la release e NON installati su almeno una
                // macchina del gruppo. Uniforme con Linux: stessi campi, stesse
                // checkbox, scarico nello store (osfetch) senza vie parallele.
                var finfo = ((mm.osInfo != null) ? mm.osInfo : {});
                var displayVer = String(((finfo.version != null) ? finfo.version : '')).match(/([^\s(]+)/);
                var kbsInstalled = {};
                var itsW = Array.isArray(mm.items) ? mm.items : [];
                for (var iw = 0; iw < itsW.length; iw++) { var kbT = /((?:KB|kb)\d+)/.exec(String(itsW[iw])); if (kbT != null) { kbsInstalled[kbT[1].toUpperCase()] = 1; } }
                var winInst = groupsBy[gk].windowsInstalled = (groupsBy[gk].windowsInstalled || {});
                for (var kbi in kbsInstalled) { winInst[kbi] = 1; }
                groupsBy[gk].displayVer = ((displayVer != null) ? displayVer[1] : '');
                continue;
            }
            var codename = String(((mm != null) && (mm.osInfo != null) && (mm.osInfo.codename != null)) ? String(mm.osInfo.codename).trim().replace(/"/g, '') : '');
            if (codename == '') { fskipped.push({ machine: mname, reason: 'codename assente nell inventario (scansione vecchia?)' }); continue; }
            if (groupsBy[codename] == null) { groupsBy[codename] = { os: 'linux', distro: String(((mm.osInfo != null) && (mm.osInfo.name != null)) ? mm.osInfo.name : 'Linux').replace(/"/g, ''), ver: String(((mm.osInfo != null) && (mm.osInfo.version != null)) ? mm.osInfo.version : '').replace(/"/g, ''), codename: codename, machines: {}, updates: [] }; }
            groupsBy[codename].machines[mid] = mname;
            var installed = {};
            var its = ((mm != null) && Array.isArray(mm.items)) ? mm.items : [];
            for (var ii = 0; ii < its.length; ii++) { var sp = String(its[ii]).indexOf(' '); if (sp > 0) { installed[String(its[ii]).slice(0, sp)] = String(its[ii]).slice(sp + 1).trim(); } }
            obj.plog('osplan ' + mname + ': ' + Object.keys(installed).length + ' pacchetti installati (' + groupsBy[codename].distro + ' ' + codename + ')');
            var idx = await fIndex(codename);
            var queue = []; var queued = {};
            var pushP = function (name, reason) { var stz = idx[name]; if (stz == null) { return; } var cand = fbest(stz); var key = name + '_' + cand.Version; if (queued[key] != null) { return; } queued[key] = 1; queue.push({ name: name, reason: reason, st: cand }); };
            for (var iname in installed) { var st2 = idx[iname]; if (st2 == null) { continue; } var cand2 = fbest(st2); if (!fverGe(installed[iname], cand2.Version)) { pushP(iname, 'aggiornamento disponibile'); } }
            var seen = {}; for (var qk in queued) { seen[qk] = 1; }
            var frontier = queue.slice(0);
            while (frontier.length > 0) {
                var next = [];
                for (var f = 0; f < frontier.length; f++) {
                    var depgs = fdeps(String((frontier[f].st.Depends || '') + ',' + (frontier[f].st['Pre-Depends'] || '')));
                    for (var dg = 0; dg < depgs.length; dg++) {
                        var pick = null;
                        for (var da = 0; da < depgs[dg].length; da++) { if (idx[depgs[dg][da]] != null) { pick = depgs[dg][da]; break; } }
                        if (pick == null) { continue; }
                        if (installed[pick] != null) { continue; }
                        if (seen[pick] != null) { continue; }
                        seen[pick] = 1;
                        var stz2 = fbest(idx[pick]);
                        var kz = pick + '_' + stz2.Version;
                        if (queued[kz] != null) { continue; }
                        queued[kz] = 1;
                        var item = { name: pick, reason: 'dipendenza di ' + frontier[f].name, st: stz2 };
                        queue.push(item); next.push(item);
                    }
                }
                frontier = next;
            }
            obj.plog('osplan ' + mname + ': delta+dipendenze = ' + queue.length + ' pacchetti');
            for (var qi = 0; qi < queue.length; qi++) {
                var qe = queue[qi];
                var file2 = qe.name + '_' + qe.st.Version + '_' + (qe.st.Architecture || 'amd64') + '.deb';
                var ex = null;
                for (var ux = 0; ux < groupsBy[codename].updates.length; ux++) { if (groupsBy[codename].updates[ux].package == qe.name) { ex = groupsBy[codename].updates[ux]; break; } }
                if (ex == null) {
                    ex = { package: qe.name, version: qe.st.Version, file: file2, url: 'http://security.ubuntu.com/ubuntu/' + qe.st.Filename, origUrl: 'http://archive.ubuntu.com/ubuntu/' + qe.st.Filename, size: parseInt(qe.st.Size || '0', 10), installed: null, targets: {} };
                    groupsBy[codename].updates.push(ex);
                } else if (fverGe(qe.st.Version, ex.version)) {
                    ex.version = qe.st.Version; ex.file = file2; ex.url = 'http://security.ubuntu.com/ubuntu/' + qe.st.Filename; ex.origUrl = 'http://archive.ubuntu.com/ubuntu/' + qe.st.Filename; ex.size = parseInt(qe.st.Size || '0', 10);
                }
                ex.targets[mid] = 1;
                if ((installed[qe.name] != null) && ((ex.installed == null) || fverGe(ex.installed, installed[qe.name]))) { ex.installed = installed[qe.name]; }
            }
        }
        // v2.2.5: catalogo Microsoft per ogni gruppo windows — mancanti,
        // URL di download risolti e stato store (uniforme a Linux).
        var fcatalogWindows = null;
        try { fcatalogWindows = await obj.osCatalogWindows(groupsBy, fget, fskipped); } catch (e) { obj.plog('osplan catalogo windows fallito: ' + e); fskipped.push({ machine: '(catalogo Microsoft)', reason: 'ricerca fallita: ' + e }); }
        // stato store: file presente? sha384 calcolato dal file reale
        var gkeys = Object.keys(groupsBy).sort();
        for (var gi = 0; gi < gkeys.length; gi++) {
            var grp = groupsBy[gkeys[gi]];
            if (grp.os == 'windows') { grp.storeDirName = 'os-updates-windows' + ((grp.displayVer != null) && (grp.displayVer != '') ? ('-' + grp.displayVer.toLowerCase()) : ''); }
            if (grp.os != 'linux') { continue; }
            grp.storeDirName = 'os-updates-' + grp.codename;
            var sdir = parent.path.join(obj.storePath, grp.storeDirName);
            grp.machNames = []; for (var mk in grp.machines) { grp.machNames.push(grp.machines[mk]); }
            for (var ui = 0; ui < grp.updates.length; ui++) {
                var u2 = grp.updates[ui];
                var full2 = parent.path.join(sdir, u2.file);
                u2.inStore = false; u2.sha384 = null;
                try { if (parent.fs.statSync(full2).isFile()) { u2.inStore = true; u2.sha384 = crypto.createHash('sha384').update(parent.fs.readFileSync(full2)).digest('hex'); } } catch (e) { }
            }
            grp.updates.sort(function (a, b) { return (a.package < b.package ? -1 : (a.package > b.package ? 1 : 0)); });
        }
        return { groups: groupsBy, groupKeys: gkeys, skipped: fskipped };
    };

    // v2.2.5: CATALOGO MICROSOFT per i gruppi windows. Ricerca per release
    // ("Windows 10 Version 22H2"), filtra Security Updates/Updates x64,
    // mancanti = KB non installati su almeno una macchina, URL risolto dal
    // DownloadDialog (stesso flusso di meshos-fetch --kb). Cap 30 righe
    // per gruppo, le piu' recenti per data.
    obj.osCatalogWindows = async function (groupsBy, fget, fskipped) {
        var CATALOG_CAP = 30;
        var fStrip = function (t) { return String(t == null ? '' : t).replace(/<[^>]*>/g, ' ').replace(/&amp;/g, '&').replace(/&#39;|&apos;/g, String.fromCharCode(39)).replace(/&quot;/g, String.fromCharCode(34)).replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&nbsp;/g, ' ').replace(/\s+/g, ' ').trim(); };
        var fRows = function (html) {
            var out = [];
            var rows = String(html).split(/<tr/i);
            for (var i = 0; i < rows.length; i++) {
                var r = rows[i];
                var gm = /goToDetails\(\s*["']([0-9a-f-]{36})["']/.exec(r);
                if (gm == null) { continue; }
                var cells = r.split(/<td/i);
                var cellTxt = function (idx) { return ((cells[idx] != null) ? fStrip(cells[idx].replace(/^[^>]*>/, '')) : ''); };
                var sizeB = 0; var sm = /originalSize[^>]*>([0-9]+)</.exec(r); if (sm != null) { sizeB = parseInt(sm[1], 10); }
                out.push({ guid: gm[1], title: cellTxt(2), products: cellTxt(3), kind: cellTxt(4), date: cellTxt(5), ver: cellTxt(6), size: sizeB });
            }
            return out;
        };
        var fDialog = async function (guid) {
            var url = 'https://www.catalog.update.microsoft.com/DownloadDialog.aspx';
            var r = await fetch(url, { method: 'POST', headers: { 'User-Agent': 'MeshCentral-pkgmanager/2.0', 'Content-Type': 'application/x-www-form-urlencoded' }, body: 'updateIDs=' + encodeURIComponent(JSON.stringify([{ size: 0, languages: '', uidInfo: guid, updateID: guid }])) });
            if (!r.ok) { throw new Error('HTTP ' + r.status + ' DownloadDialog'); }
            var txt = await r.text();
            var mu = /downloadInformation\[0\]\.files\[0\]\.url\s*=\s*['\"]([^'\"]+)['\"]/.exec(txt);
            return ((mu != null) ? mu[1] : null);
        };
        for (var gk in groupsBy) {
            var grp = groupsBy[gk];
            if (grp.os != 'windows') { continue; }
            grp.machNames = []; for (var mkW in grp.machines) { grp.machNames.push(grp.machines[mkW]); }
            var dv = String(grp.displayVer || '');
            if (dv == '') { fskipped.push({ machine: '(windows)', reason: 'release non deducibile dall inventario (' + grp.ver + ')' }); continue; }
            var famM = /Windows\s+Server\s+\d+|Windows\s+\d+/.exec(String(grp.distro || '')); // "Microsoft Windows 10 Pro" -> "Windows 10"; Server incluso
            if (famM == null) { fskipped.push({ machine: '(windows)', reason: 'family non deducibile da ' + grp.distro }); continue; }
            var family = famM[0];
            var mVer = dv.match(/([0-9]+H[0-9]+)/); dv = ((mVer != null) ? mVer[1] : dv);
            var arch = 'x64';
            var query = family + ' Version ' + dv;
            obj.plog('catalogo windows [' + gk + ']: query="' + query + '"');
            var html = null;
            try { html = (await fget('https://www.catalog.update.microsoft.com/Search.aspx?q=' + encodeURIComponent(query))).toString('utf8'); } catch (e) { fskipped.push({ machine: '(catalogo Microsoft)', reason: 'ricerca fallita: ' + e }); continue; }
            var rows = fRows(html);
            obj.plog('catalogo windows [' + gk + ']: ' + rows.length + ' righe');
            var seenKb = {};
            var cand = [];
            for (var ri = 0; ri < rows.length; ri++) {
                var r2 = rows[ri];
                if (/Drivers|Driver/i.test(r2.kind)) { continue; }
                if (!/Security Updates|Updates|Update Rollup/i.test(r2.kind)) { continue; }
                if (!/x64/i.test(r2.title)) { continue; }
                var kb = /\b(KB\d+)\b/i.exec(r2.title);
                if (kb == null) { continue; }
                kb = kb[1].toUpperCase();
                if (seenKb[kb] != null) { continue; }
                seenKb[kb] = 1;
                if (grp.windowsInstalled[kb] === 1) { continue; } // installato su tutte le macchine del gruppo
                // targets = macchine del gruppo dove manca
                var targets2 = {};
                var nmiss = 0;
                // per il singolo riquadro: tutte le macchine senza quel KB -> la riga resta finche' qualcuno non lo ha
                for (var mid in grp.machines) { targets2[mid] = 1; nmiss++; } // (semplificato: installato = esclusa sopra; il check per-macchina e' nella nota)
                r2.kb = kb; r2.targets = targets2;
                cand.push(r2);
            }
            cand.sort(function (a, b) { var da = Date.parse(a.date), db2 = Date.parse(b.date); return ((isNaN(db2) ? -1 : db2) - (isNaN(da) ? -1 : da)); });
            var shown = Math.min(cand.length, CATALOG_CAP);
            for (var ci = 0; ci < shown; ci++) {
                var c = cand[ci];
                var url2 = null;
                try { url2 = await fDialog(c.guid); } catch (e2) { fskipped.push({ file: c.kb, reason: 'download URL non risolto: ' + e2 }); }
                if (url2 == null) { continue; }
                grp.updates.push({ package: c.kb, version: ((c.ver != null) && (c.ver != '') && (c.ver != 'n/a')) ? c.ver : c.date, file: c.kb + '.msu', url: url2, origUrl: url2, size: c.size, installed: null, targets: c.targets, catalogGuid: c.guid, title: c.title });
            }
            if (cand.length > shown) { fskipped.push({ machine: '(windows ' + dv + ')', reason: 'mostrati i ' + shown + ' aggiornamenti piu recenti su ' + cand.length + ' mancanti nel catalogo' }); }
            obj.plog('catalogo windows [' + gk + ']: mancanti ' + cand.length + ' (mostrati ' + shown + ')');
        }
    };

    obj.replyCatalog = function (session, opAck, err) {
        obj.fs.readFile(obj.catalogPath, function (err2, data) {
            var cat = null;
            try { cat = JSON.parse(data); } catch (e) { }
            obj.plog('catalog read ' + ((cat != null) ? 'ok (' + ((cat.packages != null) ? cat.packages.length : '?') + ' packages)' : 'FAILED: ' + err2));
            // Template dispatcher (case 'plugin' on message.action) calls
            // pluginHandler[message.plugin][message.method](server, message):
            // plugin and method must be at the TOP level, not nested in event.
            var send = function () {
                try { session.send({ action: 'plugin', plugin: 'pkgmanager', method: 'pkgList', catalog: cat, token: obj.dlToken, opAck: opAck, error: (err2 ? String(err2) : (err || null)), binMissing: ((obj.binariesMissing != null) ? obj.binariesMissing().length : -1), binBusy: (obj.ensureBinariesBusy === true), binAttempts: (obj.ensureBinariesAttempts || 0), binError: (obj.binariesLastError || null), pluginVersion: obj.version }); } catch (e) { console.log('pkgmanager: reply failed: ' + e); }
            };
            if ((cat == null) || (cat.packages == null)) { send(); return; }
            var oses = ['linux', 'windows', 'macos'];
            var work = [];
            for (var i = 0; i < cat.packages.length; i++) {
                var p = cat.packages[i];
                for (var k = 0; k < oses.length; k++) {
                    var def = p[oses[k]];
                    if (def == null) { continue; }
                    // v1.3.0: bundle (artifacts[]) or legacy single artifact.
                    var names2 = null;
                    if ((def.artifacts != null) && (def.artifacts.length > 0)) { names2 = def.artifacts; }
                    else if (def.artifact != null) { names2 = [def.artifact]; }
                    if (names2 == null) { continue; }
                    for (var n2 = 0; n2 < names2.length; n2++) { work.push({ pkgid: p.id, def: def, name: names2[n2], idx: (n2 + 1) }); }
                }
            }
            if (work.length == 0) { send(); return; }
            var done = 0;
            for (var w = 0; w < work.length; w++) {
                (function (item) { obj.pkgArtifactInfo(item.pkgid, item.name, item.idx, item.def, function () { done++; if (done == work.length) { send(); } }); })(work[w]);
            }
        });
    };

    // v1.8.0: builds the stand-alone PYTHON downloader with the scan
    // inventory EMBEDDED. Stdlib only. The generated source contains ZERO
    // backslash characters on purpose (splitlines() instead of split('\n')):
    // no escaping headaches in any direction, easy to audit.
    obj.buildPyDownloader = function (machines) {
        var inv = [];
        for (var i = 0; i < machines.length; i++) {
            var m = machines[i];
            var info = ((m != null) && (m.osInfo != null)) ? m.osInfo : {};
            var items = [];
            if (Array.isArray(m.items)) { for (var j = 0; j < m.items.length; j++) { items.push(String(m.items[j])); } }
            inv.push({ id: String((m != null) ? (m.id || m.name || '') : ''), name: String((m != null) ? (m.name || '') : ''), os: String((m != null) ? (m.os || '') : ''), osInfo: { name: String(info.name || ''), version: String(info.version || ''), codename: String(info.codename || '') }, items: items });
        }
        var pre = `#!/usr/bin/env python3
# meshos-downloader — airgap OS-update downloader generated by the
# MeshCentral pkgmanager plugin (v1.8.0).
#
# The scan inventory is ALREADY INSIDE this file (INVENTORY below): no
# arguments, no config needed. Run it on ANY machine with internet:
#
#     python3 meshos-downloader.py             # all missing updates
#     python3 meshos-downloader.py --max 3     # cap for a test run
#
# It downloads ONLY the missing Ubuntu/Debian packages (delta vs the vendor
# security+updates indexes + the dependency closure) into os-updates/ and
# writes os-updates/manifest.json with the sha384 of every file.
#
# Then: copy EVERYTHING from os-updates/ into the MeshCentral server store
# (web UI -> My Files -> "Pacchetti (pkgmanager)" -> store/<bundle-id>/)
# and in the plugin: Aggiornamenti OS -> Gestione aggiornamenti ->
# «Importa manifest…» with that same bundle id. The server verifies every
# file and builds the OS bundle by itself.
#
# Ubuntu/Debian is the solid path; Windows/macOS machines in the inventory
# are reported as skipped (best effort: missing KBs / combo updates are
# not deducible from an installed-packages scan — use meshos-fetch or WSUS).
import datetime
import gzip
import hashlib
import json
import os
import shutil
import subprocess
import sys
import urllib.request
`;
        var post = `OUT_DIR = 'os-updates'
MAX_FILES = None
UA = 'MeshCentral-pkgmanager/1.8.0 (meshos-downloader)'

for _i in range(1, len(sys.argv)):
    if (sys.argv[_i] == '--max') and (_i + 1 < len(sys.argv)):
        try:
            MAX_FILES = int(sys.argv[_i + 1])
        except ValueError:
            print('avviso: --max non numerico, ignorato')
        break

def log(msg):
    print('[meshos-downloader] ' + str(msg))

def http_get(url):
    req = urllib.request.Request(url, headers={'User-Agent': UA})
    return urllib.request.urlopen(req, timeout=90).read()

def sha384_of(buf):
    return hashlib.sha384(buf).hexdigest()

HAS_DPKG = shutil.which('dpkg') is not None

def ver_ge(a, b):
    if a == b:
        return True
    if HAS_DPKG:
        return subprocess.call(['dpkg', '--compare-versions', str(a), 'ge', str(b)], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL) == 0
    return str(a) >= str(b)

def parse_index(text):
    idx = {}
    cur = {}
    def flush():
        if ('Package' in cur) and ('Version' in cur) and ('Filename' in cur) and (cur.get('Architecture') in ('amd64', 'all')):
            idx.setdefault(cur['Package'], []).append(cur)
    for line in text.splitlines():
        if line.strip() == '':
            flush()
            cur = {}
            continue
        pos = line.find(':')
        if pos > 0:
            key = line[:pos].strip()
            val = line[pos + 1:].strip()
            if key not in cur:
                cur[key] = val
    flush()
    return idx

def best(stanzas):
    out = stanzas[0]
    for st in stanzas:
        if ver_ge(st['Version'], out['Version']):
            out = st
    return out

def dep_groups(st):
    out = []
    for grp in str(st or '').split(','):
        grp = grp.strip()
        if grp == '':
            continue
        names = []
        for alt in grp.split('|'):
            nm = alt.split('(')[0].strip()
            if nm != '':
                names.append(nm)
        if names:
            out.append(names)
    return out

manifest = {'tool': 'pkgmanager-export', 'version': '1.8', 'generated': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'files': [], 'skipped': []}
skipped = manifest['skipped']

def fetch_index(codename):
    pockets = ['https://security.ubuntu.com/ubuntu/dists/' + codename + '-security', 'https://archive.ubuntu.com/ubuntu/dists/' + codename + '-updates']
    areas = ['main', 'universe']
    idx = {}
    for pocket in pockets:
        for area in areas:
            url = pocket + '/' + area + '/binary-amd64/Packages.gz'
            text = None
            for cand in (url, url.replace('https://', 'http://')):
                try:
                    text = gzip.decompress(http_get(cand)).decode('utf-8', 'replace')
                    break
                except Exception:
                    pass
            if text is None:
                skipped.append({'machine': '(indice)', 'reason': 'indice vendor non raggiungibile: ' + url})
                continue
            for name, stanzas in parse_index(text).items():
                if name not in idx:
                    idx[name] = []
                idx[name].extend(stanzas)
    return idx

os.makedirs(OUT_DIR, exist_ok=True)
done = {}
targets_by = {}

for m in INVENTORY:
    os_name = str(m.get('os') or '').lower()
    if os_name in ('windows', 'macos', 'darwin'):
        skipped.append({'machine': str(m.get('name')), 'reason': os_name + ': best effort — KB/combo non deducibili dalla sola scansione (meshos-fetch --kb/--macos o WSUS)'})
        continue
    codename = str((m.get('osInfo') or {}).get('codename') or '').strip()
    if codename == '':
        skipped.append({'machine': str(m.get('name')), 'reason': 'codename assente nell inventario (scansione vecchia?)'})
        continue
    installed = {}
    for item in (m.get('items') or []):
        s = str(item)
        pos = s.find(' ')
        if pos > 0:
            installed[s[:pos]] = s[pos + 1:].strip()
    log('linux ' + str(m.get('name')) + ': ' + str(len(installed)) + ' pacchetti installati (Ubuntu ' + codename + ')')
    idx = fetch_index(codename)
    queue = []
    queued = {}
    def push(name, reason):
        stanzas = idx.get(name)
        if not stanzas:
            return
        cand = best(stanzas)
        key = name + '_' + cand['Version']
        if key in queued:
            return
        queued[key] = 1
        queue.append({'name': name, 'reason': reason, 'st': cand})
    for iname in installed:
        stanzas = idx.get(iname)
        if not stanzas:
            continue
        cand = best(stanzas)
        if not ver_ge(installed[iname], cand['Version']):
            push(iname, 'aggiornamento disponibile')
    seen = dict(queued)
    frontier = list(queue)
    while frontier:
        nxt = []
        for qi in frontier:
            for names in dep_groups((qi['st'].get('Depends') or '') + ',' + (qi['st'].get('Pre-Depends') or '')):
                pick = None
                for nm in names:
                    if nm in idx:
                        pick = nm
                        break
                if (pick is None) or (pick in installed) or (pick in seen):
                    continue
                seen[pick] = 1
                stz = best(idx[pick])
                key = pick + '_' + stz['Version']
                if key in queued:
                    continue
                queued[key] = 1
                item = {'name': pick, 'reason': 'dipendenza di ' + qi['name'], 'st': stz}
                queue.append(item)
                nxt.append(item)
        frontier = nxt
    log('  delta+dipendenze: ' + str(len(queue)) + ' pacchetti')
    for qi in queue:
        key = qi['name'] + '_' + qi['st']['Version']
        if key not in done:
            done[key] = {'package': qi['name'], 'version': qi['st']['Version'], 'file': qi['name'] + '_' + qi['st']['Version'] + '_' + str(qi['st'].get('Architecture') or 'amd64') + '.deb', 'orig': 'http://archive.ubuntu.com/ubuntu/' + qi['st']['Filename'], 'alt': 'http://security.ubuntu.com/ubuntu/' + qi['st']['Filename'], 'size': int(qi['st'].get('Size') or 0)}
        targets_by.setdefault(key, []).append(str(m.get('id') or m.get('name') or ''))

order = sorted(done.values(), key=lambda e: e['size'])
log('download unificato: ' + str(len(order)) + ' file distinti' + (' (cap --max ' + str(MAX_FILES) + ')' if MAX_FILES is not None else ''))
for e in order:
    if (MAX_FILES is not None) and (len(manifest['files']) >= MAX_FILES):
        skipped.append({'file': e['file'], 'reason': 'cap --max raggiunto (per il resto rilancialo senza --max)'})
        continue
    buf = None
    for cand in (e['orig'], e['alt']):
        try:
            buf = http_get(cand)
            break
        except Exception:
            pass
    if buf is None:
        skipped.append({'file': e['file'], 'reason': 'download fallito (' + e['orig'] + ')'})
        continue
    with open(os.path.join(OUT_DIR, e['file']), 'wb') as fh:
        fh.write(buf)
    key = e['package'] + '_' + e['version']
    manifest['files'].append({'os': 'linux', 'package': e['package'], 'version': e['version'], 'file': e['file'], 'sha384': sha384_of(buf), 'size': len(buf), 'targets': targets_by.get(key, [])})
    log('  ok ' + e['file'] + ' (' + str(len(buf) // 1024) + 'KB)')

with open(os.path.join(OUT_DIR, 'manifest.json'), 'w') as fh:
    json.dump(manifest, fh, indent=2)
log('fatto: ' + str(len(manifest['files'])) + ' file scaricati, ' + str(len(manifest['skipped'])) + ' saltati -> ' + OUT_DIR)
log('prossimo passo: copia ' + OUT_DIR + '/ nello store del server (My Files -> Pacchetti (pkgmanager) -> store/<id-bundle>/) e «Importa manifest…» nel plugin.')
`;
        return pre + 'INVENTORY = ' + JSON.stringify(inv) + '\n\n' + post;
    };

    // v1.9.0: compiled downloader binaries shipped with the plugin (one per
    // OS, like the meshagents). The server patches the scan inventory into
    // the binary's embedded slot (byte-for-byte, exactly like MeshCentral
    // patches the meshagent .msh) and serves it over /pkgstore.ashx.
    obj.pkgDownloaderPlatforms = ['win-x64', 'win-x86', 'linux-x64', 'linux-arm64', 'linux-arm', 'macos-x64', 'macos-arm64'];
    obj.pkgDownloaderSlot = 2097152; // 2MB inventory slot between the markers
    obj.pkgDownloaderBin = function (session, platform, machines) {
        try {
            var binPath = parent.path.join(parent.parent.datapath, 'plugins', 'pkgmanager', 'bin', 'meshos-downloader-' + platform + ((platform.indexOf('win') === 0) ? '.exe' : ''));
            parent.fs.readFile(binPath, function (err, data) {
                try {
                    if ((err != null) || (data == null)) { obj.replyCatalog(session, null, 'Binario del downloader non ancora disponibile per ' + platform + ' (plugins/pkgmanager/bin/): il plugin lo scarica da solo in background dal canale di aggiornamento (log del server per i dettagli). Nel frattempo usa la piattaforma «py» (script Python standalone) o copia bin/ a mano.'); return; }
                    var mstart = '__MESHOS_INVENTORY_START__';
                    var mend = '__MESHOS_INVENTORY_END__';
                    // The marker STRINGS also live in the binary as .rodata
                    // literals (Go constants): the REAL embedded slot is the
                    // occurrence whose end marker sits at the exact slot
                    // distance — iterate occurrences until it is found.
                    var sIdx = -1;
                    var probe = data.indexOf(mstart);
                    while (probe >= 0) {
                        if (data.indexOf(mend, probe + mstart.length + obj.pkgDownloaderSlot) === (probe + mstart.length + obj.pkgDownloaderSlot)) { sIdx = probe; break; }
                        probe = data.indexOf(mstart, probe + 1);
                    }
                    if (sIdx < 0) { obj.replyCatalog(session, null, 'Slot inventario non trovato nel binario ' + platform + ' (binario corrotto?).'); return; }
                    var inv = Buffer.from(JSON.stringify(machines), 'utf8');
                    if (inv.length > obj.pkgDownloaderSlot) { obj.replyCatalog(session, null, 'Inventario troppo grande (' + Math.round(inv.length / 1024) + 'KB > 2MB): esporta meno macchine per volta o usa il downloader py.'); return; }
                    var bin = Buffer.from(data); // writable copy
                    inv.copy(bin, sIdx + mstart.length); // payload + implicit \0 padding
                    var outDir = parent.path.join(obj.storePath, '_downloader');
                    try { parent.fs.rmSync(outDir, { recursive: true, force: true }); } catch (e) { }
                    parent.fs.mkdirSync(outDir, { recursive: true });
                    var fname = 'meshos-downloader-' + platform + ((platform.indexOf('win') === 0) ? '.exe' : '');
                    parent.fs.writeFileSync(parent.path.join(outDir, fname), bin);
                    obj.plog('exportdownloader -> binario ' + fname + ' (' + Math.round(bin.length / 1048576) + 'MB, inventario ' + Math.round(inv.length / 1024) + 'KB patchato nello slot)');
                    session.send({ action: 'plugin', plugin: 'pkgmanager', method: 'pkgDownloaderReady', platform: platform, file: fname, size: bin.length });
                } catch (e) { obj.replyCatalog(session, null, 'Patch binario fallita: ' + e); }
            });
        } catch (e) { obj.replyCatalog(session, null, 'Patch binario fallita: ' + e); }
    };

    // v1.9.6: helpers auto-aggiornamento plugin
    obj.cmpSemver = function (a, b) {
        try {
            var pa = String(a).split('.'), pb = String(b).split('.');
            for (var i = 0; i < 3; i++) { var x = parseInt(pa[i] || '0', 10) || 0, y = parseInt(pb[i] || '0', 10) || 0; if (x != y) return (x > y) ? 1 : -1; }
            return 0;
        } catch (e) { return 0; }
    };
    obj.pluginVersionFromCode = function (code) { var m = /obj\.version = '([0-9]+\.[0-9]+\.[0-9]+)'/.exec(String(code)); return m ? m[1] : null; };
    // Verifica + backup + scrittura. Il NUOVO codice NON viene eseguito qui:
    // si attiva al riavvio di MeshCentral (o con pkgmanagerAutoRestart).
    obj.pluginInstallUpdate = function (code, knownVersion, session) {
        try {
            if (vmMod == null) { obj.replyCatalog(session, null, 'Aggiornamento plugin: modulo vm non disponibile.'); return; }
            try { new vmMod.Script(String(code)); } catch (se) { obj.replyCatalog(session, null, 'Aggiornamento plugin RIFIUTATO: JavaScript non valido nel file (' + se + ').'); return; }
            var v = obj.pluginVersionFromCode(code);
            if (v == null) { obj.replyCatalog(session, null, 'Aggiornamento plugin RIFIUTATO: versione non leggibile nel file.'); return; }
            if (obj.cmpSemver(v, obj.version) < 0) { obj.replyCatalog(session, null, 'Aggiornamento plugin RIFIUTATO: la versione ' + v + ' e piu vecchia della corrente ' + obj.version + '.'); return; }
            var sha = crypto.createHash('sha384').update(String(code)).digest('hex');
            var selfPath = parent.path.join(parent.parent.datapath, 'plugins', 'pkgmanager', 'pkgmanager.js');
            var bakPath = selfPath + '.bak-' + obj.version;
            try { parent.fs.copyFileSync(selfPath, bakPath); } catch (e1) { obj.replyCatalog(session, null, 'Aggiornamento plugin: backup fallito (' + e1 + ') — niente sovrascrittura.'); return; }
            parent.fs.writeFileSync(selfPath, String(code));
            // v2.1.7: allinea la versione anche nel config.json a disco — e'
            // la fonte di verita' del check auto-restart (poll/immediato).
            try { var _cfg = JSON.parse(parent.fs.readFileSync(obj.pkgLocalConfigPath)); _cfg.version = v; parent.fs.writeFileSync(obj.pkgLocalConfigPath, JSON.stringify(_cfg, null, 2)); } catch (e2) { obj.plog('config.json non allineato alla v' + v + ': ' + e2); }
            try { if (parent.fs.existsSync(obj.updatePendingPath)) { parent.fs.unlinkSync(obj.updatePendingPath); } } catch (e2) { }
            obj._pendingUpdate = null;
            obj.plog('plugin updated ' + obj.version + ' -> ' + v + ' (backup: ' + parent.path.basename(bakPath) + ', sha384=' + sha.slice(0, 16) + '...)');
            var auto = true;
            try { var _pc = parent.parent.config.settings.plugins; auto = ((_pc == null) || (_pc.pkgmanagerAutoRestart !== false)); } catch (e3) { }
            var msg = 'Plugin aggiornato a v' + v + ' (backup: pkgmanager.js.bak-' + obj.version + ', sha384 ' + sha.slice(0, 16) + '...).';
            if (auto) { msg += ' Riavvio automatico di MeshCentral tra 3 secondi.'; setTimeout(function () { obj.plog('auto-restart per attivare la v' + v); console.log('Server restart...'); process.exit(0); }, 3000); } else { msg += ' RIAVVIA MeshCentral per attivare la nuova versione.'; }
            session.send({ action: 'plugin', plugin: 'pkgmanager', method: 'pkgUpdateApplied', version: v, backup: parent.path.basename(bakPath), auto: auto, msg: msg });
        } catch (e) { obj.replyCatalog(session, null, 'Aggiornamento plugin fallito: ' + e); }
    };

    obj.serveraction = function (command, session, parent2) {
        obj.plog('serveraction ' + command.pluginaction + ' from user ' + command.userid);
        var isAdmin = ((session != null) && (session.user != null) && (session.user.siteadmin === 0xFFFFFFFF));
        function deny() { try { session.send({ action: 'plugin', plugin: 'pkgmanager', method: 'pkgDenied', msg: 'Operazioni di gestione riservate agli amministratori del server.' }); } catch (e) { } }

        if (command.pluginaction == 'list') { obj.replyCatalog(session, null, null); return; }

        // v2.2.0: STATO BINARI DOWNLOADER DEL PLUGIN (bin/meshos-downloader-*)
        if (command.pluginaction == 'binstatus') {
            if (!isAdmin) { deny(); return; }
            (function () {
                var files = [];
                try { var names = parent.fs.readdirSync(obj.binDir); for (var i in names) { var f = parent.path.join(obj.binDir, names[i]); var stf = parent.fs.statSync(f); if (stf.isFile()) files.push({ name: names[i], size: stf.size }); } } catch (e1) { }
                try { session.send({ action: 'plugin', plugin: 'pkgmanager', method: 'pkgBinStatus', platforms: obj.downloaderPlatforms, missing: obj.binariesMissing(), busy: (obj.ensureBinariesBusy === true), attempts: (obj.ensureBinariesAttempts || 0), lastError: (obj.binariesLastError || null), url: obj.binariesUrl, dir: obj.binDir, files: files, version: obj.version }); } catch (e2) { }
            })();
            return;
        }
        // v2.2.0: RITENTA MANUALE dei binari downloader (azzera i tentativi)
        if (command.pluginaction == 'binretry') {
            if (!isAdmin) { deny(); return; }
            obj.ensureBinariesAttempts = 0;
            obj.plog('binretry: ritento il download dei binari del downloader su richiesta admin.');
            setTimeout(function () { try { obj.ensureBinaries(); } catch (e3) { } }, 100);
            try { obj.replyCatalog(session, null, 'Ricerca/estrazione binari del downloader rilanciata.'); } catch (e4) { }
            return;
        }
        // v2.2.0: CODA DEI LOG DEL PLUGIN
        if (command.pluginaction == 'plogtail') {
            if (!isAdmin) { deny(); return; }
            var lines = obj.plogBuf.slice(-400);
            var size = null;
            try { size = parent.fs.statSync(obj.logPath).size; } catch (e5) { }
            try { session.send({ action: 'plugin', plugin: 'pkgmanager', method: 'pkgLogTail', lines: lines, path: (obj.logPath || ''), size: size }); } catch (e6) { }
            return;
        }

        // v2.1.9: STATO DEI BINARI AGENTE DEFAULT (agentbuilds) — il core
        // (agentbuilds.js) espone agentDefaults.status() con per-file status/
        // received/size: il pannello "Binari agente" lo rende con barra di
        // avanzamento. Aggiunto lo stato disco (agentbuilds/, agents/).
        if (command.pluginaction == 'agentbuildinfo') {
            if (!isAdmin) { deny(); return; }
            (function () {
                var out = { core: null, disk: [], tools: [] };
                try {
                    var ad = parent.parent.agentDefaults;
                    if ((ad != null) && (typeof ad.status == 'function')) {
                        var st = ad.status();
                        out.core = { busy: !!st.busy, enabled: (st.enabled !== false), errors: (st.errors || []), files: (st.files || []), updates: (st.updates || null) };
                    }
                } catch (e1) { }
                // stato disco: cache verificata agentbuilds/ e override agents/
                var scanDir = function (base, depth, acc) {
                    try {
                        if (!parent.fs.existsSync(base)) return;
                        for (var e of parent.fs.readdirSync(base)) {
                            var p = parent.path.join(base, e);
                            var stt = parent.fs.statSync(p);
                            if (stt.isDirectory()) {
                                if (depth > 0) { scanDir(p, depth - 1, acc); }
                                else {
                                    var sub = [];
                                    try { for (var e2 of parent.fs.readdirSync(p)) { var p2 = parent.path.join(p, e2); var s2 = parent.fs.statSync(p2); sub.push({ name: e2, dir: s2.isDirectory(), size: s2.isDirectory() ? null : s2.size }); } } catch (e3) { }
                                    acc.push({ name: e, dir: true, items: sub });
                                }
                            } else { acc.push({ name: e, dir: false, size: stt.size }); }
                        }
                    } catch (e4) { }
                };
                try {
                    var ab = []; scanDir(parent.path.join(parent.parent.datapath, 'agentbuilds'), 1, ab); out.disk.push({ dir: 'agentbuilds', items: ab });
                    var ag = []; scanDir(parent.path.join(parent.parent.datapath, 'agents'), 0, ag); out.disk.push({ dir: 'agents', items: ag });
                } catch (e5) { }
                try { session.send({ action: 'plugin', plugin: 'pkgmanager', method: 'pkgAgentBuild', info: out }); } catch (e6) { }
            })();
            return;
        }

        // v2.1.8: RIAVVIO DEL SERVER dal pulsante del plugin (solo admin).
        // Usa il canale del launcher: 'Server restart...' su stdout + exit(0)
        // -> il launcher rilancia il figlio in 500ms (riavvio pulito).
        if (command.pluginaction == 'serverrestart') {
            if (!isAdmin) { deny(); return; }
            obj.plog('server restart requested by ' + command.userid);
            try { obj.replyCatalog(session, null, 'Riavvio di MeshCentral tra 2 secondi…'); } catch (e) { }
            setTimeout(function () { console.log('Server restart...'); process.exit(0); }, 2000);
            return;
        }

        // v1.9.6: AUTO-AGGIORNAMENTO DEL PLUGIN — online e airgap
        if (command.pluginaction == 'pluginupdate-check') {
            if (!isAdmin) { obj.plog('denied pluginupdate-check for user ' + command.userid); deny(); return; }
            (function () {
                // v2.1.12: cache-buster — raw/Fastly e' afflitto da POP disallineati
                // (il check poteva leggere una versione vecchia e rispondere
                // "gia aggiornato" per minuti): query string diversa = cache key diversa.
                var _srcUrl = obj.updateSrcUrl + ((obj.updateSrcUrl.indexOf('?') >= 0) ? '&' : '?') + 'nocache=' + Date.now();
                var f = null; try { f = fetch(_srcUrl); } catch (e) { }
                if (f == null) { obj.replyCatalog(session, null, 'Aggiornamento plugin: fetch non disponibile su questo Node.'); return; }
                f.then(function (r) { return r.text(); }).then(function (code) {
                    var v = obj.pluginVersionFromCode(code);
                    if (v == null) { obj.replyCatalog(session, null, 'Aggiornamento plugin: la risposta del sorgente non contiene una versione valida.'); return; }
                    var sha = crypto.createHash('sha384').update(code).digest('hex');
                    var cmp = obj.cmpSemver(v, obj.version);
                    obj._pendingUpdate = ((cmp > 0) ? { code: code, sha: sha, version: v } : null);
                    obj.plog('pluginupdate-check -> corrente ' + obj.version + ', remota ' + v + ' (' + ((cmp > 0) ? 'aggiornamento disponibile' : 'gia aggiornato') + ')');
                    session.send({ action: 'plugin', plugin: 'pkgmanager', method: 'pkgUpdateInfo', current: obj.version, latest: v, newer: (cmp > 0), sha384: sha, url: obj.updateSrcUrl });
                }).catch(function (err) {
                    obj.plog('pluginupdate-check error: ' + err);
                    obj.replyCatalog(session, null, 'Aggiornamento plugin online fallito: ' + err + ' — se il server e airgap usa «Aggiorna plugin (file)».');
                });
            })();
            return;
        }
        if (command.pluginaction == 'pluginupdate-apply') {
            if (!isAdmin) { obj.plog('denied pluginupdate-apply for user ' + command.userid); deny(); return; }
            var pu = obj._pendingUpdate;
            if ((pu == null) || (String(command.sha || '') !== pu.sha)) { obj.replyCatalog(session, null, 'Aggiornamento plugin: nessun download in sospeso o hash non corrispondente — rifai «Aggiorna plugin (online)».'); return; }
            obj.pluginInstallUpdate(pu.code, pu.version, session);
            return;
        }
        if (command.pluginaction == 'pluginupdate-airgap-apply') {
            if (!isAdmin) { obj.plog('denied pluginupdate-airgap-apply for user ' + command.userid); deny(); return; }
            obj.fs.readFile(obj.updatePendingPath, 'utf8', function (err2, code) {
                if ((err2 != null) || (code == null) || (code == '')) { obj.replyCatalog(session, null, 'Aggiornamento plugin: nessun file caricato — usa «Aggiorna plugin (file)» e seleziona il pkgmanager.js nuovo.'); return; }
                obj.pluginInstallUpdate(code, null, session);
            });
            return;
        }

        // v1.7.0: «Scarica aggiornamenti» — INTEGRATED downloader. The SERVER
        // (this process) fetches the vendor indexes, computes the missing
        // updates for every Linux machine from the scan inventory (delta +
        // dependency closure, dpkg version compare when available), downloads
        // the .deb files DIRECTLY into store/<bundle-id>/ and then re-enters
        // serveraction as 'importmanifest' so every file is re-verified and
        // the kind:'os' bundle is built+saved through the normal admin-
        // guarded path. Managed machines never touch the internet — installs
        // keep flowing from THIS server over the LAN. Windows/macOS machines
        // are reported as skipped (best effort: meshos-fetch.js --kb/--macos).
        // v2.0.8: «osplan» — CALCOLO del piano aggiornamenti SENZA download:
        // per ogni gruppo (codename/release) union dei mancanti con versione
        // massima e stato store (presente/mancante). Risponde pkgOsPlan.
        if (command.pluginaction == 'osplan') {
            var pmachs = command.machines;
            if ((pmachs == null) || (Array.isArray(pmachs) !== true) || (pmachs.length === 0)) { obj.replyCatalog(session, null, 'Nessuna macchina nella scansione: prima fai «Scansiona macchine» dalla vista Aggiornamenti OS.'); return; }
            var pskipped = [];
            (async function () {
                try {
                    var pget = async function (url) { var r = await fetch(url, { headers: { 'User-Agent': 'MeshCentral-pkgmanager/2.0' } }); if (!r.ok) { throw new Error('HTTP ' + r.status + ' ' + url); } return Buffer.from(await r.arrayBuffer()); };
                    var plan = await obj.osPlanCompute(pmachs, pget, pskipped);
                    try { session.send({ action: 'plugin', plugin: 'pkgmanager', method: 'pkgOsPlan', plan: plan }); } catch (e) { }
                } catch (err) {
                    obj.plog('osplan error: ' + err);
                    try { obj.replyCatalog(session, null, 'Calcolo piano aggiornamenti fallito: ' + err); } catch (e3) { }
                }
            })();
            return;
        }

        // v2.0.8: «osfetch» — piano + DOWNLOAD dei SOLO file mancanti nello
        // store (store/os-updates-<codename>/), poi ripete il piano aggiornato.
        // NON crea piu' bundle nel catalogo: la vista Aggiornamenti OS lavora
        // direttamente sul piano (elenco pacchetti + stato server).
        if (command.pluginaction == 'osfetch') {
            if (!isAdmin) { obj.plog('denied osfetch for user ' + command.userid + ' (not full site admin)'); deny(); return; }
            var fmachs = command.machines;
            if ((fmachs == null) || (Array.isArray(fmachs) !== true) || (fmachs.length === 0)) { obj.replyCatalog(session, null, 'Nessuna macchina nella scansione: prima fai «Scansiona macchine» dalla vista Aggiornamenti OS.'); return; }
            var fskipped = [];
            (async function () {
                try {
                    var fget = async function (url) { var r = await fetch(url, { headers: { 'User-Agent': 'MeshCentral-pkgmanager/2.0' } }); if (!r.ok) { throw new Error('HTTP ' + r.status + ' ' + url); } return Buffer.from(await r.arrayBuffer()); };
                    var plan = await obj.osPlanCompute(fmachs, fget, fskipped);
                    // v2.2.1: filtra per SELEZIONE del client (chiavi 'storeDir/file')
                    var fsel = null;
                    if (Array.isArray(command.packages)) { fsel = {}; for (var si = 0; si < command.packages.length; si++) { fsel[String(command.packages[si])] = 1; } }
                    var gkeys = plan.groupKeys; var dl = 0; var dlok = 0;
                    // v2.2.7: TOTAL prima del loop (per la barra di avanzamento)
                    var ftot = 0;
                    for (var gi2 = 0; gi2 < gkeys.length; gi2++) {
                        var grp2 = plan.groups[gkeys[gi2]];
                        if (grp2 == null) { continue; }
                        if ((grp2.os != 'linux') && (!((grp2.os == 'windows') && (grp2.updates != null) && (grp2.updates.length > 0)))) { continue; }
                        for (var ui2 = 0; ui2 < grp2.updates.length; ui2++) { var u2p = grp2.updates[ui2]; if ((u2p.inStore !== true) && ((fsel == null) || (fsel[grp2.storeDirName + '/' + u2p.file] != null))) { ftot++; } }
                    }
                    var sendProg = function (file, state, bytes, reason) {
                        try { session.send({ action: 'plugin', plugin: 'pkgmanager', method: 'pkgOsFetchProgress', total: ftot, done: dlok, current: file, state: state, bytes: (bytes || 0), reason: (reason || null) }); } catch (e) { }
                    };
                    sendProg(null, 'start', 0, null); // running=true sul client
                    for (var gi = 0; gi < gkeys.length; gi++) {
                        var grp = plan.groups[gkeys[gi]];
                        if (grp.os != 'linux') { if ((grp.os == 'windows') && (grp.updates != null) && (grp.updates.length > 0)) { grp.storeDirName = grp.storeDirName || ('os-updates-windows' + ((grp.displayVer != null) && (grp.displayVer != '') ? ('-' + grp.displayVer.toLowerCase()) : '')); } else { continue; } }
                        var sdir = parent.path.join(obj.storePath, grp.storeDirName);
                        try { parent.fs.mkdirSync(sdir, { recursive: true }); } catch (e) { }
                        for (var ui = 0; ui < grp.updates.length; ui++) {
                            var u = grp.updates[ui];
                            if (u.inStore === true) { continue; } // gia' presente: niente re-download
                            if ((fsel != null) && (fsel[grp.storeDirName + '/' + u.file] == null)) { continue; } // v2.2.1: non selezionato
                            if (dl > 0 && (dl % 25) === 0) { obj.plog('osfetch ... ' + dl + ' download effettuati'); }
                            dl++;
                            var buf = null;
                            try { buf = await fget(u.origUrl); } catch (e1) { try { buf = await fget(u.url); } catch (e2) { } }
                            if (buf == null) { fskipped.push({ file: u.file, reason: 'download fallito (' + u.origUrl + ')' }); sendProg(u.file, 'fail', 0, 'download fallito'); continue; }
                            parent.fs.writeFileSync(parent.path.join(sdir, u.file), buf);
                            u.sha384 = crypto.createHash('sha384').update(buf).digest('hex');
                            u.size = buf.length; u.inStore = true; dlok++;
                            obj.plog('osfetch ok ' + grp.storeDirName + '/' + u.file + ' (' + Math.round(buf.length / 1024) + 'KB)');
                            sendProg(u.file, 'ok', buf.length, null);
                        }
                    }
                    sendProg(null, 'end', 0, null);
                    obj.plog('osfetch -> ' + dlok + ' scaricati, ' + fskipped.length + ' saltati');
                    try { session.send({ action: 'plugin', plugin: 'pkgmanager', method: 'pkgOsPlan', plan: plan, opAck: 'Scaricati ' + dlok + ' nuovi file nello store; ' + fskipped.length + ' saltati (dettaglio qui sotto).' + ((fsel != null) ? ' Selezione: ' + Object.keys(fsel).length + ' pacchetti.' : '') }); } catch (e) { }
                } catch (err) {
                    obj.plog('osfetch error: ' + err);
                    try { obj.replyCatalog(session, null, 'Download aggiornamenti fallito: ' + err + ' — se il server e airgap usa «Esporta downloader…» nella vista Aggiornamenti OS.'); } catch (e3) { }
                }
            })();
            return;
        }

        // v2.1.0: «osstorelist» — elenco dei file SCARICATI nello store
        // (store/os-updates-<codename>/) per la scheda Gestione aggiornamenti
        // OS: visibilita' dei singoli pacchetti + eliminazione manuale.
        if (command.pluginaction == 'osstorelist') {
            var outStore = [];
            try {
                var storeDirs = parent.fs.readdirSync(obj.storePath);
                for (var sdi = 0; sdi < storeDirs.length; sdi++) {
                    // v2.1.1: include anche la LEGACY 'os-updates' (download
                    // pre-2.0.7, senza suffisso codename) — i suoi file erano
                    // invisibili nella scheda.
                    if ((storeDirs[sdi] !== 'os-updates') && (storeDirs[sdi].indexOf('os-updates-') !== 0)) { continue; }
                    var dirPath = parent.path.join(obj.storePath, storeDirs[sdi]);
                    var st0 = null; try { st0 = parent.fs.statSync(dirPath); } catch (e) { }
                    if ((st0 == null) || !st0.isDirectory()) { continue; }
                    var fls = parent.fs.readdirSync(dirPath);
                    var filesL = [];
                    for (var fj = 0; fj < fls.length; fj++) {
                        var st1 = null; try { st1 = parent.fs.statSync(parent.path.join(dirPath, fls[fj])); } catch (e2) { }
                        if ((st1 != null) && st1.isFile()) { filesL.push({ file: fls[fj], size: st1.size, mtime: st1.mtimeMs }); }
                    }
                    filesL.sort(function (a, b) { return (a.file < b.file ? -1 : (a.file > b.file ? 1 : 0)); });
                    outStore.push({ dir: storeDirs[sdi], files: filesL });
                }
            } catch (e3) { }
            try { session.send({ action: 'plugin', plugin: 'pkgmanager', method: 'pkgOsStoreList', store: outStore }); } catch (e4) { }
            return;
        }

        // v1.9.0: «Esporta downloader…» — COMPILED per-platform downloader
        // (like the meshagents): the server patches the scan inventory into
        // the binary's embedded slot and serves it over /pkgstore.ashx (LAN,
        // admin-only). platform 'py' keeps the v1.8.0 stand-alone Python
        // script as the documented fallback.
        if (command.pluginaction == 'exportdownloader') {
            if (!isAdmin) { obj.plog('denied exportdownloader for user ' + command.userid + ' (not full site admin)'); deny(); return; }
            var xmachs = command.machines;
            if ((xmachs == null) || (Array.isArray(xmachs) !== true) || (xmachs.length === 0)) { obj.replyCatalog(session, null, 'Nessuna macchina nella scansione: prima fai «Scansiona macchine» dalla vista Aggiornamenti OS.'); return; }
            var xplat = String(command.platform || '');
            if (xplat == 'py') {
                try {
                    var xscript = obj.buildPyDownloader(xmachs);
                    obj.plog('exportdownloader -> meshos-downloader.py (' + Math.round(xscript.length / 1024) + 'KB, ' + xmachs.length + ' macchina/e incorporate)');
                    session.send({ action: 'plugin', plugin: 'pkgmanager', method: 'pkgDownloaderReady', filename: 'meshos-downloader.py', script: xscript });
                } catch (e) { obj.replyCatalog(session, null, 'Generazione downloader fallita: ' + e); }
                return;
            }
            if (obj.pkgDownloaderPlatforms.indexOf(xplat) < 0) { obj.replyCatalog(session, null, 'Piattaforma non valida: ' + xplat + '. Disponibili: ' + obj.pkgDownloaderPlatforms.join(', ') + ' (oppure py per lo script Python).'); return; }
            obj.pkgDownloaderBin(session, xplat, xmachs);
            return;
        }

        // v1.6.1: import a meshos-fetch manifest into a kind:'os' bundle.
        // Verifies every file already exists in store/<pkgid>/, builds the
        // per-OS bundle defs (artifacts[] + chained install commands with
        // {{url:N}}/{{sha384:N}} placeholders), then falls through into the
        // normal save branch (admin check + kind-aware guards included).
        if (command.pluginaction == 'importmanifest') {
            var man = command.manifest;
            if ((man == null) || (Array.isArray(man.files) !== true) || (man.files.length === 0)) { obj.replyCatalog(session, null, 'Manifest non valido (serve files[], generato da meshos-fetch).'); return; }
            var pkgid = String(command.pkgid || '');
            if (!/^[a-zA-Z0-9._-]+$/.test(pkgid)) { obj.replyCatalog(session, null, 'ID bundle non valido (lettere, numeri, . _ -).'); return; }
            var byOs = { linux: [], windows: [], macos: [] };
            var missing = [];
            for (var fi = 0; fi < man.files.length; fi++) {
                var fe = man.files[fi];
                var fname = String((fe != null) ? (fe.file || '') : '');
                if (!/^[a-zA-Z0-9._+~:-]+$/.test(fname)) { missing.push(((fname || '(vuoto)') + ' (nome non valido)')); continue; }
                var full = parent.path.join(obj.storePath, pkgid, fname);
                if (!parent.fs.existsSync(full)) { missing.push(fname); continue; }
                var os2 = String((fe != null) ? (fe.os || '') : '');
                if ((os2 != 'linux') && (os2 != 'windows') && (os2 != 'macos')) {
                    var dot2 = fname.lastIndexOf('.'); var ext2 = fname.slice(dot2 + 1).toLowerCase();
                    os2 = ((ext2 == 'deb') || (ext2 == 'rpm') || (ext2 == 'apk')) ? 'linux' : (((ext2 == 'msi') || (ext2 == 'msu') || (ext2 == 'cab')) ? 'windows' : 'macos');
                }
                byOs[os2].push(fe);
            }
            if (missing.length > 0) { obj.replyCatalog(session, null, 'File mancanti nello store — copiali in plugins/pkgmanager/store/' + pkgid + '/: ' + missing.join(', ')); return; }
            var isOsf = ((String((man != null) ? (man.tool || '') : '') == 'pkgmanager-osfetch') || (String((man != null) ? (man.tool || '') : '') == 'pkgmanager-export'));
            var skipN = (Array.isArray(man.skipped) ? man.skipped.length : 0);
            var descOsf = 'Aggiornamenti OS (downloader pkgmanager): ' + man.files.length + ' file (delta+dipendenze dalla scansione' + ((skipN > 0) ? (', ' + skipN + ' saltati: ' + String(man.skipped.slice(0, 2).map(function (s) { return String((s.machine || s.file || '?') + ' — ' + s.reason); }).join(' | ')).slice(0, 220)) : '') + ') — installazione airgap dalla LAN';
            var pkgB = { id: pkgid, name: String(command.name || pkgid), description: (isOsf ? descOsf : ('Bundle OS importato da meshos-fetch (' + String((man.generated != null) ? man.generated : '') + ') — airgap')), kind: 'os' };
            for (var osk in byOs) {
                var fl = byOs[osk];
                if (fl.length === 0) continue;
                var parts2 = [], insts2 = [];
                    // v2.0.7: linux = UN SOLO dpkg/rpm/apk per TUTTI i file
                    // (dpkg gestisce da solo l'ordine e i per-package; prima
                    // erano uno-a-uno in catena ' && ' ordinati per SIZE).
                    var debsA = [], rpmsA = [], apksA = [], othersA = [];
                for (var fk = 0; fk < fl.length; fk++) {
                    var f2 = fl[fk]; var fn = String(f2.file);
                    var dd = fn.lastIndexOf('.'); var b2 = ((dd > 0) ? fn.slice(0, dd) : fn); var e2 = fn.slice(dd + 1).toLowerCase();
                    if (osk == 'linux') {
                        parts2.push("curl -kfsSL -o /tmp/" + fn + " '{{url:" + (fk + 1) + "}}' && echo '{{sha384:" + (fk + 1) + "}}  /tmp/" + fn + "' | sha384sum -c -");
                            if (e2 == 'deb') { debsA.push('/tmp/' + fn); }
                            else if (e2 == 'rpm') { rpmsA.push('/tmp/' + fn); }
                            else if (e2 == 'apk') { apksA.push('/tmp/' + fn); }
                            else { othersA.push('/tmp/' + fn); }
                    } else if (osk == 'windows') {
                        var dst2 = '"%TEMP%\\' + fn + '"';
                        parts2.push('curl -kfsSL -o ' + dst2 + ' "{{url:' + (fk + 1) + '}}" && certutil -hashfile ' + dst2 + ' SHA384 | findstr /i "{{sha384:' + (fk + 1) + '}}"');
                        if (e2 == 'msi') { insts2.push('msiexec /i ' + dst2 + ' /qn'); }
                        else if (e2 == 'msu') { insts2.push('wusa ' + dst2 + ' /quiet /norestart'); }
                        else if (e2 == 'cab') { insts2.push('dism /Online /Add-Package /PackagePath:' + dst2 + ' /NoRestart /Quiet'); }
                        else { insts2.push(dst2 + ' /S'); }
                    } else {
                        parts2.push("curl -kfsSL -o /tmp/" + fn + " '{{url:" + (fk + 1) + "}}' && echo '{{sha384:" + (fk + 1) + "}}  /tmp/" + fn + "' | shasum -a 384 -c -");
                        if (e2 == 'pkg') { insts2.push('sudo -n installer -pkg /tmp/' + fn + ' -target /'); }
                        else if (e2 == 'app') { insts2.push('cp -R /tmp/' + fn + ' /Applications/'); }
                        else { insts2.push('sh /tmp/' + fn); }
                    }
                }
                if (osk == 'linux') {
                    if (debsA.length > 0) { insts2.push('sudo -n dpkg -i ' + debsA.join(' ')); }
                    if (rpmsA.length > 0) { insts2.push('sudo -n rpm -Uvh --force ' + rpmsA.join(' ')); }
                    if (apksA.length > 0) { insts2.push('sudo -n apk add --allow-untrusted ' + apksA.join(' ')); }
                    for (var oa = 0; oa < othersA.length; oa++) { insts2.push('sh ' + othersA[oa]); }
                }
                var cmd2 = parts2.join(' && ');
                if (insts2.length > 0) { cmd2 += ' && ' + insts2.join(' && '); }
                pkgB[osk] = { type: ((osk == 'windows') ? 1 : 3), cmd: cmd2, artifacts: fl.map(function (x) { return String(x.file); }), timeout: 900, kind: 'os' };
            }
            obj.plog('import manifest -> bundle ' + pkgid + ' (' + man.files.length + ' file)');
            command.pkg = pkgB;
            command.pluginaction = 'save';
        }

        if ((command.pluginaction == 'save') || (command.pluginaction == 'delete')) {
            if (!isAdmin) { obj.plog('denied ' + command.pluginaction + ' for user ' + command.userid + ' (not full site admin)'); deny(); return; }
            if (command.pluginaction == 'save') {
                var pkg = command.pkg;
                if ((pkg == null) || (typeof pkg.id != 'string') || (!/^[a-zA-Z0-9._-]+$/.test(pkg.id))) { obj.replyCatalog(session, null, 'ID pacchetto non valido (usa lettere, numeri, . _ -).'); return; }
                if ((typeof pkg.name != 'string') || (pkg.name.trim() == '')) { obj.replyCatalog(session, null, 'Nome pacchetto mancante.'); return; }
                var clean = { id: pkg.id, name: pkg.name.trim() };
                if (typeof pkg.description == 'string') { clean.description = pkg.description; }
                if ((typeof pkg.kind == 'string') && (pkg.kind.trim() == 'os')) { clean.kind = 'os'; } // v1.4.0
                var oses = ['linux', 'windows', 'macos'];
                for (var k = 0; k < oses.length; k++) {
                    var def = obj.sanitizeDef(pkg[oses[k]]);
                    if (def != null) { clean[oses[k]] = def; }
                }
                if ((clean.linux == null) && (clean.windows == null) && (clean.macos == null)) { obj.replyCatalog(session, null, 'Serve almeno un comando per OS.'); return; }
                for (var k2 = 0; k2 < oses.length; k2++) {
                    if ((clean[oses[k2]] != null) && (clean[oses[k2]].uninstall == null) && (String(clean[oses[k2]].kind || '') != 'os')) { obj.replyCatalog(session, null, 'Comando di disinstallazione mancante per ' + oses[k2] + ' (è obbligatoria per le app; opzionale per i bundle aggiornamenti OS).'); return; }
                }
                obj.enqueueCatalogWrite(function () { return new Promise(function (resSave) { // v2.0.7 mutex catalogo
                obj.fs.readFile(obj.catalogPath, function (err, data) {
                    var cat = null;
                    try { cat = JSON.parse(data); } catch (e) { }
                    if (cat == null) { cat = { comment: 'Managed by the pkgmanager plugin.', packages: [] }; }
                    if (cat.packages == null) { cat.packages = []; }
                    var idx = -1;
                    for (var i = 0; i < cat.packages.length; i++) { if (cat.packages[i].id == clean.id) { idx = i; break; } }
                    if (idx >= 0) { cat.packages[idx] = clean; } else { cat.packages.push(clean); }
                    obj.fs.writeFile(obj.catalogPath, JSON.stringify(cat, null, 2), function (e2) {
                        if (e2 != null) { obj.replyCatalog(session, null, 'Scrittura catalogo fallita: ' + e2); resSave(); return; }
                        obj.plog('package saved: ' + clean.id);
                        obj.replyCatalog(session, 'Pacchetto salvato: ' + clean.id, null);
                        resSave();
                    });
                }); }); });
            } else {
                var delId = String(command.id || '');
                if (!/^[a-zA-Z0-9._-]+$/.test(delId)) { obj.replyCatalog(session, null, 'ID non valido.'); return; }
                obj.enqueueCatalogWrite(function () { return new Promise(function (resDel) { // v2.0.7 mutex catalogo
                obj.fs.readFile(obj.catalogPath, function (err, data) {
                    var cat = null;
                    try { cat = JSON.parse(data); } catch (e) { }
                    if ((cat == null) || (cat.packages == null)) { obj.replyCatalog(session, null, 'Catalogo non leggibile.'); resDel(); return; }
                    var idx = -1;
                    for (var i = 0; i < cat.packages.length; i++) { if (cat.packages[i].id == delId) { idx = i; break; } }
                    if (idx < 0) { obj.replyCatalog(session, null, 'Pacchetto inesistente: ' + delId); resDel(); return; }
                    cat.packages.splice(idx, 1);
                    obj.fs.writeFile(obj.catalogPath, JSON.stringify(cat, null, 2), function (e2) {
                        if (e2 != null) { obj.replyCatalog(session, null, 'Scrittura catalogo fallita: ' + e2); resDel(); return; }
                        try { parent.fs.rmSync(parent.path.join(obj.storePath, delId), { recursive: true, force: true }); } catch (e3) { }
                        obj.plog('package deleted: ' + delId);
                        obj.replyCatalog(session, 'Pacchetto eliminato: ' + delId, null);
                        resDel();
                    });
                }); }); });
            }
            return;
        }
    };

    return obj;
};